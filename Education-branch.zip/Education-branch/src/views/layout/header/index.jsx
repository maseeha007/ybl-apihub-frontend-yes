import React from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Navbar, Nav, Modal, Dropdown } from 'react-bootstrap';
import './style.scss';
import Search from '../../components/search';
import Login from '../../components/login';
import Share from '../../components/share';
import { loginModalStatus, makeLogout } from './action';
import { connect } from 'react-redux';
import { savePhoneCode } from '../../components/login/action';
import { Alert } from 'react-bootstrap';
import { globalClickEvent, trackRegisterAttemptEvent } from '../../../analytics'
// Registration Attempt
class Header extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      ...props,
      showSearch: false,
      isSessionExpired: false
    }
    this.closeSearch = this.closeSearch.bind(this);
    this.moveTo = this.moveTo.bind(this);
    this.logout = this.logout.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.openSearch = this.openSearch.bind(this);
    this.register = this.register.bind(this);
    this.handleSessionClose = this.handleSessionClose.bind(this)

  }
  handleClose = () => {
    this.props.closeLoginModal();
    this.props.savePhoneCode("91")
  }
  handleSessionClose = () => {
    localStorage.clear()
    // this.setState({isSessionExpired:false})
    localStorage.setItem("sessionExpired", "false");
    window.location.reload();
  }
  handleShow = () => {
    globalClickEvent('link clicked login')
    this.props.getLogin();
  }
  openSearch = () => {
    globalClickEvent(`link clicked search`);

    this.setState({ showSearch: true })
    document.body.style.overflow = 'hidden';
  }

  closeSearch = () => {
    this.setState({ showSearch: false })
    document.body.style.overflow = 'visible';
  }
  moveTo = () => {
    globalClickEvent(`link clicked subscription-list`);
    const url = '/subscription-list';
    window.location.href = url;
  }
  moveToAccount = () => {
    globalClickEvent(`link clicked account`);
    const url = '/account';
    window.location.href = url;
  }
  logout = () => {
    this.props.makeLogout();
    localStorage.clear();
    if (this.props?.history?.push) {
      this.props.history.push('/');
    } else {
      const url = window.location.href;
      window.location.href = window.location.origin;
    }

  }
  register = () => {
    globalClickEvent(`link clicked register`);
    if ('/register' === window.location.pathname) {
      window.location.reload();
      globalClickEvent(`link clicked register`);
    } else {
      console.log('here you can clicked')
      if (this.props?.history?.push) {
        this.props.history.push('/register');
        globalClickEvent(`link clicked register`);

      } else {
        window.location.href = '/register';
        globalClickEvent(`link clicked register`);

      }
    }
  }

  headerSectionChanges = (link, name) => {
    globalClickEvent(`link clicked ${name}`);
    window.location.href = link;
  }

  render() {
    let username = localStorage.getItem('userName');
    const menuLink = [{ 'link': 'Home', 'path': '/' }, { 'link': 'Explore', 'path': '/explore' }, { 'link': 'Get Started', 'path': '/getStarted' }, 
    //{ 'link': 'FAQ', 'path': '/faq' },
    // { 'link': 'Partner', 'path': '/partner-products' },
    { 'link': 'yesxpress onboarding', 'path': '/yesxpressonboarding' },
    { 'link': 'Trade', 'path': '/Trade' },
    { 'link': 'education', 'path': '/education' }]
    const isDesktop = window.screen.width > 1000
    return (
      <React.Fragment>
        {this.state.showSearch ? <Search close={this.closeSearch} /> : null}
        <Navbar expand={`lg ${isDesktop ? 'sticky' : 'not-desktop'}`} className="no-pad navin-top" id="mainNav">
          <Navbar.Toggle className="no-border" id='toggle' aria-controls="ybl-navbar-nav" />
          <Navbar.Brand ><Link to="/"><img alt="logo" className="logo" src="/assets/img/logo.svg" /></Link></Navbar.Brand>
          {username ?
            <Nav className="icon-group d-xs-flex d-sm-flex d-md-none d-lg-none">
              <Dropdown className="header-dropdown">
                <Dropdown.Toggle variant="link" id="user-dorpdown">
                  {username && username == 'XXXXXXXXXXXXX' ? 'Unknown' : username}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item onClick={this.moveToAccount}>My Account</Dropdown.Item>
                  <Dropdown.Item onClick={this.moveTo}>My Subscription</Dropdown.Item>
                  <Dropdown.Item onClick={this.logout}>Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              <Nav.Link className="icon" onClick={this.openSearch}><img alt="icon" className="preShow" src="/assets/icons/search-black.svg" /> <img alt="icon" className="postShow" src="/assets/icons/search-blue.svg" /> <span>Search</span></Nav.Link>
            </Nav>
            :
            <Nav className=" navin icon-group d-xs-flex d-sm-flex d-md-none d-lg-none">
              <Nav.Link className="mobile-login-icon  mg-10" onClick={this.handleShow}><img alt="icon" className="mg-10" src="/assets/icons/login-mobile-profile.svg" />
                {/* <span className="blk"> Login</span>  */}
              </Nav.Link>
              {/* <Nav.Link className="icon" onClick={this.register}><img alt="icon" className="" src="/assets/icons/register-black.svg" />  </Nav.Link> */}
              <Nav.Link className="icon" onClick={this.openSearch}><img alt="icon" className="" src="/assets/icons/search.svg" /> </Nav.Link>
              {/* <p>Demo </p> */}
            </Nav>}

          <Navbar.Collapse className="justify-content-center nav-pills visible-md hidden-sm" id="ybl-navbar-nav">
            <Nav>
              {menuLink.map((item, index) => <Nav.Link key={index} className={this.props.title == item.link ? 'active' : ''}
                // href={item.path}
                onClick={this.headerSectionChanges.bind(this, item.path, item.link)}
              >{item.link}</Nav.Link>)}
            </Nav>
          </Navbar.Collapse>
          {username ?
            <Nav className="icon-group d-none d-sm-none d-md-flex d-lg-flex">
              <Dropdown className="header-dropdown">
                <Dropdown.Toggle variant="link" id="user-dorpdown">
                  Welcome, {username && username == 'XXXXXXXXXXXXX' ? 'Unknown' : username}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item onClick={this.moveToAccount}>My Account</Dropdown.Item>
                  <Dropdown.Item onClick={this.moveTo}>My Subscription</Dropdown.Item>
                  <Dropdown.Item onClick={this.logout}>Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              <Nav.Link className="icon" onClick={this.openSearch}><img alt="icon" className="preShow" src="/assets/icons/search-blue.svg" /> </Nav.Link>
            </Nav>
            :
            <Nav className="icon-group d-none d-sm-none d-md-flex d-lg-flex">
              <Nav.Link className="icon login" onClick={this.handleShow}>Login</Nav.Link>
              <Nav.Link className="icon register" onClick={this.register}>Register</Nav.Link>
              <Nav.Link className="icon-search" onClick={this.openSearch}><img alt="icon-search" src="/assets/icons/search.svg" /></Nav.Link>
            </Nav>}
        </Navbar>
        <div className="clearfix"></div>
        <Modal className={'loginModal'} show={this.props.login} onHide={this.handleClose}>
          <Modal.Header className="login-header">
            Login
            <button type="button" class="close"><span aria-hidden="true">
              <img
                alt="icon"
                className="close-icon"
                src="/assets/icons/login-close.svg"
                onClick={this.handleClose}
              />

            </span><span class="sr-only">Close</span></button>
          </Modal.Header>
          <Modal.Body>
            <Login modalclose={this.handleClose} />
          </Modal.Body>
        </Modal>
        <Modal className={'loginModal'} show={localStorage.getItem("sessionExpired") === "true"} onHide={this.handleSessionClose}>
          <Modal.Header className="login-header">
            Session Expired
            <button type="button" class="close"><span aria-hidden="true">
              <img
                alt="icon"
                className="close-icon"
                src="/assets/icons/login-close.svg"
                onClick={this.handleSessionClose}
              />

            </span><span class="sr-only">Close</span></button>
          </Modal.Header>
          <Modal.Body>
            <Alert className="danger" variant="danger">Your Session has expired. Please login again.  </Alert>
          </Modal.Body>
        </Modal>
        <Share></Share>
      </React.Fragment >
    )
  }
}

const mapStateToProps = (state) => ({
  login: state.headerReducer.loginModal

});
const mapDispatchToProps = (dispatch) => {
  return {
    getLogin: () => dispatch(loginModalStatus(true)),
    closeLoginModal: () => dispatch(loginModalStatus(false)),
    makeLogout: () => dispatch(makeLogout(false)),
    savePhoneCode: (code) => dispatch(savePhoneCode(code))
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Header));


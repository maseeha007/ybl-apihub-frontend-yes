import { FETCH_SUBSCRIPTION, ACCEPT_SUBSCRIPTION, DECLINE_SUBSCRIPTION } from './constant';



export const get_subscriptions = (payload) => ({
  type: FETCH_SUBSCRIPTION,
  payload: payload
})


export const accept_subscription = (payload) => ({
  type: ACCEPT_SUBSCRIPTION,
  payload: payload
})


export const decline_subscription = (payload) => ({
  type: DECLINE_SUBSCRIPTION,
  payload: payload
})

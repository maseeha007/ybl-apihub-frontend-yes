import axios from 'axios';
import { APIMiddLEWAREURL } from '../../../env';

export const get_subscription = (payload, token) => {
  console.log(payload, 'piyush');
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  return axios.get(
    `${window.yblDomain}` + '/admin/partners?partnerStatus=' + payload.type + '&pageSize=' + payload.pageSize + '&pageNumber=' + payload.pageNumber,
    config
  );
};

export const decline_subscription = ({ payload }, token) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  return axios.post(`${window.yblDomain}` + `/admin/actions?entityId=${payload}&actionFor=partner&actionType=rejected`, {}, config);
};

export const accept_subscription = ({ payload }, token) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  //api.636018471a4e4806a6f8.southeastasia.aksapp.io/admin/actions?entityId=510&actionFor=partner&actionType=approved
  return axios.post(`${window.yblDomain}` + `/admin/actions?entityId=${payload}&actionFor=partner&actionType=approved`, {}, config);
};

// curl --location --request GET 'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io/admin/caleadsReport?fromDate=07-03-2021&toDate=31-03-2021' \
// --header 'Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImV4cCI6MTYyNTU3MzM5MiwiaWF0IjoxNjI1NTcyNDkyfQ.Vx_1D6QdKp7hdmJH-mx4he5JdUsD03X3uX9XOORzSHhqWR2kJnLmuynqBX4E_eJYIMvBMCQGvL5nX_5XhGB1kQ'

export const downloadPartner_subscription = ({ payload }) => {
  const token = localStorage.getItem('adminToken');
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  return axios.get(`${window.yblDomain}` + `/admin/caleadsReport?fromDate=${payload.fromDate}&toDate=${payload.toDate}`, config);
};

import { all, takeEvery, put } from 'redux-saga/effects'

import { FETCH_CASUBSCRIPTION, FETCH_CASUBSCRIPTION_SUCCESS, FETCH_CASUBSCRIPTION_FAIL,
    ACCEPT_CASUBSCRIPTION, ACCEPT_CASUBSCRIPTION_SUCCESS, ACCEPT_CASUBSCRIPTION_FAIL,
    DECLINE_CASUBSCRIPTION, DECLINE_CASUBSCRIPTION_SUCCESS, DECLINE_CASUBSCRIPTION_FAIL } from './constant';
    import { get_subscription, accept_subscription, decline_subscription } from './apis';

export function* fetchSubscriptionAsync({payload}) {
    try {
        const token = localStorage.getItem("adminToken");
        let {data} = yield get_subscription(payload,token);
        if(data.statusType!='SUCCESS'){
            yield   put({'type':FETCH_CASUBSCRIPTION_FAIL, data});
        } else {
            yield put({'type': FETCH_CASUBSCRIPTION_SUCCESS, data})
        }
    }  catch(err) {
        yield put({'type':'NETWORK ERROR'});
        if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
            localStorage.setItem("AdminAccess","No")
            window.location.href=`${window.location.origin}/admins`

        }
    }    
}

export function* acceptSubscriptionAsync(payload) {
    try {
        const token = localStorage.getItem("adminToken")
        let {data} = yield accept_subscription(payload,token);
        if(data.statusType!='SUCCESS'){
            yield put({'type': ACCEPT_CASUBSCRIPTION_FAIL, data: data?.message})
        } else {
            yield  put({'type':ACCEPT_CASUBSCRIPTION_SUCCESS, data});
        }
    }  catch (err) {
        yield put({'type':'NETWORK ERROR'})
        if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
            localStorage.setItem("AdminAccess","No")
            window.location.href=`${window.location.origin}/admins`

        }
    }    
}



export function* declineSubscriptionAsync(payload) {
    try {
        const token = localStorage.getItem("adminToken")
        let {data} = yield decline_subscription(payload,token);
        if(data.statusType!='SUCCESS'){
            yield put({'type': DECLINE_CASUBSCRIPTION_FAIL, data: data?.message})
        } else {
            yield  put({'type':DECLINE_CASUBSCRIPTION_SUCCESS, data});
        }
    }  catch(err) {
        yield put({'type':'NETWORK ERROR'})
        if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
            localStorage.setItem("AdminAccess","No")
            window.location.href=`${window.location.origin}/admins`

        }
    }    
}

export default function* watchAll() {
    yield all([
        takeEvery(FETCH_CASUBSCRIPTION, fetchSubscriptionAsync),
        takeEvery(ACCEPT_CASUBSCRIPTION, acceptSubscriptionAsync),
        takeEvery(DECLINE_CASUBSCRIPTION, declineSubscriptionAsync),
    ])
    
}
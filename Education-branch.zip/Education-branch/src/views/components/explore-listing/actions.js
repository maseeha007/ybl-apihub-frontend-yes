import { GET_SOLUTIONS, GET_TAGS_DATA, UPDATE_EXPLORE_LIST, GET_PARTNER_CATEGORY } from './constant';

export const getSolutions = () => ({
  type: GET_SOLUTIONS,
});

export const getTagsData = (tags, boolean) => ({
  type: GET_TAGS_DATA,
  payload: { tags, boolean },
});
export const updateExploreList = (tags) => ({
  type: UPDATE_EXPLORE_LIST,
  payload: { tags, boolean: '' },
});

export const getCategory = () => ({
  type: GET_PARTNER_CATEGORY,
});

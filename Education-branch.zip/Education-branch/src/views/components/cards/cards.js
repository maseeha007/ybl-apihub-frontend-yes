import React,{ useState } from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Tooltip, OverlayTrigger ,Modal} from 'react-bootstrap';
import './style.scss';
import { connect } from 'react-redux';
import { globalClickEvent } from '../../../analytics';
function Cards(props) {
  const [openPopup, setOpenPopup] = useState(false);
  const [partnerurl, setPartnerurl] = useState("");
  const [partnername, setPartnername] = useState("");

  const handleClose = () => {
    setOpenPopup(false)
  };
  const handleurldirect = (data) => {
    window.open(data, "_blank");
    setOpenPopup(false)
  };
  const movetoNextPagepartner= (data ,name) => {
    debugger;
    setOpenPopup(true)
    setPartnerurl(data)
    setPartnername(name)
   // window.location.href = data;
  }
  const renderTooltip = (props, feature) => (
    console.log('checking feature', props),
    (
      <Tooltip id="button-tooltip" {...props}>
        <div className="feature-heading-container">
          <h1 className="feature-heading">Features</h1>
        </div>
        {props.map((feature, index) => (
          <ul className="listing">
            {index < 4 && (
              <li className="tooltip-heading">
                <span className="tooltip-heading_icon"></span>
                <p>{feature.featureName}</p>
              </li>
            )}
          </ul>
        ))}
      </Tooltip>
    )
  );
  const movetoNextPage = (name, isyblProduct, solution, pid) => {
    const url =
      isyblProduct === 'true'
        ? `/product?id=${pid}&name=${name}&solutionName=${solution}`
        : `/partnerdetails?id=${pid}&name=${name}&solname=${solution.replace('&', '~')}`;
    globalClickEvent(`link clicked on Explore page ${name}`);
    window.location.href = url;
  };
  return (
    <section id="cards">
      <div className="card-container">
        <Row noGutters={true} className="fixed-width-section">
          {props.data.map((product, index) => (
            <div className="cols">
              <OverlayTrigger
                isOpen={true}
                placement={index % 3 === 0 ? 'right' : 'left'}
                delay={{ show: 200, hide: 20 }}
                overlay={renderTooltip(product.feature)}
              >
               {!product.redirectUrl ?
               <Link
                  className="slink "
                  // to={
                  //   product.isYblProduct === 'true'
                  //     ? `/product?id=${product.productId}&name=${product.productName}&solutionName=${props.solution}`
                  //     : '/partnerdetails?id=' + product.productId + '&name=' + product.productName + '&solname=' + props.solution.replace('&', '~')
                  // }
                  onClick={movetoNextPage.bind(this, `${product.productName}`, `${product.isYblProduct}`, props.solution, product.productId)}
                >
                  <Card className="solutionCard">
                    <Card.Body className="no-pad">
                      <img
                        className="oval"
                        src={
                          product.isYblProduct === 'true'
                            ? '/assets/explore/' + String(product.productName).toLowerCase().replace(/\s/g, '-') + '.svg'
                            : '/assets/explore/zoho-books.svg'
                        }
                        alt=""
                      />
                      <Card.Title className="scard-title">{product.productName}</Card.Title>
                      <Card.Text className="scard-text">{product.description}</Card.Text>
                      {product.isYblProduct === 'true' ? (
                        <span>
                          {/* <img
                            className="logo-img"
                            src="/assets/img/logo.svg"
                            alt=""
                          /> */}
                        </span>
                      ) : (
                        <span>
                          <img className="logo-img" src={'/assets/img/' + String(product.productName).toLowerCase().replace(/\s/g, '-') + '-logo.svg'} alt="" />
                        </span>
                      )}
                    </Card.Body>
                  </Card>
                </Link>
                :product.redirectUrl  ?
                <a className="slink "
                onClick={movetoNextPagepartner.bind(this, `${product.redirectUrl}`, `${product.productName}`)}
                  //href={product.redirectUrl} 
                  //target="_blank"  
                >
                 
                  <Card className="solutionCard">
                    <Card.Body className="no-pad">
                      <img
                        className="oval"
                        src={
                          product.isYblProduct === 'true'
                            ? '/assets/explore/' + String(product.productName).toLowerCase().replace(/\s/g, '-') + '.svg'
                            : '/assets/explore/zoho-books.svg'
                        }
                        alt=""
                      />
                      <Card.Title className="scard-title">{product.productName}</Card.Title>
                      <Card.Text className="scard-text">{product.description}</Card.Text>
                      {product.isYblProduct === 'true' ? (
                        <span>
                          {/* <img
                            className="logo-img"
                            src="/assets/img/logo.svg"
                            alt=""
                          /> */}
                        </span>
                      ) : (
                        <span>
                          <img className="logo-img" src={'/assets/img/' + String(product.productName).toLowerCase().replace(/\s/g, '-') + '-logo.svg'} alt="" />
                        </span>
                      )}
                    </Card.Body>
                  </Card>
                </a>:''
                
                }
              </OverlayTrigger>
            </div>
          ))}
        </Row>
      </div>

      <Modal className={'disclamerpartner sm'} show={openPopup} onHide={handleClose.bind(this)}>
          <Modal.Header className="login-header">
           {partnername}
            <button type="button" class="close">
              <span aria-hidden="true">
                <img alt="icon" className="close-icon" src="/assets/icons/login-close.svg" onClick={handleClose.bind(this)} />
              </span>
              <span class="sr-only">Close</span>
            </button>
          </Modal.Header>
          <Modal.Body>
          <p><strong>Disclaimer:</strong></p>
           <p>By clicking on this link you will be leaving yesconnect.yesbank.in and will be redirected to a third party website. Any use of the third party website will be subject to and any information you provide will be governed by the terms of the third party website, including those relating to confidentiality, data privacy and security. YES BANK does not control such third party websites, and is not responsible for their contents and services. The products, services and offers are subject to the respective terms and conditions of the third party. Nothing contained herein shall constitute or be deemed to constitute an advice, invitation or solicitation to purchase any products/services of the third party. YES BANK Limited makes no representation about the quality, delivery, usefulness or otherwise of the goods / services offered by the third party.</p>
           <button type="button" onClick={handleClose.bind(this)} class="cancle-btn btn btn-default">Cancel</button>
           <button type="button" onClick={handleurldirect.bind(this,partnerurl)} class="submit-btn btn btn-primary">Agree and Proceed</button>
          </Modal.Body>
        </Modal>
    </section>
  );
}
const mapStateToProps = (state) => ({
  products: state.solutionsReducer.products,
});
const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(Cards);

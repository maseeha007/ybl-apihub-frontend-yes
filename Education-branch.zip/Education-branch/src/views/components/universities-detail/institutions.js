import React, { PureComponent } from 'react';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import { Container, Row, Col, Card } from 'react-bootstrap';
import PartnerBanner from '../../components/partnerbanner';


import './style.scss';

import { onLoadTrack, trackErrorEvent } from '../../../analytics';
import { myBusinessObj } from '../../../service/mybusiness';
// import {track} from '../../../analytics'
class Explore extends React.Component {
  constructor(props) {
    super(props);


  }


  componentDidMount() { }

  componentWillUnmount() { }


  render() {

    return (
      <>
        <div>
          <Header title="institution-detail" />

          <section id="institutions" >
            <div className='explorebanner'>
              <div className="container">
                <div className="banner-container">
                  <h2 className="banner-heading">EDU Connect for Universities</h2>
                  <h2 className="banner-heading"><b>Transition to an innovative, digital campus with an ease</b></h2>
                </div>
              </div>
            </div>

            <div className='container Solutioningcon'>
              <div className='row align-items-center'>
                <div className='col-sm-12 text-center'>
                  <h2 className='mb-4'>Smart Campus Solutions for Colleges</h2>
                  <p className='para'>EDU Connect facilitates banking & beyond banking services that uses networked technologies to facilitate receivables, payments, communication with enhanced security. </p>
                  <h4>Key Advantages for your institution</h4>

                </div>


                <div className='col-sm-6 '>
                  <img src='/assets/explore/School-section.svg' className='img-fluid imgbox mt-5' />

                </div>
                <div className='col-sm-6 '>
                  <div class="content advantage">
                    <ul>
                      <li><span><b>Be Compliant:</b></span><p>Get real time downloadable Format Reports for License Renewal & Audit.</p></li>
                      <li><span><b>Data-driven decision-making:</b></span><p>Access to interactive visualized dashboards with multi-level snapshots highlighting critical insights.</p></li>
                      <li><span><b>Enhanced management control:</b></span><p>A comprehensive Accounting, Reconciliation & Transaction Hub to manage your budgets, government grants & fund utilization.</p></li>
                      <li><span><b>Enriching transactional experience:</b></span><p>Validates student fee details instantly, offers multiple payment modes for fee payment, and automatically updates your ERP through API Banking.</p></li>

                    </ul>
                  </div>

                </div>

                <div className='col-sm-12 text-center '>
                  <h4 className='headinst'>Benefits for Students</h4>

                </div>
                <div className='col-sm-6 '>
                  <div class="content advantage">
                    <ul>
                      <li><span><b>Enhanced Campus experience with three taps</b></span><p>With a smart ID card, tap to mark attendance, tap to make a purchase on campus, tap for student profile and health records in case of emergency</p></li>
                      <li><span><b>Customized Web-Interface</b></span><p>Access to a dashboard for Academic Records, Online Lectures & Examinations, Fee Payments with transactional records & due date reminders</p></li>
                    </ul>
                  </div>

                </div>
                <div className='col-sm-6 '>
                  {/* <img src='/assets/explore/benefitsstudent.png' className='img-fluid imgbox' /> */}
                
                  <img src='/assets/explore/teammeat.png' className='img-fluid imgbox' />
                </div>
              </div>
            </div>


            <div className='container-fluid SmartCampus'>
              <div className='container'>
                <div className="row" >
                  <div className="col-sm-12 text-center" >
                    <h2>Explore Our Smart Campus Products</h2>
                  </div>
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/Bill-Management-HP.svg' alt="" />
                        <Card.Title className="scard-title">Digital Campus</Card.Title>
                        <Card.Text className="scard-text">Is a co-created holistic solution that can handle the entire gamut of on-campus and off-campus activities in a School, College or University which can be delivered modular or as a totally customized Campus Management Suite with Integrated Banking Channels</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/Payment-HP.svg' alt="" />
                        <Card.Title className="scard-title">Cashless Campus</Card.Title>
                        <Card.Text className="scard-text">Is a smart card-based proposition for Students which would be a ID Card with student records & also card which enables access and contactless payments on the campus. Institutes can also issue co-branded expense management cards for staff & admin to track & control the expenses.</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/Receivables-HP.svg' alt="" />
                        <Card.Title className="scard-title">Fee Management</Card.Title>
                        <Card.Text className="scard-text">Is a robust fee collections system enabling offline economy to shift from paper to digital collections. It reduces 90% of the manual reconciliation effort in fees collection. Get reports and detailed Statistics on payments, manage your settlements, refunds and much more right from one single dashboard</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/account-HP.svg' alt="" />
                        <Card.Title className="scard-title">Fund Management</Card.Title>
                        <Card.Text className="scard-text">Is a secure hassle-free payments solutioning for wide range of transactional experience. Get reports and detailed Statistics on Budget allocation, government grants, fund utilization, vendor payments, salary disbursal and much more right from one single dashboard</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                </div>
              </div>
            </div>

          </section>
          <Footer />
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  //products: state.solutionsReducer.products,

});
const mapDispatchToProps = (dispatch) => {
  return {

  };
};

export default Explore;

import React, { PureComponent } from 'react';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import { Container, Row, Col, Dropdown, Form, Modal, Badge } from 'react-bootstrap';
import { getSolutions, getTagsData, updateExploreList } from './actions';
import { getAccountData } from '../account/actions';
import Cards from '../cards/cards';
import './style.scss';
import { connect } from 'react-redux';
import { onLoadTrack } from '../../../analytics';
import { myBusinessObj } from '../../../service/mybusiness';

class Explore extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      tags: [
        { id: 4, value: 'Electronic Collection', isChecked: true },
        { id: 5, value: 'Dealer Payment Recovery', isChecked: true },
        { id: 6, value: 'Remittance', isChecked: true },
        { id: 7, value: 'Fund Transfer', isChecked: true },
        { id: 8, value: 'Bulk Transfers', isChecked: true },
        { id: 9, value: 'Benificiary Management', isChecked: true },
        // { id: 10, value: 'Bill Management', isChecked: true },
        { id: 11, value: 'Wallet Management', isChecked: true },
        { id: 12, value: 'ERP', isChecked: true },
        { id: 13, value: 'Accounting', isChecked: true },
        { id: 14, value: 'Invoice Management', isChecked: true },
        { id: 15, value: 'Payroll', isChecked: true },
        { id: 16, value: 'API Aggregator', isChecked: true },
      ],
      solutions: [
        { id: 1, value: 'YES BANK', isChecked: false },
        { id: 2, value: 'Partners', isChecked: true },
        { id: 3, value: 'Popular', isChecked: false },
      ],
      allchecked: false,
      alltags: false,
      headings: ['Account', 'Payment', 'Receivables', 'Remittances', 'Supply Chain'],
      width: window.innerWidth,
      show: false,
      dropValue: { key: 'Select', value: '' },
      allSolutions: false,
      solutionTags: [],
      filterTags: [],
      searchParams: '',
      businessSolution: myBusinessObj,
    };
  }

  handleScroll = () => {
    const header = document.getElementById('searchHeader');
    const sticky = header?.offsetTop;
    if (window?.pageYOffset > sticky) {
      header.classList.add('sticky');
    } else {
      header?.classList?.remove('sticky');
    }
  };

  parseQuery(queryString) {
    var query = {};
    var pairs = (queryString[0] === '?' ? queryString.substr(1) : queryString).split('&');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split('=');
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
    }
    return query;
  }
  componentDidMount() {
    this.props.getAccountData();

    const {
      match: { params },
    } = this.props;
    this.setState({ ...this.state, path: params.path });
    window.addEventListener('resize', this.handleWindowSizeChange);
    window.addEventListener('scroll', this.handleScroll);
    let qs = this.parseQuery(this.props.location.search);
    const solutionType = qs.type == 'partner' ? 'partner' : 'ybl';

    if (solutionType === 'ybl') {
      const yblSol = [
        { id: 1, value: 'YES BANK', isChecked: true },
        { id: 2, value: 'Partners', isChecked: false },
        { id: 3, value: 'Popular', isChecked: false },
      ];
      this.setState({ solutions: yblSol });
    } else {
      const partnerSol = [
        { id: 1, value: 'YES BANK', isChecked: false },
        { id: 2, value: 'Partners', isChecked: true },
        { id: 3, value: 'Popular', isChecked: false },
      ];
      this.setState({ solutions: partnerSol });
    }
    if (qs.searchKey) {
      this.setState({ searchParams: qs.searchKey });
      this.props.getTagsData(qs.searchKey, '');
    } else {
      this.props.getSolutions({ solutionName: String(params.path).split('-').join(' '), solutionType: solutionType });
    }

    const isValidTag = this.state.tags.find(({ value }) => value === qs.searchKey);
    const filterData = [...this.state.tags];
    if (qs.searchKey) {
      if (isValidTag) {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = tag.value === qs.searchKey;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      } else {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = false;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      }
    } else {
      const selectedTags = filterData.map((tag) => {
        tag.isChecked = true;
        return tag;
      });
      this.setState({ tags: selectedTags, alltags: true });
    }
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.handleWindowSizeChange);
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleWindowSizeChange = () => {
    this.setState({ width: window.innerWidth });
  };

  handleClose = () => this.setState({ show: false });
  handleShow = () => this.setState({ show: true });
  handleAllCheckedMobile = (event, field) => {
    if (field == 'solution') {
      let allcheck = [...this.state.solutionTags];
      if (allcheck.length === 3) {
        allcheck.splice(0, allcheck.length);
      } else if (allcheck.length < 3) {
        allcheck = ['YES BANK', 'Partners', 'Popular'];
      }
      this.setState(
        {
          solutionTags: allcheck,
        },
        () => console.log('this.sttae.solutionTags', this.state.solutionTags)
      );
    } else if (field == 'tags') {
      let allcheck = [...this.state.filterTags];
      if (allcheck.length === 10) {
        allcheck.splice(0, allcheck.length);
      } else if (allcheck.length < 10) {
        allcheck = [
          'Account Balance',
          'Account Details',
          'Account Transactions',
          'Inward remittance',
          'Beneficiary Management',
          'Fund Reservation',
          'Card Account Transactions',
          'Payment Initiation Service',
          'Remittance',
          'Supply chain',
        ];
      }
      this.setState(
        {
          filterTags: allcheck,
        },
        () => console.log('this.state.filterTags', this.state.filterTags)
      );
    }
  };
  handleAllChecked = (event, field) => {
    if (field == 'solution') {
      let temp = event.target.checked;
      let solutions = [...this.state.solutions];
      solutions.forEach((sol) => (sol.isChecked = event.target.checked));
      this.setState({
        solutions: solutions,
        allchecked: temp,
      });
      console.log('this.state.solutions', this.state.solutions);
    } else {
      let temp = event.target.checked;
      let tags = [...this.state.tags];
      tags.forEach((tag) => (tag.isChecked = event.target.checked));
      this.setState({
        tags: tags,
        alltags: temp,
      });
    }
  };
  handleCheckChildElementMobile = (event, field, value) => {
    if (field == 'solution') {
      let selected = [...this.state.solutionTags];
      if (selected.indexOf(value) !== -1) {
        selected.splice(selected.indexOf(value), 1);
      } else {
        selected.push(value);
      }
      this.setState(
        {
          solutionTags: selected,
        },
        () => {
          console.log('solutionTags', this.state.solutionTags);
          let boolean = '';
          const tagsToCheck = this.state.solutionTags;
          if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
            boolean = '';
          } else if (tagsToCheck.includes('YES BANK')) {
            boolean = true;
          } else if (tagsToCheck.includes('Partners')) {
            boolean = false;
          }
          this.props.getTagsData([...this.state.filterTags], boolean);
        }
      );
    } else if (field == 'tags') {
      let selected = [...this.state.filterTags];
      if (selected.indexOf(value) !== -1) {
        selected.splice(selected.indexOf(value), 1);
      } else {
        selected.push(value);
      }
      this.setState(
        {
          filterTags: selected,
        },
        () => {
          console.log('solutionTags', this.state.filterTags);
          let boolean = '';
          const tagsToCheck = this.state.solutionTags;
          if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
            boolean = '';
          } else if (tagsToCheck.includes('YES BANK')) {
            boolean = true;
          } else if (tagsToCheck.includes('Partners')) {
            boolean = false;
          }
          this.props.getTagsData([...this.state.filterTags], boolean);
        }
      );
    }
  };
  handleCheckChildElement = (event, field) => {
    if (field == 'solution') {
      let temp = false;
      let solutions = [...this.state.solutions];
      solutions.forEach((sol) => {
        if (sol.value === event.target.value) sol.isChecked = event.target.checked;
      });
      temp = solutions.every((sol) => {
        return sol.isChecked === true;
      });
      this.setState({
        solutions: solutions,
        allchecked: temp,
      });
    } else {
      let temp = false;
      let tags = [...this.state.tags];
      tags.forEach((tag) => {
        if (tag.value === event.target.value) tag.isChecked = event.target.checked;
      });
      temp = tags.every((tag) => {
        return tag.isChecked === true;
      });
      this.setState({
        tags: tags,
        alltags: temp,
      });
    }
  };
  handleApply = (field) => {
    if (field === 'mobile') {
      let tagsToCheck = [...this.state.solutionTags];
      let tagsToSend = [...this.state.filterTags];
      console.log('check', tagsToSend, tagsToCheck);
      let boolean = false;
      if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
        boolean = '';
      } else if (tagsToCheck.includes('YES BANK')) {
        boolean = true;
      } else if (tagsToCheck.includes('Partners')) {
        boolean = false;
      }
      this.props.getTagsData(tagsToSend, boolean);
      this.handleClose();
      if (tagsToSend.length === 1) {
        this.setState({ searchParams: tagsToSend[0] });
      } else {
        this.setState({ searchParams: '' });
      }
    } else {
      let tagsToCheck = [];
      let tagsToSend = [];
      let boolean = '';
      this.state.solutions.forEach((sol, index) => {
        if (sol.isChecked) {
          tagsToCheck.push(sol.value);
        }
      });
      this.state.tags.forEach((tag, index) => {
        if (tag.isChecked) {
          tagsToSend.push(tag.value);
        }
      });
      if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
        boolean = '';
      } else if (tagsToCheck.includes('YES BANK')) {
        boolean = true;
      } else if (tagsToCheck.includes('Partners')) {
        boolean = false;
      }
      this.props.getTagsData(tagsToSend, boolean);
    }
  };
  handleDropdown = (e, sol) => {
    e.preventDefault();
    this.setState(
      {
        dropValue: sol,
      },
      () => console.log('dropvalue', this.state.dropValue)
    );
    this.props.updateExploreList(sol.value);
  };
  componentDidUpdate(prevProps, prevState) {
    let qs = this.parseQuery(this.props.location.search);
    if ((this.state.searchParams || this.state.searchParams === '') && qs.searchKey && this.state.searchParams !== qs.searchKey) {
      this.setState({ searchParams: qs.searchKey });
      const isValidTag = this.state.tags.find(({ value }) => value === qs.searchKey);
      const filterData = [...this.state.tags];
      this.props.getTagsData(qs.searchKey, '');
      if (isValidTag && Object.keys(isValidTag)) {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = tag.value === qs.searchKey;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      } else {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = false;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      }
    }

    if (!prevProps.products || !prevProps.products.length) {
      if (this.props.products[0]?.tag) {
        let tags = String(this.props.products[0]?.tag)
          .split(',')
          .map((item) => item.toLocaleLowerCase().trim());
        let ctags = [...this.state.tags].map((item) => {
          if (tags.indexOf(String(item.value).toLocaleLowerCase()) > -1) {
            item.isChecked = true;
          } else {
            item.isChecked = false;
          }
          return item;
        });

        this.setState({ ...this.state, tags: ctags, alltags: false });
      }
    }

    const payload = {
      pageName: 'yes connect|explore-path',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }

  render() {
    const { width } = this.state;
    const IsNotDesktop = width <= 1023;
    return (
      <>
        <div>
          <Header title="Explore" />
          <section id="explore">
            <Modal show={this.state.show} onHide={this.handleClose}>
              <Modal.Header className="no-border" closeButton></Modal.Header>
              <Modal.Body className="filter-coloumn">
                <h1 className="filter-heading">Filters</h1>
                <h2 className="solution-heading">Solution/Product Offered</h2>
                <Form className="solution-data">
                  <Badge className={this.state.solutionTags.length == 3 ? 'tags-colored' : 'tags'} onClick={(e) => this.handleAllCheckedMobile(e, 'solution')}>
                    All
                  </Badge>
                  {this.state.solutions.map((sol, index) => (
                    <Badge
                      className={this.state.solutionTags.includes(sol.value) ? 'tags-colored' : 'tags'}
                      onClick={(e) => this.handleCheckChildElementMobile(e, 'solution', sol.value)}
                    >
                      {sol.value}
                    </Badge>
                  ))}
                </Form>
                <h2 className="solution-heading">Tags</h2>
                <Form className="tags-solution-data">
                  <Badge className={this.state.filterTags.length == 10 ? 'tags-colored' : 'tags'} onClick={(e) => this.handleAllCheckedMobile(e, 'tags')}>
                    All
                  </Badge>
                  {this.state.tags.map((tag) => (
                    <Badge
                      className={this.state.filterTags.includes(tag.value) ? 'tags-colored' : 'tags'}
                      onClick={(e) => this.handleCheckChildElementMobile(e, 'tags', tag.value)}
                    >
                      {tag.value}
                    </Badge>
                  ))}
                </Form>
                <button className="apply-btns" onClick={() => this.handleApply('mobile')}>
                  Apply
                </button>
              </Modal.Body>
            </Modal>
            <Container fluid className="no-pad">
              {/* {IsNotDesktop && ( */}
              <Row className="select-container flex" id="searchHeader">
                {/* <Col className="select-content flex"> */}
                <Col className="select-content flex">
                  <h1 className="select-heading">Curated Solutions</h1>
                  <Dropdown>
                    <Dropdown.Toggle className="select-dropdown" id="dropdown-basic">
                      {this.state.dropValue.key}
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                      {this.state.businessSolution.map((sol, index) => (
                        <Dropdown.Item onClick={(e) => this.handleDropdown(e, sol)}>{sol.key}</Dropdown.Item>
                      ))}
                    </Dropdown.Menu>
                  </Dropdown>
                </Col>
                {IsNotDesktop ? (
                  <div>
                    {this.state.filterTags.length == 0 ? (
                      <img className="filter-icon" src="assets/icons/filter-black-36dp.svg" onClick={this.handleShow} />
                    ) : (
                      <div className="selected-filter-container">
                        <img className="filter-icon-black" src="assets/icons/filter-black-36dp.svg" onClick={this.handleShow} />
                        <Badge className="filter-tags-selected">{this.state.filterTags.length}</Badge>
                      </div>
                    )}
                  </div>
                ) : (
                  ''
                )}
              </Row>
              {/* )} */}
              <Row className="second-row">
                {IsNotDesktop ? (
                  ''
                ) : (
                  <Col className="filter-coloumn no-pad " md={2} lg={3}>
                    <h1 className="filter-heading">Filters</h1>
                    <h2 className="solution-heading">Solution/Product Offered</h2>
                    <Form className="solution-data">
                      <Form.Check className="checkboxes custom-checkbox ">
                        <Form.Check.Input
                          className="checkboxes custom-control-input"
                          id="customCheck1"
                          onClick={(e) => this.handleAllChecked(e, 'solution')}
                          checked={this.state.allchecked}
                          value="checkedall"
                        />
                        <Form.Check.Label className="custom-control-label" for="customCheck1">
                          All
                        </Form.Check.Label>
                      </Form.Check>

                      {this.state.solutions.map((sol, index) => (
                        <Form.Check className="checkboxes custom-checkbox ">
                          <Form.Check.Input
                            className="checkboxes custom-control-input"
                            id={sol.id}
                            key={sol.id}
                            onClick={(e) => this.handleCheckChildElement(e, 'solution')}
                            checked={sol.isChecked}
                            value={sol.value}
                          />
                          <Form.Check.Label className="custom-control-label" for={sol.id}>
                            {sol.value}
                          </Form.Check.Label>
                        </Form.Check>
                      ))}
                    </Form>
                    <h2 className="solution-heading">Tags</h2>
                    <Form className="tags-solution-data">
                      <Form.Check className="checkboxes custom-checkbox ">
                        <Form.Check.Input
                          className="checkboxes custom-control-input"
                          id="customCheck2"
                          onClick={(e) => this.handleAllChecked(e, 'tags')}
                          checked={this.state.alltags}
                          value="checkedall"
                        />
                        <Form.Check.Label className="custom-control-label" for="customCheck2">
                          All
                        </Form.Check.Label>
                      </Form.Check>
                      {this.state.tags.map((tag) => (
                        <Form.Check className="checkboxes custom-checkbox ">
                          <Form.Check.Input
                            className="checkboxes custom-control-input"
                            id={tag.id}
                            key={tag.id}
                            onClick={(e) => this.handleCheckChildElement(e, 'tags')}
                            checked={tag.isChecked}
                            value={tag.value}
                            // label={tag.value}
                          />
                          <Form.Check.Label className="custom-control-label" for={tag.id}>
                            {tag.value}
                          </Form.Check.Label>
                        </Form.Check>
                      ))}
                    </Form>
                    <button className="apply-btn" onClick={this.handleApply}>
                      Apply
                    </button>
                  </Col>
                )}

                <Col className="cards-container no-pad">
                  {!this.props.error && this.state.searchParams && (
                    <p className="txt-center">
                      Showing Results for: <b>{this.state.searchParams}</b>
                    </p>
                  )}
                  {this.props.error !== null ? (
                    <div className={'alert alert-danger'}>{this.props.error}</div>
                  ) : (
                    this.props.products.map((product) => (
                      <div className="Mobile-listing">
                        <h1 className="data-heading">{product.solutionName} </h1>
                        <p className="solution-desc"> {product.description}</p>

                        <Cards data={product.products} solution={product.solutionName} />
                      </div>
                    ))
                  )}
                </Col>
              </Row>
            </Container>
          </section>
          <Footer />
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  products: state.solutionsexReducer.products,
  searchParams: state.solutionsexReducer.results,
  error: state.solutionsexReducer.error,
});
const mapDispatchToProps = (dispatch) => {
  return {
    getTagsData: (data, boolean) => dispatch(getTagsData(data, boolean)),
    getSolutions: (data) => dispatch(getSolutions(data)),
    getAccountData: () => dispatch(getAccountData()),
    updateExploreList: (tags) => dispatch(updateExploreList(tags)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Explore);

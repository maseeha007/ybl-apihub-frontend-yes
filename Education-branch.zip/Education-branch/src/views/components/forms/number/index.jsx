import React, { useState, useRef } from "react";
import { Form, FormControl, InputGroup, DropdownButton, Dropdown } from 'react-bootstrap';
import classnames from 'classnames';
import './style.scss';



const Number = (props) => {
    const inputEl = useRef();
    const [state, setState] = useState({ edited: false })
    const innerFocus = () => {
        setState({ ...state, 'edited': true })
    }

    const innerBlur = () => {
        const value = inputEl.current.value
        if (value) {
            setState({ ...state, 'has-text': true, 'edited': false })
        } else {
            setState({ ...state, 'has-text': false, 'edited': false })
        }
    }

    const innerClick = () => {
        inputEl.current.focus();
        setState({ ...state, 'edited': true })
    }
  console.log("================>"+props.otpdisable)
    return (
        <div className={classnames({ "ybl-number": true, 'active': state.edited })}  >
            <InputGroup>
                <div className="relative-div">
                    <input type="password" id="otp-section" className="form-control" name={props.name} ref={inputEl} onFocus={() => { innerFocus(); }} onBlur={() => { innerBlur(); }} value={props.value}  maxLength={props.size} onChange={props.onChange} />
                    <Form.Label  ref={el => {
                        el &&
                            el.addEventListener("selectstart", (e) => {
                                e.preventDefault()
                            });
                    }}
                    onClick={() => { innerClick() }} className={classnames({ 'has-text': state['has-text'] ,'otp-disable': !props.otpdisable})}>{props.label ? props.label : ''}{props.required ? <span className="required">*</span> : null} </Form.Label>
                </div>
            </InputGroup>
            { props.error && <div className="error">{props.error}</div>}
        </div>
    );
}

export default Number;

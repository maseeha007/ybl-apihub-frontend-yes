import axios from 'axios';
import { APIURL } from '../../../env';

const fetchOverview = (id) => {
  var response = axios.get(`${window.yblDomain}/apihub` + '/explore/products/' + id + '/overviews');
  return response;
};

const fetchFeatures = (id) => {
  // debugger;
  var response = axios.get(`${window.yblDomain}/apihub` + '/explore/products/' + id + '/features');
  return response;
};
const fetchSubscribe = (payload) => {
  var name = payload.name;
  var productId = payload.productId;
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  debugger;
  var response = axios.post(
    `${window.yblDomain}/apihub` + '/subscription?productName=' + name + '&isPartnerProduct=true',
    { productId: productId, environment: '', plan: 'Gold', custId: payload.custId },
    config
  );
  return response;
};
const capitalize = (s) => {
  if (typeof s !== 'string') return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
};

const fetchSolutions = ({ payload }) => {
  var response = axios.get(
    `${window.yblDomain}/apihub` + '/explore/solutions?solutionName=' + capitalize(payload.solutionName) + '&solutionType=' + payload.solutionType
  );
  //  var response = axios.get('http://api.636018471a4e4806a6f8.southeastasia.aksapp.io/explore/solutions?solutionName=Payments&solutionType=ybl')
  return response;
};

const fetchPartnerProducts = () => {
  var config = {
    searchKey: null,
    filter: 'YESXPRESSONBOARDING',
  };
  let tagsresponse = axios.post(`${window.yblDomain}/apihub` + '/search/searchDetails', config);
  return tagsresponse;
};
export { fetchOverview, fetchFeatures, fetchSubscribe, fetchPartnerProducts };

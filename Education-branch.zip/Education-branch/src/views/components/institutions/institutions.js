import React, { PureComponent } from 'react';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import { Container, Row, Col, Form, Modal, Badge, Dropdown, Carousel } from 'react-bootstrap';
import { getSolutions, getTagsData, updateExploreList, getCategory } from './actions';
import { getAccountData } from '../account/actions';
import { getallpartners } from '../partners/action';
import PartnerBanner from '../../components/partnerbanner';
import Cards from '../cards/cards';
import ProductsCards from '../ProductsCards';

import './style.scss';
import { connect } from 'react-redux';
import { onLoadTrack, trackErrorEvent } from '../../../analytics';
import { myBusinessObj } from '../../../service/mybusiness';
// import {track} from '../../../analytics'
class Explore extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      tags: [
        { id: 4, value: 'Electronic Collection', isChecked: true },
        { id: 5, value: 'Dealer Payment Recovery', isChecked: true },
        { id: 6, value: 'Remittance', isChecked: true },
        { id: 7, value: 'Fund Transfer', isChecked: true },
        { id: 8, value: 'Bulk Transfers', isChecked: true },
        { id: 9, value: 'Benificiary Management', isChecked: true },
        // { id: 10, value: 'Bill Management', isChecked: true },
        { id: 11, value: 'Wallet Management', isChecked: true },
        { id: 12, value: 'ERP', isChecked: true },
        { id: 13, value: 'Accounting', isChecked: true },
        { id: 14, value: 'Invoice Management', isChecked: true },
        { id: 15, value: 'Payroll', isChecked: true },
        { id: 16, value: 'API Aggregator', isChecked: true },
      ],
      solutions: [
        { id: 1, value: 'YES BANK', isChecked: true },
        { id: 2, value: 'Partners', isChecked: true },
        { id: 3, value: 'Popular', isChecked: true },
      ],
      allchecked: true,
      alltags: false,
      headings: ['Account', 'Payments', 'Receivables', 'Remittances', 'Supply Chain'],
      width: window.innerWidth,
      show: false,
      dropValue: { key: 'Select', value: '' },
      allSolutions: false,
      solutionTags: [],
      filterTags: [],
      searchParams: '',
      businessSolution: myBusinessObj,
      solutionValue: 'Select',
      beyondValues: [],
    };
  }

  handleScroll = () => {
    const header = document.getElementById('searchHeader');
    const sticky = header.offsetTop;
    if (window.pageYOffset > sticky) {
      header.classList.add('sticky');
    } else {
      header.classList.remove('sticky');
    }
  };

  parseQuery(queryString) {
    var query = {};
    var pairs = (queryString[0] === '?' ? queryString.substr(1) : queryString).split('&');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split('=');
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
    }
    return query;
  }

   openLoginModal() {
    const token = localStorage.getItem('token');
    if (!token) {
       // localStorage.setItem('tab', "overview");
        this.props.openModal();
    }
}
  componentDidMount() {

    if (this.props.error) {
      trackErrorEvent({ eventName: 'search btn clicked', errorName: 'No matching product found' });
    }
    this.props.getAccountData();
    this.props.getallpartners();
    debugger;
    console.log('maseeha' + this.props.productspartner + 'maseeha');
    localStorage.removeItem('tab');
    window.addEventListener('resize', this.handleWindowSizeChange);
    // window.addEventListener('scroll', this.handleScroll);
    let qs = this.parseQuery(this.props.location.search);
    if (qs.searchKey) {
      this.setState({ searchParams: qs.searchKey });
      this.props.getTagsData(qs.searchKey, '');
    } else {
      this.props.getSolutions();
    }

    const isValidTag = this.state.tags.find(({ value }) => value === qs.searchKey);
    const filterData = [...this.state.tags];
    if (qs.searchKey) {
      if (isValidTag) {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = tag.value === qs.searchKey;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      } else {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = false;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      }
    } else {
      const selectedTags = filterData.map((tag) => {
        tag.isChecked = true;
        return tag;
      });
      this.setState({ tags: selectedTags, alltags: true });
    }

    const payload = {
      pageName: 'yes connect|explore',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
    if (this.state.beyondValues.length === 0 && localStorage.getItem('products')) {
      const products = localStorage.getItem('products');
      this.setState({ beyondValues: JSON.parse(products) });
    }
    this.props.getCategory();
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.handleWindowSizeChange);
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleWindowSizeChange = () => {
    this.setState({ width: window.innerWidth });
  };

  handleClose = () => this.setState({ show: false });
  handleShow = () => this.setState({ show: true });
  handleAllCheckedMobile = (event, field) => {
    if (field == 'solution') {
      let allcheck = [...this.state.solutionTags];
      if (allcheck.length === 3) {
        allcheck.splice(0, allcheck.length);
      } else if (allcheck.length < 3) {
        allcheck = ['YES BANK', 'Partners', 'Popular'];
      }
      this.setState(
        {
          solutionTags: allcheck,
        },
        () => console.log('this.sttae.solutionTags', this.state.solutionTags)
      );
    } else if (field == 'tags') {
      let allcheck = [...this.state.filterTags];
      if (allcheck.length === 13) {
        allcheck.splice(0, allcheck.length);
      } else if (allcheck.length < 13) {
        allcheck = [
          'Electronic Collection',
          'Dealer Payment Recovery',
          'Remittance',
          'Fund Transfer',
          'Bulk Transfers',
          'Benificiary Management',
          // 'Bill Management',
          'Wallet Management',
          'ERP',
          'Accounting',
          'Invoice Management',
          'Payroll',
          'API Aggregator',
        ];
      }
      this.setState(
        {
          filterTags: allcheck,
        },
        () => console.log('this.state.filterTags', this.state.filterTags)
      );
    }
  };
  handleAllChecked = (event, field) => {
    if (field == 'solution') {
      let temp = event.target.checked;
      let solutions = [...this.state.solutions];
      solutions.forEach((sol) => (sol.isChecked = event.target.checked));
      this.setState({
        solutions: solutions,
        allchecked: temp,
      });
      console.log('this.state.solutions', this.state.solutions);
    } else {
      let temp = event.target.checked;
      let tags = [...this.state.tags];
      tags.forEach((tag) => (tag.isChecked = event.target.checked));
      this.setState({
        tags: tags,
        alltags: temp,
      });
    }
  };
  handleCheckChildElementMobile = (event, field, value) => {
    if (field == 'solution') {
      let selected = [...this.state.solutionTags];
      if (selected.indexOf(value) !== -1) {
        selected.splice(selected.indexOf(value), 1);
      } else {
        selected.push(value);
      }
      this.setState(
        {
          solutionTags: selected,
        },
        () => {
          console.log('solutionTags', this.state.solutionTags);
          let boolean = '';
          const tagsToCheck = this.state.solutionTags;
          if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
            boolean = '';
          } else if (tagsToCheck.includes('YES BANK')) {
            boolean = true;
          } else if (tagsToCheck.includes('Partners')) {
            boolean = false;
          }
          this.props.getTagsData([...this.state.filterTags], boolean);
        }
      );
    } else if (field == 'tags') {
      let selected = [...this.state.filterTags];
      if (selected.indexOf(value) !== -1) {
        selected.splice(selected.indexOf(value), 1);
      } else {
        selected.push(value);
      }
      this.setState(
        {
          filterTags: selected,
        },
        () => {
          console.log('solutionTags', this.state.filterTags);
          let boolean = '';
          const tagsToCheck = this.state.solutionTags;
          if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
            boolean = '';
          } else if (tagsToCheck.includes('YES BANK')) {
            boolean = true;
          } else if (tagsToCheck.includes('Partners')) {
            boolean = false;
          }
          this.props.getTagsData([...this.state.filterTags], boolean);
        }
      );
    }
  };
  handleCheckChildElement = (event, field) => {
    if (field == 'solution') {
      let temp = false;
      let solutions = [...this.state.solutions];
      solutions.forEach((sol) => {
        if (sol.value === event.target.value) sol.isChecked = event.target.checked;
      });
      temp = solutions.every((sol) => {
        return sol.isChecked === true;
      });
      this.setState({
        solutions: solutions,
        allchecked: temp,
      });
    } else {
      let temp = false;
      let tags = [...this.state.tags];
      tags.forEach((tag) => {
        if (tag.value === event.target.value) tag.isChecked = event.target.checked;
      });
      temp = tags.every((tag) => {
        return tag.isChecked === true;
      });
      this.setState({
        tags: tags,
        alltags: temp,
      });
    }
  };
  handleApply = (field) => {
    if (field === 'mobile') {
      let tagsToCheck = [...this.state.solutionTags];
      let tagsToSend = [...this.state.filterTags];
      console.log('check', tagsToSend, tagsToCheck);
      let boolean = '';
      if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
        boolean = '';
      } else if (tagsToCheck.includes('YES BANK')) {
        boolean = true;
      } else if (tagsToCheck.includes('Partners')) {
        boolean = false;
      }
      this.props.getTagsData(tagsToSend, boolean);
      this.handleClose();
      // if (tagsToSend.length === 1) {
      //   this.setState({ searchParams: tagsToSend[0] })
      // } else {
      //   this.setState({ searchParams: "" })
      // }
    } else {
      let tagsToCheck = [];
      let tagsToSend = [];
      let boolean = '';
      this.state.solutions.forEach((sol, index) => {
        if (sol.isChecked) {
          tagsToCheck.push(sol.value);
        }
      });
      this.state.tags.forEach((tag, index) => {
        if (tag.isChecked) {
          tagsToSend.push(tag.value);
        }
      });
      if (tagsToCheck.includes('YES BANK') && tagsToCheck.includes('Partners')) {
        boolean = '';
      } else if (tagsToCheck.includes('YES BANK')) {
        boolean = true;
      } else if (tagsToCheck.includes('Partners')) {
        boolean = false;
      }
      this.props.getTagsData(tagsToSend, boolean);
    }
  };
  handleDropdown = (e, sol) => {
    debugger;
    e.preventDefault();
    this.setState(
      {
        dropValue: sol,
      },
      () => console.log('dropvalue', this.state.dropValue)
    );
    this.props.updateExploreList(sol.value);
  };
  handleBeyondSolution = (e, sol) => {
    debugger;
    e.preventDefault();
    this.setState(
      {
        solutionValue: sol,
      },
      () => console.log('dropvalue', this.state.solutionValue)
    );
    this.props.updateExploreList(sol);
  };
  componentDidUpdate(prevProps, prevState) {
    let qs = this.parseQuery(this.props.location.search);
    if ((this.state.searchParams || this.state.searchParams === '') && qs.searchKey && this.state.searchParams !== qs.searchKey) {
      this.setState({ searchParams: qs.searchKey });
      const isValidTag = this.state.tags.find(({ value }) => value === qs.searchKey);
      const filterData = [...this.state.tags];
      this.props.getTagsData(qs.searchKey, '');
      if (isValidTag && Object.keys(isValidTag)) {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = tag.value === qs.searchKey;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      } else {
        const selectedTags = filterData.map((tag) => {
          tag.isChecked = false;
          return tag;
        });
        this.setState({ tags: selectedTags, alltags: false });
      }
    }
  }
  resetExplore() {
    this.props.getSolutions();
  }

  render() {
    debugger;
    let dataslider = this.props?.products?.map((item, i) => {
      return (
        <>
          {item.products?.map((patnerdata, index) => {
            //if (patnerdata?.digiOnboard) {
            return <>
              <Carousel.Item interval={3000} className="item">
                <img
                  className=" img-fluid"
                  src={'/assets/img/' + String(patnerdata?.productName).toLowerCase().replace(/\s/g, '-') + '-logo.svg'}
                  alt="Image One" height='60px' />
              </Carousel.Item >
            </>
            // }
          })
          }
        </>
      )
    })

    console.log('===========>', this.props.beyondlist);
    debugger;

    const { width } = this.state;
    const IsNotDesktop = width <= 1023;
    const isYBLProduct = this.props.products.filter((product) => product.brand !== 'Partner');
    return (
      <>
        <div>
          <Header title="education" />

          <section id="institutions" >
            <div className='explorebanner'>
              <div className="container">
                <div className="banner-container">
                  <h2 className="banner-heading">EDU Connect for Educational Institution</h2>
                  <h2 className="banner-heading"><b>Transition to an innovative, digital campus with an ease</b></h2>
                </div>
              </div>
            </div>




            <div className='container Solutioningcon'>
              <div className='row '>
                <div className='col-sm-12 text-center'>
                  <h2 className='mb-4'>About Edu Connect</h2>
                  <p className='para'>Imagine if the institution’s technological platform & infrastructures are stitched seamlessly with the banking channels for secure communication that results in a more intuitive experience that plays a role in </p>

                  <img src='/assets/explore/cerclemangment.jpg' className='img-fluid imgbox' />
                </div>
              </div>
            </div>
            <div className='container '>
            <div className='row '>
                <div className='col-sm'>
                <img src='/assets/explore/razorpaylogo.png' className='img-fluid logopartner'  />
                </div>
                <div className='col-sm'>
                <img src='/assets/explore/xomiclogo.png' className='img-fluid logopartner'  />
                </div>
                <div className='col-sm'>
                <img src='/assets/explore/cashfreelogo.png' className='img-fluid logopartner'  />
                </div>
                <div className='col-sm'>
                <img src='/assets/explore/zohologo.png' className='img-fluid logopartner'  />
                </div>
                <div className='col-sm'>
                <img src='/assets/explore/easebuzzlogo.png' className='img-fluid logopartner'  />
                </div>
                <div className='col-sm'>
                <img src='/assets/explore/payulogo.png' className='img-fluid logopartner'  />
                </div>
                </div>
              </div>

            <div className='container '>
              <Carousel id="" className='row d-none' nextIcon={<span aria-hidden="true" className="carousel-control-icon" />}
                      prevIcon={<span aria-hidden="true" className="carousel-control-icon rotate180" />}  >
                {dataslider}
              </Carousel>
              <div className='row Transition-inno'>
                <div className='col-sm-12 text-center'>
                  <h2> Customized Superior Solution to address the need of</h2>
                </div>
                <div className='col-sm-4'>
                  <div className="card" >
                    <img className="card-img-top" src="/assets/explore/school.jpg" alt="Card image cap" />
                    <div className="card-body">
                      <h5 className="card-title">Smart School Solutioning</h5>
                      {/* <p className="card-text">We believe that School campuses are epicenter of activities, for that reason, leveraging on smart campus solutioning would enhance experience of Students, Parents, Teachers & Vendors.</p> */}
                      <a href="/school-detail" className="btn btn-primary">EXPLORE NOW</a>
                    </div>
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className="card" >
                    <img className="card-img-top" src="/assets/explore/collage.jpg" alt="Card image cap" />
                    <div className="card-body">
                      <h5 className="card-title">Smart College Solutioning</h5>
                      {/* <p className="card-text">Complete college management solution which automates campus operations and also provides application fo Admins, Teachers & Parents.</p> */}
                      <a href="/institution-detail" className="btn btn-primary">EXPLORE NOW</a>
                    </div>
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className="card" >
                    <img className="card-img-top" src="/assets/explore/univercity.jpg" alt="Card image cap" />
                    <div className="card-body">
                      <h5 className="card-title">Smart University Solutioning</h5>
                      {/* <p className="card-text">Smart Campus initiative is a tailor-made banking suite exclisively designed to enable transition to Innovative, Digital campus with ease.</p> */}
                      <a href="/universities-detail" className="btn btn-primary">EXPLORE NOW</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className='container-fluid aboutinstitut'>
              <div className='container'>
                <div className='row '>
                  <div className='col-sm-12 text-center'>
                    <h2>What Institutes are Saying About us</h2>
                  </div>

                  <div className='col-sm-12'>
                    <Carousel
                      nextIcon={<span aria-hidden="true" className="carousel-control-icon" />}
                      prevIcon={<span aria-hidden="true" className="carousel-control-icon rotate180" />}
                    >
                      <Carousel.Item  className="item">
                        <div className="item-wrap row">
                          <div className="col-sm-12" >
                            <div className="card" >
                              <div className="card-body">
                                <p className="card-text">API integrated digital fee collection solution provided by Yes Bank Limited has enhanced management control with auto reconciliation, and enriching transactional experience of students across the campus and our affiliated colleges
                                </p>
                                <h5 className="card-title">Aurangabad University</h5>
                                <span className='profes'>Dr Babasaheb Ambedkar Marathwada University- BAMU</span>
                              </div>
                            </div>
                          </div>
                          {/* <div className="col-sm-6" >
                            <div className="card" >
                              <div className="card-body">
                                <p className="card-text">Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed hendrerit tempor enim a ultrices. Conubia nostra, per inceptos himenaeos. Sed hendrerit tempor enim a ultrices
                                </p>
                                <h5 className="card-title">Aditya Pratap Singh</h5>
                                <span className='profes'>Vice-Principal, Delhi University</span>
                              </div>
                            </div>
                          </div> */}
                        </div>
                      </Carousel.Item>
                      {/* <Carousel.Item interval={3000} className="item">
                      <div className="item-wrap row">
                          <div className="col-sm-6" >
                            <div className="card" >
                              <div className="card-body">
                                <p className="card-text">API integrated digital fee collection solution provided by Yes Bank Limited has enhanced management control with auto reconciliation, and enriching transactional experience of students across the campus and our affiliated colleges
                                </p>
                                <h5 className="card-title">Aurangabad University</h5>
                                <span className='profes'>Dr Babasaheb Ambedkar Marathwada University- BAMU</span>
                              </div>
                            </div>
                          </div>
                          <div className="col-sm-6" >
                            <div className="card" >
                              <div className="card-body">
                                <p className="card-text">Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed hendrerit tempor enim a ultrices. Conubia nostra, per inceptos himenaeos. Sed hendrerit tempor enim a ultrices
                                </p>
                                <h5 className="card-title">Aditya Pratap Singh</h5>
                                <span className='profes'>Vice-Principal, Delhi University</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Carousel.Item> */}
                      
                    </Carousel>
                  </div>
                </div>
              </div>

            </div>

            <div className='container bannerinstit'>
            <PartnerBanner checkLogin={this.openLoginModal.bind()} />
            </div>


          </section>
          <Footer />
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  //products: state.solutionsReducer.products,
  searchParams: state.searchReducer.results,
  error: state.solutionsReducer.error,
  beyondlist: state.solutionsReducer.beyondlist,
  products: state.partnersReducer.products,
});
const mapDispatchToProps = (dispatch) => {
  return {
    getTagsData: (data, boolean) => dispatch(getTagsData(data, boolean)),
    getSolutions: () => dispatch(getSolutions()),
    getAccountData: () => dispatch(getAccountData()),
    getallpartners: () => dispatch(getallpartners()),
    updateExploreList: (tags) => dispatch(updateExploreList(tags)),
    getCategory: () => dispatch(getCategory()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Explore);

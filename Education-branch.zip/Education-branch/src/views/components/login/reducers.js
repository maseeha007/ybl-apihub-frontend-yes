const reducer = (
  state = {
    errorMsg: '',
    otp_data: {},
    otpstatus: false,
    gotOTP: false,
    showOtp: false,
    loginApiStatus: false,
    sendOtpLoader: false,
    loginbtnLoader: false,
    verifyNumber: false,
    errorType: '',
    phoneNumber: '',
    resendOtpLink: false,
    user_data: {},
    pcode: '91',
  },
  action
) => {
  switch (action.type) {
    case 'DISABLE_OTP':
      return { ...state, gotOTP: false };
    case 'LOGIN_VERIFY_OTP':
      return { ...state, verifyNumber: true };
    case 'ServerError':
      return { ...state, errorMsg: action.payload };
    case 'GET_MOBILE_OTP':
      return { ...state, loading: true };
    case 'OTP_RECEIVED':
      return { ...state, otp_data: action.payload };
    case 'LOGIN_ERROR_TYPE':
      return { ...state, errorType: action.payload };
    case 'MOBILE_NUMBER':
      return { ...state, phoneNumber: action.payload };
    case 'RESEND_OTP_LINK_ACTIVE':
      return { ...state, resendOtpLink: action.payload };
    case 'OTP':
      return { ...state, otp: action.payload };
    case 'GOT_OTP':
      return { ...state, gotOTP: true, user_data: action.payload };
    case 'SHOW_TIMER':
      return { ...state, showOtp: action.payload };
    case 'SEND_OTP_LOADER':
      return { ...state, sendOtpLoader: action.payload };
    case 'LOGIN_BTN_LOADER':
      return { ...state, loginbtnLoader: action.payload };
    case 'PHONE_CODE':
      return { ...state, pcode: action.payload };
    case 'TOO_MANY_ATEMPTS':
      return { ...state, errorMsg: 'Too Many Attempts! Please Wait for 10 Minutes' };
    case 'ADID_VERIFED':
      return { ...state, msg: action.payload };
    case 'PSM_LOADER':
      return { ...state, psmLoader: action.payload };
    case 'CUSTOMER_CAPTCHA':
      return { ...state, customerCaptcha: action.payload };
    case 'PSM_CAPTCHA':
      return { ...state, psmCaptcha: action.payload };
    default:
      return state;
  }
};
export default reducer;

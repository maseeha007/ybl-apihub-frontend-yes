import React, { Component } from 'react';
//import YBL_SCHOOL_ADMINISTRATIVE from '../images/ybls-school-administrative.svg';
//import CHECK_OPTION from '../images/check.png';
//import PHONE_SVG from '../images/phone.svg';
//import NEXT_ICON from '../images/next-icon.svg';
//import PREV_ICON from '../images/prev-icon.svg';
import Slider from "react-slick";
import { Alert, Button, CardGroup, Card} from 'react-bootstrap';

import './style.scss';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';

const NextArrow = (props) => {
  const { className, onClick } = props;
  return (
    <div
      className={className}
      onClick={onClick}
    >
        <img src={'/assets/img/aboutright.svg'} alt="next" />
    </div>
  );
}

const PrevArrow = (props) => {
  const { className, onClick } = props;
  return (
    <div
      className={className}
      onClick={onClick}
    >
        <img src={'/assets/img/aboutleft.svg'} alt="prev" />
    </div>
  );
}


const YblSchoolPage = () => {

    let count = 1;
    const settings = {
        dots: false,
        arrows: true,
        infinite: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 6,
        nextArrow: <NextArrow />,
        prevArrow: <PrevArrow />,
    };

    const YBL_SCHOOL_DATA = {
        YBL_SCHOOL_INSTRUCTIONS: [
            {
                icon: '',
                description: 'Be Compliant: Get real time downloadable UDISE+ Format Reports for License Renewal & Audit.',
            },
            {
                icon: '',
                description: 'A la carte of Academic & Administrative Modules',
            },
            {
                icon: '',
                description: 'Dashboard: For Efficient School Budget / Fund Management of all the branches.',
            },
            {
                icon: '',
                description: 'Comprehensive Fee Collection : Multiple Payment Channels : NEFT/RTGS, IMPS, UPI, NACH, BBPS, Cash & Cheque, with Regular Alerts',
            },
            {
                icon: '',
                description: 'Education Financing Option Available for the parents',
            },
            {
                icon: '',
                description: 'Industry Best TASC Savings Account Interest Rates',
            }
        ],
        YBL_SCHOOL_CUSTOMIZED:[
            {
                icon: '',
                description: 'Online Free Payment',
            },
            {
                icon: '',
                description: 'School Bus Tracking',
            },
            {
                icon: '',
                description: 'Homework',
            },
            {
                icon: '',
                description: 'Timetable',
            },
            {
                icon: '',
                description: 'Reports',
            },
            {
                icon: '',
                description: 'Purchase Alerts',
            }
        ],
        SLIDER_CARD: [
            {
                title: 'Student Admissions',
            },
            {
                title: 'School Management',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'School Management',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'Student Admissions',
            },
            {
                title: 'Student Admissions',
            }
        ]
    };
    
    return (
      <div><Header title="institution-detail" />

<section id="institutions" >
            <div className='explorebanner'>
              <div className="container">
                <div className="banner-container">
                  <h2 className="banner-heading">EDU Connect for Schools </h2>
                  <h2 className="banner-heading"><b>Transition to an innovative, digital campus with an ease</b></h2>
                </div>
              </div>
            </div>

            <div className='container Solutioningcon'>
              <div className='row align-items-center'>
                <div className='col-sm-12 text-center'>
                  <h2 className='mb-4'>Smart Campus Solutions for Colleges</h2>
                  <p className='para'>EDU Connect facilitates banking & beyond banking services that uses networked technologies to facilitate receivables, payments, communication with enhanced security. </p>
                  <h4>Key Advantages for your institution</h4>

                </div>


                <div className='col-sm-6 '>
                  <img src='/assets/explore/School-section.svg' className='img-fluid imgbox mt-5' />

                </div>
                <div className='col-sm-6 '>
                  <div class="content advantage">
                    <ul>
                      {/* <li><span><b>Be Compliant:</b></span><p>Get real time downloadable Format Reports for License Renewal & Audit.</p></li>
                      <li><span><b>Data-driven decision-making:</b></span><p>Access to interactive visualized dashboards with multi-level snapshots highlighting critical insights.</p></li>
                      <li><span><b>Enhanced management control:</b></span><p>A comprehensive Accounting, Reconciliation & Transaction Hub to manage your budgets, government grants & fund utilization.</p></li>
                      <li><span><b>Enriching transactional experience:</b></span><p>Validates student fee details instantly, offers multiple payment modes for fee payment, and automatically updates your ERP through API Banking.</p></li> */}


                      {
                            YBL_SCHOOL_DATA.YBL_SCHOOL_INSTRUCTIONS.map((item, index) => (

                              <li><p>{item.description}</p></li>
                                
                        ))
                        }
                    </ul>
                  </div>

                </div>
                <div className='col-sm-12 text-center explore-btn-container '>
                <a href="/explore-listing" className="explore-btn btn btn-primary">EXPLORE NOW</a>
                  </div>
                  <section className="ybl-school-section-2 mt-5">
                <div className="header-container text-center">
                    <h1 className="ybl-school-title mb-3">
                        Connects entire student life cycle management
                    </h1>
                </div>
                <div className="ybl-school-sliders container pt-2 pb-5">
                    <Slider {...settings}>
                        { 
                            YBL_SCHOOL_DATA.SLIDER_CARD.map((el, index) => {
                                return (<div className={`slider-card slider-card-${count > 6 ? count = 1 : count++}`} key={index + 1}>
                                    <div className="slider-header">
                                        <h3>{index < 9 ? `0 ${index + 1}` : index}</h3>
                                    </div>
                                    <div className="slider-content">
                                        <p>
                                            {el.title}
                                        </p>
                                    </div>
                                </div>
                                )
                            })
                        }
                    </Slider>
                </div>
            </section>

               
                <section className="ybl-school-section-3 container">
                <div className="header-container pt-5 text-center">
                    <h1 className="ybl-school-title mb-3">
                        Yes Bank Offers a Customized Mobile App for Parents with key features
                    </h1>
                </div>
                <div className="ybl-school-content">
                    <div className="ybl-school-img">
                        <img src={'/assets/explore/mobile.svg'} alt='school administrative' />
                    </div>
                    <div className="ybl-school-wrapper">
                        {
                            YBL_SCHOOL_DATA.YBL_SCHOOL_CUSTOMIZED.map((item, index) => (
                                <div className="ybl-school-list-instructions" key={index}>
                                    <Alert key='' className="ybl-school-instructions">
                                        <div className="ybl-school-icon">
                                            <img src={'/assets/explore/right.svg'} alt='check option' />
                                        </div>
                                        <div className="ybl-school-description">
                                            {item.description}
                                        </div>
                                    </Alert>
                                </div>
                        ))
                        }
                    </div>    
                </div>
                <div className="explore-btn-container text-center mt-5 mb-5">
                    <Button
                        variant="primary"
                        className="explore-btn"
                    >
                        Explore Now
                    </Button>
                </div>
            </section>
               
              </div>
            </div>
            <div className='container-fluid SmartCampus'>
              <div className='container'>
                <div className="row" >
                  <div className="col-sm-12 text-center" >
                    <h2>Explore Our Smart Campus Products</h2>
                  </div>
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/Bill-Management-HP.svg' alt="" />
                        <Card.Title className="scard-title">Digital Campus</Card.Title>
                        <Card.Text className="scard-text">Is a co-created holistic solution that can handle the entire gamut of on-campus and off-campus activities in a School, College or University which can be delivered modular or as a totally customized Campus Management Suite with Integrated Banking Channels</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/Payment-HP.svg' alt="" />
                        <Card.Title className="scard-title">Cashless Campus</Card.Title>
                        <Card.Text className="scard-text">Is a smart card-based proposition for Students which would be a ID Card with student records & also card which enables access and contactless payments on the campus. Institutes can also issue co-branded expense management cards for staff & admin to track & control the expenses.</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/Receivables-HP.svg' alt="" />
                        <Card.Title className="scard-title">Fee Management</Card.Title>
                        <Card.Text className="scard-text">Is a robust fee collections system enabling offline economy to shift from paper to digital collections. It reduces 90% of the manual reconciliation effort in fees collection. Get reports and detailed Statistics on payments, manage your settlements, refunds and much more right from one single dashboard</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                  <div className="d-sm-block col-sm-3" >
                    <Card className="solutionCard ">
                      <Card.Body className="no-pad">
                        <img className="oval" src='assets/Hp-icons/account-HP.svg' alt="" />
                        <Card.Title className="scard-title">Fund Management</Card.Title>
                        <Card.Text className="scard-text">Is a secure hassle-free payments solutioning for wide range of transactional experience. Get reports and detailed Statistics on Budget allocation, government grants, fund utilization, vendor payments, salary disbursal and much more right from one single dashboard</Card.Text>
                        <a href="/explore-listing" className="btn btn-primary">EXPLORE NOW</a>
                      </Card.Body>
                    </Card>
                  </div >
                </div>
              </div>
            </div>

            

          </section>
        
        <Footer />
        </div>
  )
    
}

export default YblSchoolPage;

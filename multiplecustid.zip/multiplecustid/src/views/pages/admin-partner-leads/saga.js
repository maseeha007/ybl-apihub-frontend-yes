import { all, takeEvery, put } from 'redux-saga/effects';

import {
  PARTNER_FETCH_SUBSCRIPTION,
  PARTNER_FETCH_SUBSCRIPTION_SUCCESS,
  PARTNER_FETCH_SUBSCRIPTION_FAIL,
  PARTNER_ACCEPT_SUBSCRIPTION,
  PARTNER_ACCEPT_SUBSCRIPTION_SUCCESS,
  PARTNER_ACCEPT_SUBSCRIPTION_FAIL,
  PARTNER_DECLINE_SUBSCRIPTION,
  PARTNER_DECLINE_SUBSCRIPTION_SUCCESS,
  PARTNER_DECLINE_SUBSCRIPTION_FAIL,
  DOWNLOAD_PARTNER_RECORDS,
} from './constant';
import { get_subscription, accept_subscription, decline_subscription, downloadPartner_subscription } from './apis';
import YearView from 'react-calendar/dist/umd/YearView';

export function* fetchSubscriptionAsync({ payload }) {
  try {
    const token = localStorage.getItem('adminToken');
    let { data } = yield get_subscription(payload, token);
    if (data.statusType != 'SUCCESS') {
      yield put({ type: PARTNER_FETCH_SUBSCRIPTION_FAIL, data: data?.message });
    } else {
      yield put({ type: PARTNER_FETCH_SUBSCRIPTION_SUCCESS, data });
    }
  } catch (err) {
    yield put({ type: 'NETWORK ERROR' });
    if (err?.response?.data?.error === 'Unauthorized' || err.response.status === 401) {
      localStorage.setItem('AdminAccess', 'No');
      window.location.href = `${window.location.origin}/admins`;
    }
  }
}

export function* acceptSubscriptionAsync(payload) {
  try {
    const token = localStorage.getItem('adminToken');
    let { data } = yield accept_subscription(payload, token);
    if (data.statusType != 'SUCCESS') {
      yield put({ type: PARTNER_ACCEPT_SUBSCRIPTION_FAIL, data: data?.message });
    } else {
      yield put({ type: PARTNER_ACCEPT_SUBSCRIPTION_SUCCESS, data });
    }
  } catch (err) {
    yield put({ type: 'NETWORK ERROR' });
    if (err?.response?.data?.error === 'Unauthorized' || err.response.status === 401) {
      localStorage.setItem('AdminAccess', 'No');
      window.location.href = `${window.location.origin}/admins`;
    }
  }
}

export function* declineSubscriptionAsync(payload) {
  try {
    const token = localStorage.getItem('adminToken');
    let { data } = yield decline_subscription(payload, token);
    if (data.statusType != 'SUCCESS') {
      yield put({ type: PARTNER_DECLINE_SUBSCRIPTION_FAIL, data: data?.message });
    } else {
      yield put({ type: PARTNER_DECLINE_SUBSCRIPTION_SUCCESS, data });
    }
  } catch (err) {
    if (err?.response?.data?.error === 'Unauthorized' || err.response.status === 401) {
      localStorage.setItem('AdminAccess', 'No');
      window.location.href = `${window.location.origin}/admins`;
    }
    yield put({ type: 'NETWORK ERROR' });
  }
}

export function* downloadPartner_subscriptionAsync(payload) {
  try {
    const { data } = yield downloadPartner_subscription(payload);
    if (data.statusType === 'FAIL') {
      console.log('NO downloading');
    } else {
      console.log('downloading done');
    }
  } catch (err) {
    yield put({ type: 'Network Error' });
  }
}

export default function* watchAll() {
  yield all([
    takeEvery(PARTNER_FETCH_SUBSCRIPTION, fetchSubscriptionAsync),
    takeEvery(PARTNER_ACCEPT_SUBSCRIPTION, acceptSubscriptionAsync),
    takeEvery(PARTNER_DECLINE_SUBSCRIPTION, declineSubscriptionAsync),
    takeEvery(DOWNLOAD_PARTNER_RECORDS, downloadPartner_subscriptionAsync),
  ]);
}

export  const GET_OVERVIEW = 'GET_OVERVIEW';
export const GET_OVERVIEW_DATA = 'GET_OVERVIEW_DATA';

export const GET_FEATURES_DATA = 'GET_FEATURES_DATA';
export const GET_FEATURES = 'GET_FEATURES';

export const GET_API_VERSION = 'GET_API_VERSION';
export const GET_API_VERSION_DATA = 'GET_API_VERSION_DATA';

export const GET_API_DEF = 'GET_API_DEF';
export const GET_API_DEF_DATA = 'GET_API_DEF_DATA';

export const SET_TAB = "SET_TAB";


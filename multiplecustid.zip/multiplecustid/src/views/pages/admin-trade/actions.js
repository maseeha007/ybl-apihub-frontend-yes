import { FETCH_TRADE, ACCEPT_TRADE, DECLINE_TRADE } from './constant';

export const get_trade = (payload) => ({
  type: FETCH_TRADE,
  payload: payload,
});

// export const accept_lead = (payload) => ({
//   type: ACCEPT_LEAD,
//   payload: payload
// })

// export const decline_lead = (payload) => ({
//   type: DECLINE_LEAD,
//   payload: payload
// })

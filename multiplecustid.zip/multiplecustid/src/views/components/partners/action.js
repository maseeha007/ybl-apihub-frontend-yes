import {

  P_CHECK_SUBSCRIBE,
  P_NON_CA_EMAIL,
  P_VERIFY_CA_START,
  P_SENDOTPFORPARTENR,
  P_SEND_OTP_FORPARTENR_LOADER,
  P_VERIFYOTPAPIASYC,
  P_CHECK_SUBSCRIBE_FAILURE,
  P_GET_PARTNER_SUBSCRIBTION,
  P_GET_ALLPARTNER,
  P_RESETSUBSCRIED_MODULE
  
} from './constant';


// export const getOverview = (id) => ({
//   type: P_GET_OVERVIEW,
//   payload: id,
// });
// export const getFeatures = (id) => ({
//   type: P_GET_FEATURES,
//   payload: id,
// });


export const getallpartners = () => ({
  type: P_GET_ALLPARTNER,
  
});
export const resetmodaledata = () => ({
  type: P_RESETSUBSCRIED_MODULE,
  
});



export const checkSubscribe = (payload) => ({
  type: P_CHECK_SUBSCRIBE,
  payload: payload,
});

export const sentEmailForNonCA = (payload) => ({
  type: P_NON_CA_EMAIL,
  payload: payload,
});
export const verifyCa = (payload) => ({
  type: P_VERIFY_CA_START,
  payload: payload,
});

export const sendOtpCAUser = (custId) => ({
  type: P_SENDOTPFORPARTENR,
  payload: custId,
});
export const sendOtpLoaderAction = (status) => ({
  type: P_SEND_OTP_FORPARTENR_LOADER,
  data: status,
});

export const verifyOtp = (otp) => ({
  type: P_VERIFYOTPAPIASYC,
  payload: otp,
});

export const setError = (msg) => ({
  type: P_CHECK_SUBSCRIBE_FAILURE,
  error_message: msg,
});

export const subscribeAction = (id, token) => ({
  type: P_GET_PARTNER_SUBSCRIBTION,
  payload: { id, token },
});

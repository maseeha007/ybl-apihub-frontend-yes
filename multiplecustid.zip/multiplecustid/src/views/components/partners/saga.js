import { all, call, put, takeEvery, takeLatest, select } from 'redux-saga/effects';
import { fetchOverview, fetchFeatures, fetchSubscribe,fetchPartnerProducts } from './api';
import {
  P_GET_PRODUCTS_SUCCESS, P_GET_PRODUCTS_FAILURE, P_GET_ALLPARTNER,
  P_CHECK_SUBSCRIBE,
  P_CHECK_SUBSCRIBE_FAILURE,
  P_CHECK_SUBSCRIBE_SUCCESS,
  P_NON_CA_EMAIL,
  P_VERIFY_CA_SUCCESS,
  P_VERIFY_CA_FAIL,
  P_VERIFY_CA_START,
  P_PARTNER_LOADER,
  P_CA_LOADER,
  P_SENDOTPFORPARTENR,
  P_SEND_OTP_FORPARTENR_LOADER,
  P_SEND_OTP_SUCCESS,
  PS_VERIFY_OTP_STATUS,
  PS_VERIFY_OTP_SUCCESS,
  P_VERIFYOTPAPIASYC,
  P_VERIFY_OTP_LOADER,
  P_GET_PARTNER_SUBSCRIBTION,
} from './constant';
import { validCAUserOnRegistration, sendYBLOTP, verifyYBLOTPAPI } from '../../../service/otpAPI';
import { sendEmailToUser, subscribeAPI } from '../../../service/subscribeAPI';

export function* VerifyUserAsync({ payload }) {
  let custId = payload.custId;
  try {
    let { data, headers } = yield validCAUserOnRegistration(custId);
    localStorage.setItem('sessionId', headers['sessionid']);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
      res.custId = custId;
      res.encrptPhone = res.mobile;
      res.encrptemailId = res.emailId;
      res.mobile = res.mobile;
      res.randomval = new Date().getMilliseconds();

      yield put({ type: P_PARTNER_CUST_USER_SUCCESS, data: res });
      yield put({ type: P_PARTNER_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'YES');
    }
    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: P_VERIFY_USER_FAIL, data: 'Please Enter Valid Cust ID' });
      yield put({ type: P_PARTNER_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'NO');
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
    // TODO
    // yield put({ type: VERIFY_CA_FAIL, data: { result: 'Backend service is unavailable' } });
    yield put({ type: P_PARTNER_CUST_ID_LOADER, payload: false });
    localStorage.setItem('CaVerifed', 'NO');
  }
}

// export function* GetOverviewAsync({ payload }) {
//   try {
//     const data = yield call(fetchOverview.bind(this, payload));
//     if (data.data.statusType == 'SUCCESS') {
//       debugger;
//       yield put({ type: P_GET_OVERVIEW_SUCCESS, data: data.data.response });
//     } else {
//       yield put({
//         type: P_GET_OVERVIEW_FAILURE,
//         error_message: data.data.message ? data.data.message : 'No Products Found',
//       });
//     }
//   } catch (error) {
//     yield put({
//       type: P_GET_OVERVIEW_FAILURE,
//       error_message: 'Some Network Problem Occured',
//     });
//   }
// }

// export function* GetFeaturesAsync({ payload }) {
//   try {
//     // debugger;
//     const data = yield call(fetchFeatures.bind(this, payload));
//     if (data.data.statusType == 'SUCCESS') {
//       yield put({ type: P_GET_FEATURE_SUCCESS, data: data.data.response });
//     } else {
//       yield put({
//         type: P_GET_FEATURE_FAILURE,
//         error_message: data.data.message ? data.data.message : 'No Products Found',
//       });
//     }
//   } catch (error) {
//     yield put({
//       type: P_GET_FEATURE_FAILURE,
//       error_message: 'Some Network Problem Occured',
//     });
//   }
// }
export function* GetTagsDataAsync({ payload }) {
  try {
    const data = yield call(fetchPartnerProducts);
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: P_GET_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: P_GET_PRODUCTS_FAILURE,
        error_message: 'No matching product found.',
      });
      trackErrorEvent({ eventName: 'search btn clicked', errorName: `No matching product found` });
    }
  } catch (error) {
    yield put({
      type: P_GET_PRODUCTS_FAILURE,
      error_message: 'No matching products found.',
    });
    trackErrorEvent({ eventName: 'search btn clicked', errorName: `No matching product found` });
  }
}


export function* SubscribeAsync({ payload }) {
  try {
    yield put({ type: P_PARTNER_LOADER, data: true });
    const data = yield call(fetchSubscribe.bind(this, payload));
    if (data.data.statusCode === 200) {
      yield put({ type: P_CHECK_SUBSCRIBE_SUCCESS, data: data.data });
    } else {
      yield put({
        type: P_CHECK_SUBSCRIBE_FAILURE,
        error_message: data.data.statusMessage ? data.data.statusMessage : 'Some Error Occured',
      });
    }
    yield put({ type: P_PARTNER_LOADER, data: false });
  } catch (error) {
    yield put({
      type: P_CHECK_SUBSCRIBE_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if ('Unauthorized' === error?.response?.data?.error && token) {
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      // localStorage.setItem("userLogin","NO")
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      yield put({ type: P_PARTNER_LOADER, data: false });

      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    }
  }
}

export function* sendNonCA(payload) {
  const data = sendEmailToUser('partnerProductRedirect', payload.payload);
}

export function* verifyCaAsync({ payload }) {
  let custId = payload;
  yield put({ type: P_CA_LOADER, data: true });

  try {
    let { data, headers } = yield validCAUserOnRegistration(custId);
    localStorage.setItem('sessionId', headers['sessionid']);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
      res.custId = custId;
      res.encrptPhone = res.mobile;
      res.encrptemailId = res.emailId;
      res.mobile = res.mobile;
      res.randomval = new Date().getMilliseconds();
      if (res.responseCode != '0') {
        yield put({ type: P_VERIFY_CA_FAIL, data: 'Please Enter Valid Cust ID' });
      } else {
        yield put({ type: P_VERIFY_CA_SUCCESS, data: res });
        // yield put({ type: 'SEND_OTP_STATUS', data: true });
      }
    }

    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: P_VERIFY_CA_FAIL, data: 'Please Enter Valid Cust ID' });
    }
    yield put({ type: P_CA_LOADER, data: false });
  } catch {
    yield put({ type: 'NETWORK ERROR' });
    yield put({ type: P_CA_LOADER, data: false });

    yield put({ type: P_VERIFY_CA_FAIL, data: { result: 'Backend service is unavailable' } });
  }
}

export function* sendOtpForPartner({ payload }) {
  debugger;
  const sendotppayload = {
    isCaUser: true,
    custId: payload,
  };

  try {
    debugger;
    const data = yield sendYBLOTP(sendotppayload)
      .then((res) => {
        if (res.headers['sessionid']) {
          localStorage.setItem('sessionId', res.headers['sessionid']);
        }
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });

    if (data.statusType === 'FAIL') {
      yield put({ type: P_CHECK_SUBSCRIBE_FAILURE, data: data.statusMessage });
    }
    if (data.statusType === 'REQUEST IS NOT APPROPRIATE') {
      yield put({ type: P_CHECK_SUBSCRIBE_FAILURE, data: data.statusType });
    }

    if (data.statusType === 'SUCCESS') {
      const res = { ...data };
      yield put({ type: 'P_SEND_OTP_STATUS', data: true });
      yield put({ type: P_SEND_OTP_SUCCESS, data: res });
      yield put({ type: P_VERIFY_CA_SUCCESS, data: { result: data.statusMessage } });
    }
  } catch (err) {
    console.log(err);
    yield put({ type: P_CHECK_SUBSCRIBE_FAILURE, data: 'Unable to connect to YES BANK API' });
  }
  yield put({ type: P_SEND_OTP_FORPARTENR_LOADER, payload: false });
}

export function* verifyOtpAsync({ payload }) {
  debugger;
  try {
    const state = yield select();
    const reqPayload = {
      otpValue: payload,
      isCaUser: true,
    };

    const data = yield verifyYBLOTPAPI(reqPayload)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    if (data.statusType === 'SUCCESS') {
      if (data.response.mobile && data.response.emailId) {
        yield put({ type: PS_VERIFY_OTP_SUCCESS, data: 'Otp Verified' });
        yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
        yield put({ type: PS_VERIFY_OTP_STATUS, data: 'success' });
        yield put({ type: P_VERIFY_CA_SUCCESS, data: data.response });
        yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
        localStorage.setItem('CaVerifed', 'YES');
      } else {
      }
    }
    if (data.statusType === 'FAIL') {
      yield put({ type: PS_VERIFY_OTP_STATUS, data: 'fail' });
      yield put({ type: 'P_CHECK_SUBSCRIBE_FAILURE', data: data.statusMessage });
      yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
    }
  } catch (e) {
    yield put({ type: PS_VERIFY_OTP_STATUS, data: 'fail' });
    // yield put({ type: 'NETWORK ERROR' });
    yield put({ type: 'P_CHECK_SUBSCRIBE_FAILURE', data: 'Invalid Otp' });
    yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
  }
}

export function* getSubscrible({ payload }) {
  // debugger;
  try {
    // debugger;
    const data = yield subscribeAPI(payload?.id, payload?.token)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data.httpCode : e.message;
        return errorObj;
      });
    debugger;
    if (data?.statusType === 'SUCCESS') {
      yield put({ type: 'P_SET_SUBSCRIBE_DATA', payload: data?.response?.isSubscribed });
    }
    if (data?.statusType === 'FAIL') {
      yield put({ type: 'P_SET_SUBSCRIBE_DATA', payload: false });
    }
  } catch (e) {
    yield put({ type: 'P_SET_SUBSCRIBE_DATA', payload: false });
    const token = localStorage.getItem('token');
    if ('Unauthorized' === e?.response?.data?.error && token) {
      localStorage.setItem('userLogin', 'NO');
    }
  }
}
export default function* watchAll() {
  yield all([
    takeLatest(P_CHECK_SUBSCRIBE, SubscribeAsync),
    takeLatest(P_NON_CA_EMAIL, sendNonCA),
    takeLatest(P_VERIFY_CA_START, verifyCaAsync),
    takeLatest(P_VERIFYOTPAPIASYC, verifyOtpAsync),
    takeLatest(P_SENDOTPFORPARTENR, sendOtpForPartner),
    takeLatest(P_GET_PARTNER_SUBSCRIBTION, getSubscrible),
    takeLatest(P_GET_ALLPARTNER, GetTagsDataAsync),
    
  ]);
  
}

import {SAVE_TRADE_DATA,SAVE_TRADE_FAIL,
  TRADE_VERIFY_OTP_LOADER,TRADE_SEND_OTP_LOADER,
  GET_CITY_SOLUTION, GET_TRADE_ACCOUNT_DETAILS,
  VERIFY_TRADE_OTP,SEND_TRADE_OTP,LOAD_TRADE_PAGE
  
 
} from './constant';

debugger
export const saveTrade_Action = (user) =>({
  
    type: SAVE_TRADE_DATA,
    payload: { user }
  })
  export const loadTradePage = () => ({
    type :LOAD_TRADE_PAGE
  })

  export const clearError = (data) => ({
    type: SAVE_TRADE_FAIL,
    payload:  { data: data.response }
  })
//product data action
  // export const getSolutions = () => ({
  //   type: GET_SOLUTIONS,
  // });

  //get city data action
  export const getCitydata = (data) => ({
    type: GET_CITY_SOLUTION,
    payload: { data }
  });

  //account action
  export const getAccountData = () => ({
    type: GET_TRADE_ACCOUNT_DETAILS,
  });
//verify otp
  // export const verify_user = (custId) => ({
  //   type: VERIFY_USER,
  //   payload: { custId }
  // })
  
  export const verify_otp = (otp) => ({
    type: VERIFY_TRADE_OTP,
    payload: { otp }
  })
  
  
  export const send_otp = (data) => ({
    type: SEND_TRADE_OTP,
    payload: { emailId : data.emailId,mobile:data.mobile}
  })

  export const sendOtpLoaderAction = (value) => ({
    type: TRADE_SEND_OTP_LOADER,
    payload: value
  })
  export const verifyOtpLoaderAction = (value)  =>({
    type:TRADE_VERIFY_OTP_LOADER,
    payload:value
  })
  // export const verfyCustIdLoaderAction = (value) => ({
  //   type:REG_CUST_ID_LOADER,
  //   payload:value
  // })
  
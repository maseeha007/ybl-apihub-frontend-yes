import React, { useState } from 'react';
import { Container, Row, Col, Carousel, Modal } from 'react-bootstrap';
import { onLoadTrack } from '../../../analytics';

import './style.scss';

export default () => {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const cardData = [
    { title: 'Account', data: 'Allows you to transfer funds and get transfer status instantly' },
    { title: 'Bill Management', data: 'Allows you to transfer funds and get transfer status instantly' },
    { title: 'Payment', data: 'Allows you to transfer funds and get transfer status instantly' },
    { title: 'Receivables', data: 'Allows you to transfer funds and get transfer status instantly.' },
  ];
  const payload = {
    pageName: 'yes connect|testimonials',
    loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
    userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
    userId: localStorage.getItem('userId'),
  };
  onLoadTrack(payload);

  const partnerData = ['Payroll', 'ERP', 'CRM', 'E-Collect'];

  return (
    <section id="testimonials">
      <Modal className="videoModal" size={'xl'} show={show} onHide={handleClose}>
        <Modal.Header className="no-border" closeButton></Modal.Header>
        <Modal.Body>
          <iframe
            className="videoframe"
            width="100%"
            src="https://www.youtube.com/embed/mwD5t0hiLVc"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
          ></iframe>
        </Modal.Body>
      </Modal>
      <Container>
        <h1 className="title text-center"> Things you can do with our Solutions</h1>
        {/* <Carousel className="test-group" controls={false} interval={10000}>
          <Carousel.Item> */}
        <Row>
          <Col md={4}>
            <img className="videothumb" src="/assets/img/videothumb.png" frameborder="0" allowfullscreen onClick={handleShow}></img>
          </Col>
          <Col md={8}>
            {/* <h3 className="subtitle">Video Testimonial headings</h3> */}

            <div className="test-list">
              <span>
                <img src="/assets/img/check.png" alt="checkicon" className="checkicon" />{' '}
                <p>Bank from your ERP. Initiate and reconcile all your payables & receivables in your own systems.</p>{' '}
              </span>
              <span>
                <img src="/assets/img/check.png" alt="checkicon" className="checkicon" />{' '}
                <p> 100+ APIs to digitize all your banking needs encompassing payables, receivables & supply chain. </p>
              </span>
              <span>
                <img src="/assets/img/check.png" alt="checkicon" className="checkicon" />{' '}
                <p>Robust infrastructure capable of handling high volume transactions like ecommerce refunds, merchant settlements etc.</p>{' '}
              </span>
              <span>
                <img src="/assets/img/check.png" alt="checkicon" className="checkicon" />{' '}
                <p>State-of-the-Art security and encryption to protect your transactions and information. </p>
              </span>
              <span>
                <img src="/assets/img/check.png" alt="checkicon" className="checkicon" />{' '}
                <p>Dedicated implementation team and helpdesk for seamless integration and post implementation support.</p>
              </span>
              <span>
                <img src="/assets/img/check.png" alt="checkicon" className="checkicon" />
                <p> Winner for multiple international awards for innovation in banking.</p>
              </span>
            </div>
          </Col>
        </Row>
        {/* </Carousel.Item> 
        </Carousel> */}
      </Container>
    </section>
  );
};

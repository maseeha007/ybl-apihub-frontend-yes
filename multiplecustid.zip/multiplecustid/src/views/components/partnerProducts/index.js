import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Row, Col, Container, Card, Button, Modal } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import { getpartnerProducts, updatePartner } from './action';
import { getAccountData } from '../account/actions';
import Input from '../forms/input';
import { connect } from 'react-redux';
import './style.scss';
import { loginModalStatus } from '../../layout/header/action';
import { globalClickEvent, onLoadTrack } from '../../../analytics';
class Index extends Component {
  constructor(props) {
    super(props);

    this.state = {
      openPopup: false,
      details: {},
      error: {},
      showlogin: false,
    };
  }
  componentDidMount() {
    this.props.getpartnerProducts();
    this.props.getAccountData();
    const payload = {
      pageName: 'yes connect|partner product',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }
  componentDidUpdate() {
    if (this.props.updateLogin == 1 && this.state.partnerUpdated !== true) {
      setTimeout(() => {
        this.setState({ ...this.state, partnerUpdated: true, openPopup: false });
      }, 2000);
    }
  }
  saveValue(name, e) {
    let value = e.target.value;
    if (name === 'solname' || name === 'desc') {
      value = e.target.value.replace(/[^a-z0-9 ]/gi, '');
    }
    this.setState({ ...this.state, details: { ...this.state.details, [name]: value } });
  }
  handleLogin() {
    let flag = false;
    let errObj = {};
    let dataObj = {};

    if (!this.state.details.solname) {
      errObj['solname'] = 'Please Enter Product/Solution';
      document.getElementById('solname').focus();
      flag = true;
    } else {
      dataObj['solname'] = this.state.details.solname;
      errObj['solname'] = '';
    }

    if (!this.state.details.desc) {
      errObj['desc'] = 'Please Enter description';
      if (!flag) {
        document.getElementById('desc').focus();
      }
      flag = true;
    } else {
      dataObj['desc'] = this.state.details.desc;
      errObj['desc'] = '';
    }
    if (flag) {
      this.setState({ ...this.state, error: { ...errObj } });
      return;
    } else {
      let userObj = {
        custId: this.props.accountValues.custId,
        firstName: this.props.accountValues.firstName,
        lastName: this.props.accountValues.lastName,
        emailId: this.props.accountValues.emailId,
        isEnabled: this.props.accountValues.isEnabled,
        mobile: this.props.accountValues.mobile,
        organisation: this.props.accountValues.organisation,
        partnerOptIn: true,
        solutionName: dataObj.solname,
        productDescription: dataObj.desc,
        leadgenStatus: this.props.accountValues.leadgenStatus,
      };
      this.props.updatePartner(userObj);
      setTimeout(function () {
        window.location.reload();
      }, 5000);
    }
  }

  handleClose = () => {
    this.setState({ ...this.state, error: { solname: '' }, openPopup: false });
  };
  handleOpen() {
    globalClickEvent(`button clicked login`);
    this.setState({ ...this.state, openPopup: true });
  }
  handleOpenLogin() {
    globalClickEvent('button clicked login');
    this.props.openModal();
  }
  handleCloseLogin = () => {
    this.setState({ ...this.state, showlogin: false });
  };
  movetoPartnerPage = (url, name) => {
    globalClickEvent(`link clicked  partners page ${name}`);
    window.location.href = url;
  };
  render() {
    return (
      <>
        <Header title="Partner" />
        <section id="partnerDetails">
          <div className="partner-banner">
            <h2 className="heading">
              <span>Partners </span>{' '}
            </h2>
          </div>
          <div className="main-section container1">
            {this.props.partnerProducts.map((data) => (
              <>
                {data.products.map((product) => (
                  <div className="card-section">
                    <Link
                      onClick={this.movetoPartnerPage.bind(
                        this,
                        `/partnerdetails?id=${product.productId}&name=${product.productName}&solname=${data.solutionName.replace('&', '~')}`,
                        product.productName
                      )}
                      // to={'/partnerdetails?id=' + product.productId + '&name=' + product.productName + '&solname=' + data.solutionName.replace('&', '~')}
                      alt="partnerDetails"
                    >
                      <Card className="solutionCard">
                        <Card.Body className="no-pad">
                          <Card.Title className="scard-title">{product.productName}</Card.Title>
                          <img
                            className="oval"
                            src={'/assets/img/' + String(product.productName).toLowerCase().replace(/\s/g, '-') + '-logo.svg'}
                            alt="No logo"
                          />
                          <Card.Text className="scard-text">{product.description}</Card.Text>
                        </Card.Body>
                      </Card>
                    </Link>
                  </div>
                ))}
              </>
            ))}
          </div>
          <div>
            {!localStorage.token ? (
              <div className="footer-container">
                <h1 className="become-partner" onClick={this.handleOpenLogin.bind(this)}>
                  <span>Become a Partner</span>
                </h1>
                <p className="become-partner-content">
                  Grab the opportunity to collaborate with YES BANK to develop customized solutions for enhanced customer experience. Showcase your solutions on
                  YES Connect to co-create innovative solutions for the Bank’s customers.
                </p>
                <Button className="register-now-button" onClick={this.handleOpenLogin.bind(this)}>
                  Become a Partner
                </Button>
              </div>
            ) : (!this.props.accountValues.productDescription || this.props.accountValues.productDescription === null) &&
              (!this.props.accountValues.solutionName || this.props.accountValues.solutionName === null) ? (
              <div className="footer-container">
                <h1 className="become-partner" onClick={this.handleOpen.bind(this)}>
                  <span>Become a Partner</span>
                </h1>
                <p className="become-partner-content">
                  Grab the opportunity to collaborate with YES BANK to develop customized solutions for enhanced customer experience. Showcase your solutions on
                  YES Connect to co-create innovative solutions for the Bank’s customers.
                </p>
                <Button className="register-now-button" onClick={this.handleOpen.bind(this)}>
                  Become a Partner
                </Button>
              </div>
            ) : (
              ''
            )}
          </div>
        </section>

        <Modal className={'loginModal'} show={this.state.openPopup} onHide={this.handleClose.bind(this)}>
          <Modal.Header className="login-header">
            Become a Partner
            <button type="button" class="close">
              <span aria-hidden="true">
                <img alt="icon" className="close-icon" src="/assets/icons/login-close.svg" onClick={this.handleClose.bind(this)} />
              </span>
              <span class="sr-only">Close</span>
            </button>
          </Modal.Header>
          <Modal.Body>
            <div className="text-section">
              {this.props.updateLogin > 1 ? (
                <>
                  <div className={'alert alert-primary'}>Thank you for choosing to partner with us. Our Team will be in touch with you for more details.</div>
                </>
              ) : (
                ''
              )}
              <Input
                label={'Product/Solution Name'}
                maxlength="35"
                onChange={this.saveValue.bind(this, 'solname')}
                value={this.state.details.solname}
                defaultValue={this.state.details.solname}
                id="solname"
                error={this.state.error.solname}
                required
                name="solname"
              />
              {/* <Input id="fname" label={'First Name'} maxlength="35" error={this.state.error.fname} value={this.state.user.fname} onChange={this.saveValue.bind(this, 'fname')} required defaultValue={this.state.user.fname} name="fname" /> */}
            </div>
            <div className="text-section">
              <Input
                label={'Short description'}
                maxlength="300"
                onChange={this.saveValue.bind(this, 'desc')}
                id="desc"
                value={this.state.details.desc}
                error={this.state.error.desc}
                required
                name="desc"
                defaultValue={this.state.details.desc}
              />
            </div>
            <div className="action-section">
              <Button className="submit-btn" variant="primary" onClick={this.handleLogin.bind(this)}>
                Become a Partner
              </Button>
              <Button className="cancel-btn" variant="default" onClick={this.handleClose.bind(this)}>
                Cancel
              </Button>
            </div>
          </Modal.Body>
        </Modal>
        <Footer />
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  accountValues: state.accountReducer.accountDetails,
  partnerProducts: state.partnerReducer.Partnerproducts,
  updateLogin: state.partnerReducer.updatePartner,
  error_update: state.partnerReducer.error_update,
});
const mapDispatchToProps = (dispatch) => {
  return {
    getpartnerProducts: () => dispatch(getpartnerProducts()),
    getAccountData: () => dispatch(getAccountData()),
    updatePartner: (obj) => dispatch(updatePartner(obj)),
    openModal: () => dispatch(loginModalStatus(true)),
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));

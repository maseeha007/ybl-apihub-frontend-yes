import {
  GET_ACCOUNT_SUCCESS,
  GET_ACCOUNT_FAILURE,
  UPDATE_MY_ACCOUNT_LOADER,
  CUSTID_UPDATE_SUCCESS,
  CUSTID_UPDATE_ERROR,
  CUST_ID,
  CLEAR_MYACCOUNT_DATA,
  SET_MYACCOUNT_DATA,
  MYACCOUNT_SEND_OTP_STATUS,
  MYACCOUNT_SEND_OTP_SUCCESS,
  MYACCOUNT_VERIFY_OTP_SUCCESS,
  MYACCOUNT_SEND_OTP_LOADER,
  MYACCOUNT_VERIFY_OTP_STATUS,
  MYACCOUNT_VERIFY_OTP_LOADER,
  MYACCOUNT_VERIFY_CUST_SUCCESS,
  MYACCOUNT_CUSTID_LOADER,
  MYACCOUNT_CAPTCHA,
  MYACCOUNT_CUSTIDS,
} from './constant';

const initialState = {
  accountDetails: [],
  error: null,
};

const accountReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_ACCOUNT_SUCCESS:
      return { ...state, accountDetails: action.data, error: null };
    case GET_ACCOUNT_FAILURE:
      return { ...state, error: action.error_message };
    case UPDATE_MY_ACCOUNT_LOADER:
      return { ...state, updateLoader: action.data };
    case CUSTID_UPDATE_SUCCESS:
      return { ...state, msg: 'Cust Id Updated Successfully' };
    case CUSTID_UPDATE_ERROR:
      return { ...state, errormsg: action.data ? action.data : 'Cust Id is not updated' };
    case CUST_ID:
      return { ...state, custId: action.data };
    case CLEAR_MYACCOUNT_DATA:
      return { ...state, msg: '', errormsg: '', accountDetails: {} };
    case SET_MYACCOUNT_DATA:
      debugger;
      return { ...state, verified_user: action.data };
    case MYACCOUNT_SEND_OTP_LOADER:
      return { ...state, sendOtpLoader: action.payload };
    case MYACCOUNT_SEND_OTP_STATUS:
      debugger;
      return { ...state, isOtpSent: action.payload };
    case MYACCOUNT_VERIFY_OTP_LOADER:
      debugger;
      return { ...state, verifyOtpLoader: action.payload };
    case MYACCOUNT_VERIFY_OTP_STATUS:
      return { ...state, otpStatus: action.data };
    case MYACCOUNT_VERIFY_OTP_SUCCESS:
      return { ...state, otp_success_msg: action.data };
    case MYACCOUNT_SEND_OTP_SUCCESS:
      return { ...state, send_otp_state: 'success', send_otp_data: action.data };
    case MYACCOUNT_CUSTID_LOADER:
      return { ...state, custIdLoader: action.payload };
    case MYACCOUNT_CAPTCHA:
      return { ...state, captcha: action.payload };
    case MYACCOUNT_CUSTIDS:
      debugger;
      return { ...state, custIds: action.data };
    default:
      return state;
  }
};

export default accountReducer;

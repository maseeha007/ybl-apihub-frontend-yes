import React from "react";
import { Carousel } from 'react-bootstrap';
import { Container } from 'react-bootstrap';
import ReactWOW from 'react-wow'
import './style.scss';

const SucessStories = () => {

    return (
        <section id="successStories">
            <Container>
                <div className="text-center">
                    <h3 className="title"> Success Stories</h3>
                    <Carousel
                        nextIcon={<span aria-hidden="true" className="carousel-control-icon" />}
                        prevIcon={<span aria-hidden="true" className="carousel-control-icon rotate180" />}
                    >
                        <Carousel.Item interval={10000} className="item">
                            <div className="item-wrap">
                                <div className="image-wrapper">
                                    <img
                                        className="d-block ss-image"
                                        src="/assets/success-story/S-Story-Phonepe.svg"
                                        alt="First slide"
                                    />
                                </div>
                                <div className="text-wrapper">
                                    <div className="item-logo">
                                        {/* <h2>mjunction</h2> */}

                                        <img src="/assets/success-story/myjunction.svg" alt="company logo" />
                                    </div>
                                    <div className="item-content">
                                        <div className="item-heading">API Digital environment of YBL has helped us in reducing our transaction processing time by almost 80%. This drastic improvement in TAT has translated into better customer satisfaction, which in turn has led to more Channel Finance usage through our platform. API Support team of YBL was very helpful throughout this journey of designing, developing, configuring and customizing the API as per the unique business requirement of mjunction.</div>
                                        <div className="item-subsection">
                                            {/* <p>
                                                PhonePe has integrated YES BANK’s UPI APIs which allows its users to link their bank accounts securely to their smart phone. Once linked, users can authorize money transfers or merchant payments instantly by simply entering their 4-6 digit MPIN. Funds are instantly transferred directly from the sender’s bank account to the recipient’s bank account. There’s no need to enter an OTP to authorize a transaction anymore. A transaction takes less than 10 seconds to complete.
                                    </p> */}
                                            {/* <p>
                                                PhonePe has integrated YES BANK's UPI APIs which allows its users to link their bank accounts securely to their smart phone using NPCI’s encrypted libraries. Once linked, users can authorize money transfers or merchant payments instantly by simply entering their 4-6 digit MPIN. Money is instantly transferred directly from the sender’s bank account to the recipient’s bank account. There’s no need to enter an OTP to authorize a transaction anymore. A transaction takes less than 10 seconds to complete.
                                    </p> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Carousel.Item>
                        <Carousel.Item interval={100000} className="item">
                            <div className="item-wrap">
                                <div className="image-wrapper">
                                    <img
                                        className="d-block ss-image"
                                        src="/assets/success-story/S-Story-paisa-bazaar.svg"
                                        alt="First slide"
                                    />

                                </div>
                                <div className="text-wrapper">
                                    <div className="item-logo">
                                        {/* <h2>PayNearby</h2> */}

                                        <img src="/assets/success-story/paynearby.svg" alt="company logo" />
                                    </div>
                                    <div className="item-content">
                                        <div className="item-heading">
                                            Our partnership with YES Bank has helped us fructify PayNearby’s vision of transporting high-end technology to the last mile. For financial services to permeate into the hinterlands of the country, building customer trust and confidence is a must. Providing the highest level of success rate whilst ensuring privacy and security is a huge commitment that cannot be fulfilled without a strong partner. YES Bank’s secure, backend technology and stable network has helped us to valiantly explore and expand new horizons in our financial inclusion journey while reaching out to the masses. </div>
                                        <div className="item-subsection">
                                            {/* <p> This API based lending model is first-of-its-kind wherein Paisabazaar.com platform is integrated directly with the Bank’s core processing systems to deliver superior customer experiences. YES BANK is one of the few financial institutions to have built this capability along with Paisabazaar.com for their customers.
                                            </p> */}
                                            <div className="sign">
                                                <span>Anand Kumar Bajaj</span>
                                                <span>Founder, MD & CEO, PayNearby</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Carousel.Item>
                        <Carousel.Item interval={1000} className="item">
                            <div className="item-wrap">
                                <div className="image-wrapper">
                                    <img
                                        className="d-block ss-image"
                                        src="/assets/success-story/S-Story-hike.svg"
                                        alt="First slide"
                                    />
                                </div>
                                <div className="text-wrapper">
                                    <div className="item-logo">
                                        <img src="/assets/success-story/phonepe.svg" alt="company logo" />
                                        {/* <h2>PhonePe</h2> */}

                                    </div>
                                    <div className="item-content">
                                        <div className="item-heading">
                                            PhonePe has deeply partnered with YES Bank over the last 5 years utilising their API Banking suite which has helped us process payouts to millions of merchants and consumers across varied use cases. Yes bank systems are reliable and can scale well to manage volumes. They have always been forthcoming in providing innovative solutions to address our business needs in an efficient and seamless manner. We look forward to a continued partnership with YES Bank”
                                        </div>
                                        <div className="item-subsection">
                                            {/* <p>
                                                This was the first time in India that a large mobile chat platform had embedded UPI payment capabilities. The UPI integration had been done on the back of YES BANK’s state-of-the-art API Banking platform. Through this integration, Hike customers were able to make Person-to-person (P2P) payments by linking their bank account number to YES BANK’s Virtual Payment Address (VPA). This VPA enables customers to send or receive payments without having to share their Bank A/c or IFSC code details.
                                    </p> */}
                                            <div className="sign">
                                                <span>Hemant Gala</span>
                                                <span>Head - Financial Services, Payments and Banking at PhonePe</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Carousel.Item>
                        <Carousel.Item interval={10000} className="item">
                            <div className="item-wrap">
                                <div className="image-wrapper">

                                    <img
                                        className="d-block ss-image"
                                        src="/assets/success-story/S-Story-WU.svg"
                                        alt="First slide"
                                    />
                                </div>
                                <div className="text-wrapper">
                                    <div className="item-logo">
                                        {/* <h2>Rewire</h2> */}

                                        <img src="/assets/success-story/rewire.svg" alt="company logo" />
                                    </div>
                                    <div className="item-content">
                                        <div className="item-heading">

                                            YES Bank’s API-based solution enables Rewire customers to seamlessly remit money to their families who reside in developing countries. We’ve been working with Yes Bank for some time now and could not have been happier with their professional and attentive service. The fast delivery time along with immediate response time in case an order does not follow through is impeccable.
                                        </div>
                                        <div className="item-subsection">
                                            {/* <p>
                                                This direct-to-bank payment integration facilitated instant money transfers through YES BANK’s RTGS, IMPS as well as NEFT payment systems. With this integration, Western Union customers in the US, UK, Canada, Australia and many other countries were be able to send money directly to bank accounts in India.
                                    </p> */}

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Carousel.Item>
                        {/* <Carousel.Item interval={10000} className="item">
                            <div className="item-wrap">
                                <div className="image-wrapper">
                                    <img
                                        className="d-block ss-image"
                                        src="/assets/success-story/S-Story-myntra.svg"
                                        alt="First slide"
                                    />
                                </div>
                                <div className="text-wrapper">
                                    <div className="item-logo">
                                        <img src="/assets/success-story/myntra-logo.svg" alt="company logo" />
                                    </div>
                                    <div className="item-content ">
                                        <div className="item-heading">Myntra launched an instant refund service to provide customers seamless refunds for their returns that leveraged YES BANK’s payments APIs </div>
                                        <div className="item-subsection">
                                            <p>
                                            This was made possible by integrating Myntra’s customer management system (CMS) with the Bank’s IMPS APIs to enable instant refund processing.
                                    </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Carousel.Item> */}
                        {/* <Carousel.Item interval={10000} className="item">
                            <div className="item-wrap">
                                <div className="image-wrapper">
                                    <img
                                        className="d-block ss-image"
                                        src="/assets/success-story/S-Story-OLA.svg"
                                        alt="First slide"
                                    />
                                </div>
                                <div className="text-wrapper">
                                    <div className="item-logo">
                                   <h2>OLA </h2>

                                        {/* <img src="/assets/success-story/ola-cabs-logo.svg" alt="company logo" /> */}
                        {/* </div>
                                    <div className="item-content">
                                        <div className="item-heading">YES BANK’s fund transfer APIs enabled Ola to seamlessly settle driver commissions. </div>
                                        <div className="item-subsection">
                                            <p>
                                            Ola Cabs leveraged IMPS via the Bank’s APIs to make driver commissions payouts directly to bank accounts of drivers. This integration enabled Ola to settle the amount to be paid to drivers, with real-time reconciliation, directly from their ride management system.
                                    </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Carousel.Item> */}
                        {/* <Carousel.Item interval={10000} className="item"> 
                            <div className="item-wrap">
                                <div className="image-wrapper">
                                    <img
                                        className="d-block ss-image"
                                        src="/assets/success-story/S-Story-mahadiscom.svg"
                                        alt="First slide"
                                    /> */}
                        {/* <h2>Mahadiscom</h2> */}

                        {/* </div>
                                <div className="text-wrapper">
                                    <div className="item-logo_1"> */}
                        {/* <img src="/assets/success-story/Mahadiscom-logo.svg" alt="company logo" /> */}
                        {/* <h2>Mahadiscom</h2>

                                    </div>
                                    <div className="item-content m-top">
                                        <div className="item-heading">
                                            Mahadiscom leverages YES BANK’s E-Collect API to efficiently manage high tension consumer receivables.
                                             </div>
                                        <div className="item-subsection">
                                            <p>
                                            This API integration instantly notifies Mahadiscom’s ERP about each electronic inward credit into its account to instantly update the payment and payee details.
                                    </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
    </Carousel.Item>  */}
                    </Carousel>
                </div>
            </Container>
        </section>
    );
}

export default SucessStories;

import { data } from 'autoprefixer';
import {
  GET_OVERVIEW_SUCCESS,
  GET_OVERVIEW_FAILURE,
  GET_FEATURE_SUCCESS,
  GET_FEATURE_FAILURE,
  CHECK_SUBSCRIBE_SUCCESS,
  CHECK_SUBSCRIBE_FAILURE,
  VERIFY_CA_SUCCESS,
  VERIFY_CA_FAIL,
  PARTNER_LOADER,
  CA_LOADER,
  SEND_OTP_FORPARTENR_LOADER,
  SEND_OTP_SUCCESS,
  SEND_OTP_STATUS,
  P_VERIFY_OTP_LOADER,
  P_VERIFY_OTP_STATUS,
  P_VERIFY_OTP_SUCCESS,
  SET_SUBSCRIBE_DATA,
} from './constant';

const initialState = {
  overview: [],
  features: [],
  error: null,
  checksubscribe: [],
  sendOtpLoader: false,
};

const partnerProductReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_OVERVIEW_SUCCESS:
      return { ...state, overview: action.data, error: null };
    case GET_OVERVIEW_FAILURE:
      return {
        ...state,
        error: action.error_message ? action.error_message : 'No Product available',
      };
    case GET_FEATURE_SUCCESS:
      return { ...state, features: action.data, error: null };
    case GET_FEATURE_FAILURE:
      return {
        ...state,
        error: action.error_message ? action.error_message : 'No Product available',
      };

    case CHECK_SUBSCRIBE_SUCCESS:
      return { ...state, checksubscribe: action.data, error: null };
    case CHECK_SUBSCRIBE_FAILURE:
      return {
        ...state,
        error: action.error_message,
      };

    case VERIFY_CA_SUCCESS:
      return { ...state, verify_user_state: 'success', verified_message: 'CustId verifed', verified_user: action.data, random: Math.random() };
    case VERIFY_CA_FAIL:
      return { ...state, verify_user_state: 'fail', verified_message: action.data };
    case PARTNER_LOADER:
      return { ...state, parterLoader: action.data };
    case CA_LOADER:
      return { ...state, caLoader: action.data };
    case SEND_OTP_FORPARTENR_LOADER:
      return { ...state, sendOtpLoader: action.data };
    case SEND_OTP_SUCCESS:
      return { ...state, send_otp_state: 'success', send_otp_data: action.data };
    case SEND_OTP_STATUS:
      return { ...state, sendOTPStatus: action.data };
    case P_VERIFY_OTP_LOADER:
      return { ...state, verifyotpLoder: action.data };
    case P_VERIFY_OTP_STATUS:
      return { ...state, otp_verify_state: action.data };
    case P_VERIFY_OTP_SUCCESS:
      return { ...state, otp_text_msg: action.data };
    case SET_SUBSCRIBE_DATA:
      return { ...state, isSubscribed: action.payload };
    default:
      return state;
  }
};

export default partnerProductReducer;

import { all, call, put, takeEvery, takeLatest, select } from 'redux-saga/effects';
import { fetchOverview, fetchFeatures, fetchSubscribe } from './api';
import {
  GET_OVERVIEW_SUCCESS,
  GET_OVERVIEW_FAILURE,
  GET_FEATURE_SUCCESS,
  GET_FEATURE_FAILURE,
  GET_FEATURES,
  GET_OVERVIEW,
  CHECK_SUBSCRIBE,
  CHECK_SUBSCRIBE_FAILURE,
  CHECK_SUBSCRIBE_SUCCESS,
  NON_CA_EMAIL,
  VERIFY_CA_SUCCESS,
  VERIFY_CA_FAIL,
  VERIFY_CA_START,
  PARTNER_LOADER,
  CA_LOADER,
  SENDOTPFORPARTENR,
  SEND_OTP_FORPARTENR_LOADER,
  SEND_OTP_SUCCESS,
  P_VERIFY_OTP_STATUS,
  P_VERIFY_OTP_SUCCESS,
  VERIFYOTPAPIASYC,
  P_VERIFY_OTP_LOADER,
  GET_PARTNER_SUBSCRIBTION,
} from './constant';
import { validCAUserOnRegistration, sendYBLOTP, verifyYBLOTPAPI } from '../../../service/otpAPI';
import { sendEmailToUser, subscribeAPI } from '../../../service/subscribeAPI';

export function* VerifyUserAsync({ payload }) {
  let custId = payload.custId;
  try {
    let { data, headers } = yield validCAUserOnRegistration(custId);
    localStorage.setItem('sessionId', headers['sessionid']);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
      res.custId = custId;
      res.encrptPhone = res.mobile;
      res.encrptemailId = res.emailId;
      res.mobile = res.mobile;
      res.randomval = new Date().getMilliseconds();

      yield put({ type: PARTNER_CUST_USER_SUCCESS, data: res });
      yield put({ type: PARTNER_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'YES');
    }
    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: VERIFY_USER_FAIL, data: 'Please Enter Valid Cust ID' });
      yield put({ type: PARTNER_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'NO');
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
    // TODO
    // yield put({ type: VERIFY_CA_FAIL, data: { result: 'Backend service is unavailable' } });
    yield put({ type: PARTNER_CUST_ID_LOADER, payload: false });
    localStorage.setItem('CaVerifed', 'NO');
  }
}

export function* GetOverviewAsync({ payload }) {
  try {
    const data = yield call(fetchOverview.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      debugger;
      yield put({ type: GET_OVERVIEW_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_OVERVIEW_FAILURE,
        error_message: data.data.message ? data.data.message : 'No Products Found',
      });
    }
  } catch (error) {
    yield put({
      type: GET_OVERVIEW_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
  }
}

export function* GetFeaturesAsync({ payload }) {
  try {
    // debugger;
    const data = yield call(fetchFeatures.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_FEATURE_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_FEATURE_FAILURE,
        error_message: data.data.message ? data.data.message : 'No Products Found',
      });
    }
  } catch (error) {
    yield put({
      type: GET_FEATURE_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
  }
}
export function* SubscribeAsync({ payload }) {
  try {
    yield put({ type: PARTNER_LOADER, data: true });
    const data = yield call(fetchSubscribe.bind(this, payload));
    if (data.data.statusCode === 200) {
      yield put({ type: CHECK_SUBSCRIBE_SUCCESS, data: data.data });
    } else {
      yield put({
        type: CHECK_SUBSCRIBE_FAILURE,
        error_message: data.data.statusMessage ? data.data.statusMessage : 'Some Error Occured',
      });
    }
    yield put({ type: PARTNER_LOADER, data: false });
  } catch (error) {
    yield put({
      type: CHECK_SUBSCRIBE_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if ('Unauthorized' === error?.response?.data?.error && token) {
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      // localStorage.setItem("userLogin","NO")
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      yield put({ type: PARTNER_LOADER, data: false });

      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    }
  }
}

export function* sendNonCA(payload) {
  const data = sendEmailToUser('partnerProductRedirect', payload.payload);
}

export function* verifyCaAsync({ payload }) {
  let custId = payload;
  yield put({ type: CA_LOADER, data: true });

  try {
    let { data, headers } = yield validCAUserOnRegistration(custId);
    localStorage.setItem('sessionId', headers['sessionid']);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
      res.custId = custId;
      res.encrptPhone = res.mobile;
      res.encrptemailId = res.emailId;
      res.mobile = res.mobile;
      res.randomval = new Date().getMilliseconds();
      if (res.responseCode != '0') {
        yield put({ type: VERIFY_CA_FAIL, data: 'Please Enter Valid Cust ID' });
      } else {
        yield put({ type: VERIFY_CA_SUCCESS, data: res });
        // yield put({ type: 'SEND_OTP_STATUS', data: true });
      }
    }

    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: VERIFY_CA_FAIL, data: 'Please Enter Valid Cust ID' });
    }
    yield put({ type: CA_LOADER, data: false });
  } catch {
    yield put({ type: 'NETWORK ERROR' });
    yield put({ type: CA_LOADER, data: false });

    yield put({ type: VERIFY_CA_FAIL, data: { result: 'Backend service is unavailable' } });
  }
}

export function* sendOtpForPartner({ payload }) {
  debugger;
  const sendotppayload = {
    isCaUser: true,
    custId: payload,
  };

  try {
    debugger;
    const data = yield sendYBLOTP(sendotppayload)
      .then((res) => {
        if (res.headers['sessionid']) {
          localStorage.setItem('sessionId', res.headers['sessionid']);
        }
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });

    if (data.statusType === 'FAIL') {
      yield put({ type: CHECK_SUBSCRIBE_FAILURE, data: data.statusMessage });
    }
    if (data.statusType === 'REQUEST IS NOT APPROPRIATE') {
      yield put({ type: CHECK_SUBSCRIBE_FAILURE, data: data.statusType });
    }

    if (data.statusType === 'SUCCESS') {
      const res = { ...data };
      yield put({ type: 'SEND_OTP_STATUS', data: true });
      yield put({ type: SEND_OTP_SUCCESS, data: res });
      yield put({ type: VERIFY_CA_SUCCESS, data: { result: data.statusMessage } });
    }
  } catch (err) {
    console.log(err);
    yield put({ type: CHECK_SUBSCRIBE_FAILURE, data: 'Unable to connect to YES BANK API' });
  }
  yield put({ type: SEND_OTP_FORPARTENR_LOADER, payload: false });
}

export function* verifyOtpAsync({ payload }) {
  debugger;
  try {
    const state = yield select();
    const reqPayload = {
      otpValue: payload,
      isCaUser: true,
    };

    const data = yield verifyYBLOTPAPI(reqPayload)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    if (data.statusType === 'SUCCESS') {
      if (data.response.mobile && data.response.emailId) {
        yield put({ type: P_VERIFY_OTP_SUCCESS, data: 'Otp Verified' });
        yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
        yield put({ type: P_VERIFY_OTP_STATUS, data: 'success' });
        yield put({ type: VERIFY_CA_SUCCESS, data: data.response });
        yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
        localStorage.setItem('CaVerifed', 'YES');
      } else {
      }
    }
    if (data.statusType === 'FAIL') {
      yield put({ type: P_VERIFY_OTP_STATUS, data: 'fail' });
      yield put({ type: 'CHECK_SUBSCRIBE_FAILURE', data: data.statusMessage });
      yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
    }
  } catch (e) {
    yield put({ type: P_VERIFY_OTP_STATUS, data: 'fail' });
    // yield put({ type: 'NETWORK ERROR' });
    yield put({ type: 'CHECK_SUBSCRIBE_FAILURE', data: 'Invalid Otp' });
    yield put({ type: P_VERIFY_OTP_LOADER, payload: false });
  }
}

export function* getSubscrible({ payload }) {
  // debugger;
  try {
    // debugger;
    const data = yield subscribeAPI(payload?.id, payload?.token)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data.httpCode : e.message;
        return errorObj;
      });
    debugger;
    if (data?.statusType === 'SUCCESS') {
      yield put({ type: 'SET_SUBSCRIBE_DATA', payload: data?.response?.isSubscribed });
    }
    if (data?.statusType === 'FAIL') {
      yield put({ type: 'SET_SUBSCRIBE_DATA', payload: false });
    }
  } catch (e) {
    yield put({ type: 'SET_SUBSCRIBE_DATA', payload: false });
    const token = localStorage.getItem('token');
    if ('Unauthorized' === e?.response?.data?.error && token) {
      localStorage.setItem('userLogin', 'NO');
    }
  }
}
export default function* watchAll() {
  yield all([
    takeLatest(GET_OVERVIEW, GetOverviewAsync),
    takeLatest(GET_FEATURES, GetFeaturesAsync),
    takeLatest(CHECK_SUBSCRIBE, SubscribeAsync),
    takeLatest(NON_CA_EMAIL, sendNonCA),
    takeLatest(VERIFY_CA_START, verifyCaAsync),
    takeLatest(VERIFYOTPAPIASYC, verifyOtpAsync),
    takeLatest(SENDOTPFORPARTENR, sendOtpForPartner),
    takeLatest(GET_PARTNER_SUBSCRIBTION, getSubscrible),
  ]);
}

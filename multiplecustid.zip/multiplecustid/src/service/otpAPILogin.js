import axios from 'axios';
import { APIURL, APIMiddLEWAREURL } from '../env';
import { encryptedData, decryptedData } from './aes';
const LoginAPI = `${window.yblDomain}/apihub/login/auth`;
const validUserAPI = `${window.yblDomain}/apihub/user/verify?mobile=`;
axios.defaults.headers.post['Access-Control-Allow-Origin'] = '*';

export const verifyYBLOTPAPI = (payload) => {
  const verifyYBLUrl = `${window.yblDomain}/ybl/verifyOtpLogin`;
  return axios.post(
    verifyYBLUrl,
    { otpValue: payload.otpValue, captcha: payload.captcha, isLogin: payload.isLogin },
    { headers: { sessionid: localStorage.getItem('sessionId') } }
  );
};

export const sendYBLOTP = (payload) => {
  try {
    const sendYblUrl = `${window.yblDomain}/ybl/sendOtpLogin`;
    return axios.post(sendYblUrl, { mobile: `+${payload.mobile}` });
  } catch (e) {
    console.log(e);
  }
};

export const authCheck = (payload, headers) => {
  // debugger;
  return axios.post(`${window.yblDomain}/apihub/login/auth`, payload, { headers: { sessionid: localStorage.getItem('sessionId') } });
};
const loginHeader = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
};
export const verifyAdId = (id) => {
  const url = `${window.yblDomain}/apihub/user/verify`;
  return axios.post(url, { userName: id }, loginHeader);
  // /admin/verify?userName=admin'
};

export const psmLogin = (payload) => {
  const url = `${window.yblDomain}/apihub/user/loginUser`;
  return axios.post(url, payload, { headers: { sessionid: localStorage.getItem('sessionId') } });
};
export const refreshToken = () => {
  const url = `${window.yblDomain}/ybl/refreshCaptcha`;
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { sessionid: localStorage.getItem('sessionId') } };
  }
  return axios.get(url, header);
};

export const psmRefreshToken = () => {
  const url = `${window.yblDomain}/apihub/user/refreshCaptcha`;
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { sessionid: localStorage.getItem('sessionId') } };
  }
  return axios.get(url, header);
};

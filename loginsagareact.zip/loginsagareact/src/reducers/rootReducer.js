import { combineReducers } from 'redux';
import homeReducer from '../component/home/store';
import incrementreducer from '../component/increment/store';
export default combineReducers({
  homeReducer,
  incrementreducer

});

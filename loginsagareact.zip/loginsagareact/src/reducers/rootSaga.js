import { fork, all } from 'redux-saga/effects';
import homeSaga from '../component/home/saga';
import increSaga from '../component/increment/saga';

export default function* rootSaga() {
  yield all([
    fork(homeSaga),
    fork(increSaga),
    
  ]);
}

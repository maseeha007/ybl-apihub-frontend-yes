import { createStore, applyMiddleware } from 'redux';
// import { routerMiddleware } from 'connected-react-router';
import rootReducer from './reducers/rootReducer';
import rootSaga from './reducers/rootSaga';
import createSagaMiddleware from 'redux-saga';
//import history from './history';
import saga from "redux-saga";
//const sagaMiddleware = createSagaMiddleware(history);
const sagaMiddleware = createSagaMiddleware(saga)
const store = createStore(rootReducer,  applyMiddleware(sagaMiddleware));
sagaMiddleware.run(rootSaga);

export default store;

//import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import SignUp from './component/SignUp';
import Index from './component/home/index';
//import Incrementdecrmen from './component/increment/index';
//redux 1
import { Provider } from 'react-redux'
import store from './store'
//redux 1
function App() {
  return (
    <Provider store={store}>
    <div className="App">
    <Index></Index>
    
    
    
{/* <SignUp></SignUp> */}
       
    </div>
    </Provider>
  );
}

export default App;

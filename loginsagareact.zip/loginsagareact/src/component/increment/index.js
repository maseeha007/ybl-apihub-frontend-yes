import React, { Component } from "react";

import { connect } from "react-redux";

class Incrementdecrment extends Component {
  constructor(props) {
    super(props)
    this.state = {
      ...props
    }
  }
  render() {
    return (
      <div className="App">
        <div className="Age-label">
          your age: <span>{this.props.age}</span>
        </div>
        <button onClick={this.props.onAgeUp(30)}>Age UP</button>
        <button onClick={this.props.onAgeDown}>Age Down</button>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    age: state.incrementreducer.age
  };
};

const mapDispachToProps = dispatch => {
  debugger
  return {
   
    onAgeUp: (str,data) => dispatch({ type: str, value: data }),
    onAgeDown: () => dispatch({ type: "AGE_DOWN", value: 1 })
  };
};
export default connect(
  mapStateToProps,
  mapDispachToProps
)(Incrementdecrment);
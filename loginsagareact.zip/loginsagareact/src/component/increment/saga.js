import { delay } from "redux-saga";
import { takeLatest, put, all, takeEvery } from "redux-saga/effects";

export function* ageUpAsync(str ,data) {
  //yield delay(4000);
  console.log("maseeha",data ,str)
  yield put({ type: "AGE_UP_ASYNC", value: str.value });
}

export default function* watchAll() {
  yield takeLatest("AGE_UP", ageUpAsync);
}
import React, { useState } from "react";
import { connect } from 'react-redux';



const SignUp = () => {

    let [data, Setdata] = useState({ name: '', lname: '',  Email: '', pasword: ''})
    let [record, Setrecord]=useState([])
  
    

    const handlechange = (event) => {
        Setdata({...data,
            [event.target.name]: event.target.value,
          
        })
      //  console.log(JSON.stringify(data))
    }
    // React.useEffect(() => {
    //     console.log(data);
    //   }, [data])

    const Handlesubmit = (event) =>{
        debugger;
       event.preventDefault();
      
       let newrecord ={...data ,id:new Date().getTime().toString() }
       Setrecord({...record,newrecord})
      
       console.log(JSON.stringify(newrecord))
    }
    

    return (
        <div className="signupform">
            <div className="conatiner mt-5">
                <div className="row">
                    <div className="col-sm-6 ">
                        <form className="card p-5" onSubmit={Handlesubmit}>
                            <label ><b>Firt name</b></label>
                            <input onChange={handlechange} className="form-control" type="text" placeholder=" Enter first name" name="name" required />
                            <br />
                            <label ><b>Last name</b></label>
                            <input onChange={handlechange} className="form-control" type="text" placeholder="Enter  Last name" name="lname" required />
                            <br />
                            <label ><b>Email</b></label>
                            <input onChange={handlechange} className="form-control" type="email" placeholder="Enter Email" name="Email" required />
                            <br />
                            <label ><b>Address </b></label>
                            <input onChange={handlechange} className="form-control" type="text" placeholder="Enter pasword" name="Address" required />
                            <br />
                            <label ><b>Pasword </b></label>
                            <input onChange={handlechange} className="form-control" type="password" placeholder="Enter pasword" name="pasword" required />
                            <br />
                            <button type="submit" className="btn btn-success" onClick={Handlesubmit}>submit</button>
                            <button type="buttonm" className="btn btn-danger ml-2 ">cancle</button>

                        </form>
                    </div>

                    <div className="col-sm-6 ">
                        <div className="card" >
                            
                            <div className="card-body">
                                <h5 className="card-title">{data.name}</h5>
                                <h5 className="card-title">{data.lname}</h5>
                                <h5 className="card-title">{data.Email}</h5>
                                <h5 className="card-title">{data.Address}</h5>
                              
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    )



}

const mapStateToProps = (state, ownProps) => ({
    // ... computed data from state and optionally ownProps
  })
  
  const mapDispatchToProps = {
    // ... normally is an object full of action creators
  }

export default connect(mapStateToProps, mapDispatchToProps)(SignUp);

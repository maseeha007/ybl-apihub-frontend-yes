import React, { Component } from 'react';

import Incrementdecrmen from '../component/increment/index';

class Index extends Component {
  constructor(props) {
    super(props)
    this.state = {
      ...props
    }
  }
  componentDidMount() {
    
  }
  render() {
    return (
      <div id="home-section">
      <h2>hii maseeha</h2>
      <button onClick={this.props.onAgeUp}>parent btn</button>
      <Incrementdecrmen></Incrementdecrmen>
      </div>
    )
  }
}

export default Index

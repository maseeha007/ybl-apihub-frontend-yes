import { FETCH_CASUBSCRIPTION, ACCEPT_CASUBSCRIPTION, DECLINE_CASUBSCRIPTION,SET_CANCEL_ACTION_SUCCESS } from './constant';



export const get_subscriptions = (payload) => ({
  type: FETCH_CASUBSCRIPTION,
  payload: payload
})


export const accept_subscription = (payload) => ({
  type: ACCEPT_CASUBSCRIPTION,
  payload: payload
})


export const decline_subscription = (payload) => ({
  type: DECLINE_CASUBSCRIPTION,
  payload: payload
})

export const clearAPI_msg =() => ({
  type:SET_CANCEL_ACTION_SUCCESS,
  payload:''
})

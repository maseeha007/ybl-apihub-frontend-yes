import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link, withRouter } from 'react-router-dom';
import Header from '../../layout/admin-header';
import { make_login, refresh_Captcha, verify_AdId } from './actions';
import './style.scss';
import Pagination from '../../components/pagination'
import { Modal, Dropdown, Toast, Button } from 'react-bootstrap';
import Captcha from '../../components/captcha'
class Index extends Component {
  constructor(props) {
    super(props)
    this.state = {
      user: {},
      error: {}
    }
  }


  saveValue(name, e) {
    let value = e.target.value;
    this.setState({ ...this.state, user: { ...this.state.user, [name]: value } }, () => {
      if (name === 'username' && this.state.user.username?.length >= 10) {
        this.props.verify_AdId({ username: this.state.user.username })
      }
    });
  }

  makeLogin() {
    let flag = false
    let errObj = {}
    let dataObj = {}
    this.setState({ ...this.state, error: {} })
    localStorage.removeItem("AdminAccess");
    if (!this.state.user.username) {
      errObj['user'] = 'Please Enter Username';
      this.setState({ ...this.state, error: { ...errObj } });
      return
    } else {
      dataObj['username'] = this.state.user.username
    }

    if (!this.state.user.password) {
      errObj['password'] = 'Please Enter Password';
      this.setState({ ...this.state, error: { ...errObj } });
      return
    } else {
      dataObj['password'] = this.state.user.password
    }
    if (!this.state.user.password) {
      errObj['captcha'] = 'Please Enter Captcha';
      this.setState({ ...this.state, error: { ...errObj } });
      return
    } else {
      dataObj['captcha'] = this.state.user.captcha
    }
    this.props.makeLogin(dataObj)

  }


  componentDidUpdate(prevProps) {
    if (!prevProps.login_details?.token && this.props.login_details?.token) {
      this.setState({ ...this.state, success: 'Login successful !' })
      localStorage.setItem('adminToken', this.props.login_details?.token)
      localStorage.setItem('adminUserName', this.props.login_details?.username)
      setTimeout(() => {
        this.props.history.push('/admins/subscriptions')
      }, 3000)
    }
  }

  componentDidMount() {
    if (localStorage.getItem("AdminAccess")) {
      setTimeout(() => {
        localStorage.removeItem("AdminAccess");
      }, 3000)
    }
  }

  render() {
    return (
      <div id="login">
        <Header isLogin="true" />
        <div className="loginModal">
          {this.props.register_msg == 'success' && <div className={'alert alert-success'}>Congratulations, User Successfully Registered</div>}
          {this.props.error_msg && <div className={'alert alert-danger'}>{this.props.error_msg}</div>}
          {this.state.error.user ? <div className={'error alert alert-danger'}>{this.state.error.user}</div> : null}
          {this.state.success ? <div className={'error alert alert-success'}>{this.state.success}</div> : null}
          {localStorage.getItem("AdminAccess") === "No" ? <div className={'error alert alert-danger'}>Your Session has expired. Please login again</div> : null}

          <h3>SIGN IN TO YOUR ACCOUNT</h3>
          <input placeholder="Username" className="email" name="username" onChange={this.saveValue.bind(this, 'username')} />
          <input placeholder="Password" className="password" name="password" type="password" onChange={this.saveValue.bind(this, 'password')} />
          {this.props.captcha && <div className="Captcha">
            <Captcha base64Data={this.props.captcha} clickEvent={this.props.refresh_Captcha} />
            <input placeholder="Captcha" className="captcha" name="captcha" onChange={this.saveValue.bind(this, 'captcha')} />
          </div>}

          <button onClick={this.makeLogin.bind(this)}>LOG IN</button>
        </div>
      </div>
    )
  }
}



const mapStateToProps = (state) => {
  return {
    login_details: state.adminLoginReducer.login_details,
    error_msg: state.adminLoginReducer.error_msg,
    succcess_msg: state.adminLoginReducer.success_msg,
    captcha: state.adminLoginReducer.captcha
  };
};

const mapDispatchToProps = (dispatch) => ({
  makeLogin: (data) => dispatch(make_login(data)),
  verify_AdId: (payload) => dispatch(verify_AdId(payload)),
  refresh_Captcha: () => dispatch(refresh_Captcha())
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));



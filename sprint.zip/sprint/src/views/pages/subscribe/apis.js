import axios from 'axios';
import { APIURL } from '../../../env';

export const fetch_user = () => {
  const token = localStorage.getItem('token');
  return axios.get(`${window.yblDomain}/apihub` + '/user?isCaAccounsStatusRequired=false', {
    headers: {
      authorization: `Bearer ${token}`,
    },
  });
};

export const do_subscribe = (payload) => {
  const token = localStorage.getItem('token');
  return axios.post(`${window.yblDomain}/apihub` + '/subscription?isPartnerProduct=false', payload, {
    headers: {
      authorization: `Bearer ${token}`,
    },
  });
};

export const fetch_cust_status = () => {
  return {
    data: {
      statusCode: 200,
      statusMessage: 'RESPONSE EXIST',
      statusType: 'SUCCESS',
      response: 'verified',
    },
  };
};

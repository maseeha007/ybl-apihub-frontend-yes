import axios from 'axios';
import { APIURL } from '../../../env';

const fetchsubscriptionlist = () => {
  console.log('ajhgdsjhagd', localStorage.token);
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.token,
    },
  };
  let response = axios.get(`${window.yblDomain}/apihub` + '/subscription', config);
  return response;
};

const cancelSubscription = (params) => {
  let id = params.id;
  console.log('insidecancelapi', id);
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.token,
    },
  };
  let cancelresponse = axios.post(`${window.yblDomain}/apihub` + '/subscription/cancelSubscription?subscriptionId=' + id, {}, config);
  return cancelresponse;
};

export { fetchsubscriptionlist, cancelSubscription };

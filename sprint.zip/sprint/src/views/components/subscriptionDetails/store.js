import {  GET_SUBSCRIPTION_LIST_SUCCESS,GET_SUBSCRIPTION_LIST_FAILURE,CANCEL_SUBSCRIPTION_SUCCESS,CANCEL_SUBSCRIPTION_FAILURE } from './constant';

const initialState = {
  List: [],
  error: null,
  cancel:[],
};

const subscriptionListReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_SUBSCRIPTION_LIST_SUCCESS:
        console.log("insidereducer",action.data);
      return { ...state,List: action.data,error:null};
    case GET_SUBSCRIPTION_LIST_FAILURE:
      return { ...state, error: action.error_message };
      case  CANCEL_SUBSCRIPTION_SUCCESS:
        console.log("insidereducer******",action.data);
      return { ...state,cancel: action.data,error:null};
    case CANCEL_SUBSCRIPTION_FAILURE:
      return { ...state, error: action.error_message };
    default:
      return state;
  }
};

export default subscriptionListReducer;

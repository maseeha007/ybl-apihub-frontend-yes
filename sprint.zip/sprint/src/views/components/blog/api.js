import axios from 'axios';
import { APIURL } from '../../../env';
//otp start
 const do_verify_user = (custId) => {
  if (custId == '1234567890') {
    return {
      status: 'success',
      message: '',
      data: {
        firstName: 'Piyush',
        lastName: 'Kapoor',
        emailId: `piyushkapoor786${Math.floor(Math.random() * 1000)}@gmail.com`,
        mobile: `8284824${Math.floor(Math.random() * 1000)}`,
        countryCode: '+91',
        organization: 'Xebia',
      },
    };
  } else {
    return {
      status: 'fail',
      message: 'Please Enter Valid Cust ID',
    };
  }
};

 const do_verify_otp = (otp) => {
  if (otp == '222222') {
    return {
      status: 'success',
      message: 'Otp Verified',
    };
  } else {
    return {
      status: 'fail',
      message: 'Invalid OTP',
    };
  }
};
//otp end

//save trade
 const saveTrade_Action = ({user}) => {
   debugger;
    let reqObj = {
    fullName: user.fullName,
    productName: user.productName,
    mobile: user.mobile,
    emailId: user.emailId,
    companyName: user.companyName,
    annualincome: user.annualincome,
    city: user.city,
    branch: user.branch,
    remark: user.remark,
    service:user.service,
    islogin: false,
    };
    //const myJSON = JSON.stringify(reqObj);
    let header = {};
    
    if (localStorage.getItem('sessionId')) {
      header = { headers: { sessionid: localStorage.getItem('sessionId') } };
    }
    console.log(reqObj)
    return axios.post(`${window.yblDomain}` + '/ybl/saveYesTrade', reqObj, header);
  };
  const fetchSolutions = () => {
    var response = axios.get(window.yblDomain + '/apihub/explore/products');
    return response;
  };

  //account detail start
  const fetchAccountDetails = () => {
    var config = {
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
      },
    };
    let response = axios.get(`${window.yblDomain}/apihub/user?isCaAccountStatusRequired=true&role=${localStorage.getItem('role')}`, config);
    return response;
  };

  const getCity = (token) => {
    // const header = {
    //   'Content-Type': 'application/json',
    //   'Cookie': 'JSESSIONID=D7106C5C4F0145E6721662CB2CE444B0',
    //   Accept: 'application/json',
    // }
    var config = {
      headers: {
        'Content-Type': 'application/json',
       // Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
        'Cookie': 'JSESSIONID=D7106C5C4F0145E6721662CB2CE444B0'
      },
    };
    var response = axios.get(window.yblDomain + '/ybl/getYesTradeCityBranch',config);
    return response;
  };
  export { fetchSolutions, saveTrade_Action,getCity,fetchAccountDetails,do_verify_user,do_verify_otp}


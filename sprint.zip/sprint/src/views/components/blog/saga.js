

import {SAVE_TRADE_DATA,SAVE_TRADE_SUCCESS,SAVE_TRADE_FAIL,TRADE_FAIL
,       // GET_PRODUCTS_SUCCESS, GET_PRODUCTS_FAILURE,
        //GET_SOLUTIONS,
        
        GET_CITY_SUCCESS, GET_CITY_FAILURE,GET_CITY_SOLUTION,
        GET_TRADE_ACCOUNT_DETAILS, GET_TRADE_ACCOUNT_SUCCESS,GET_TRADE_ACCOUNT_FAILURE,
       
        VERIFY_TRADE_USER, VERIFY_TRADE_USER_SUCCESS, VERIFY_TRADE_USER_FAIL,SEND_TRADE_OTP,
      
        VERIFY_TRADE_OTP,VERIFY_TRADE_OTP_SUCCESS, VERIFY_OTP_FAIL,
    
        TRADE_SEND_OTP_LOADER,TRADE_VERIFY_OTP_LOADER
      } from './constant';
import { sendYBLOTP, verifyYBLOTPAPI, checkUser, validCAUser, validCAUserOnRegistration } from '../../../service/otpAPI';
import { sendEmailToUser } from '../../../service/subscribeAPI';
import {  saveTrade_Action ,fetchSolutions,getCity,fetchAccountDetails,do_verify_otp,do_verify_user} from './api';
import { all, put, takeEvery, call, select } from 'redux-saga/effects';

export function* GetAccountDataAsync() {
  try {
    const data = yield call(fetchAccountDetails);
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_TRADE_ACCOUNT_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_TRADE_ACCOUNT_FAILURE,
        error_message: data.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TRADE_ACCOUNT_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if (('Unauthorized' === error?.response?.data?.error || error.response.status === 401) && token) {
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    }
  }
}



export function* makeTradeApi({ payload }) {
  debugger;
  try {
    let { data, headers } = yield saveTrade_Action(payload);
    localStorage.setItem('sessionId', headers['sessionid']);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
     
      yield put({ type: SAVE_TRADE_SUCCESS, data: res });
      //yield put({ type: REG_CUST_ID_LOADER, payload: false });
    
    }
    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: SAVE_TRADE_FAIL, data: data.statusMessage });
     
    }
  } catch {
   
    yield put({ type: SAVE_TRADE_FAIL, data: "Backend service down" });
   
   
  }
}

// export function* GetSolutionAsync() {
//   try {
//     const data = yield call(fetchSolutions);
//     if (data.data.statusType == 'SUCCESS') {
//       // debugger;
//       // localStorage.setItem('products', JSON.stringify(data.data.response));
//       yield put({ type: GET_PRODUCTS_SUCCESS, data: data.data.response });
//     } else {
//       ({ eventName: 'search btn clicked', errorName: 'No matching product found' });

//       yield put({
//         type: GET_PRODUCTS_FAILURE,
//         error_message: data.data.message ? data.data.message : 'No matching product found.',
//       });
//     }
//   } catch (error) {
//     yield put({
//       type: GET_PRODUCTS_FAILURE,
//       error_message: 'Some Network Problem Occured',
//     });
//     yield put({
//       type: GET_PRODUCTS_FAILURE,
//       error_message: data.data.message ? data.data.message : 'Some Network Problem Occured',
//     });
//     trackErrorEvent({ eventName: 'search btn clicked', errorName: 'No matching product found' });
//   }
// }

export function* GetCityAsync() {
  try {
    const data = yield call(getCity);
    if (data.data.statusType == 'SUCCESS') {
      // debugger;
      // localStorage.setItem('products', JSON.stringify(data.data.response));
      yield put({ type: GET_CITY_SUCCESS, data: data.data.response });
    } else {
      ({ eventName: 'search btn clicked', errorName: 'No matching product found' });

      yield put({
        type: GET_CITY_FAILURE,
        error_message: data.data.message ? data.data.message : 'No matching product found.',
      });
    }
  } catch (error) {
    yield put({
      type: GET_CITY_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    yield put({
      type: CITY_FAILURE,
      error_message: data.data.message ? data.data.message : 'Some Network Problem Occured',
    });
    trackErrorEvent({ eventName: 'search btn clicked', errorName: 'No matching product found' });
  }
}


//otp start
export function* VerifyUserAsync({ payload }) {
  let custId = payload.custId;
  try {
    let { data, headers } = yield validCAUserOnRegistration(custId);
    localStorage.setItem('sessionId', headers['sessionid']);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
      res.custId = custId;
      res.encrptPhone = res.mobile;
      res.encrptemailId = res.emailId;
      res.mobile = res.mobile;
      res.randomval = new Date().getMilliseconds();
      // if (res.firstName) {
      //     res.emailId = res.emailId;
      // }
      // const encData = `${res.mobile}` + APISecretKey + `${decryptedData(res.emailId)}`
      // console.log("encDataencDataencDataencData======>"+encData)
      // localStorage.setItem('encData',encData );
      yield put({ type: VERIFY_TRADE_USER_SUCCESS, data: res });
      yield put({ type: REG_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'YES');
    }
    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: VERIFY_TRADE_USER_FAIL, data: 'Please Enter Valid Cust ID' });
      yield put({ type: REG_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'NO');
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
    yield put({ type: TRADE_FAIL, data: { result: 'Backend service is unavailable' } });
    yield put({ type: REG_CUST_ID_LOADER, payload: false });
    localStorage.setItem('CaVerifed', 'NO');
  }
}

export function* sendOtp({ payload }) {
debugger
  const sendotppayload = {
    mobile: payload.mobile,
    emailId: payload.emailId,
    isCaUser: false,
    
  };
  // if (checkValidUser.statusType === "FAIL") {
  //yield put({ type: 'IS_REGISTRED', data: { result: false } });
  // yield put({ 'type': REG_SEND_OTP_LOADER, payload: false })
  try {
    const data = yield sendYBLOTP(sendotppayload)
      .then((res) => {
        if (res.headers['sessionid']) {
          localStorage.setItem('sessionId', res.headers['sessionid']);
        }
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });

    if (data.statusType === 'FAIL') {
      yield put({ type: TRADE_FAIL, data: { result: data.statusMessage } });
      yield put({ type: TRADE_SEND_OTP_LOADER, payload: false });
      yield put({ type: 'IS_REGISTRED', data: { result: false } });
    }

    if (data.statusType === 'REQUEST IS NOT APPROPRIATE') {
      yield put({ type: TRADE_FAIL, data: { result: data.response } });
      yield put({ type: TRADE_SEND_OTP_LOADER, payload: false });
      yield put({ type: 'IS_REGISTRED', data: { result: false } });
    }

    if (data.statusType === 'SUCCESS') {
      debugger
      const res = { ...data };
      res.mobileNo = payload.mobile;
      res.emailId = payload.emailId;
      res.CAuser = localStorage.getItem('CA') == 'true' ? true : false;
      yield put({ type: 'SAVED_OTP_SUCCESS', data: res });
      yield put({ type: TRADE_FAIL, data: { result: '' } });
      yield put({ type: TRADE_SEND_OTP_LOADER, payload: false });
      yield put({ type: 'IS_REGISTRED', data: { result: true } });
    }
  } catch (err) {
    console.log(err);
    yield put({ type: REG_FAIL, data: { result: 'Unable to connect to YES BANK API' } });
    yield put({ type: TRADE_SEND_OTP_LOADER, payload: false });
    yield put({ type: 'IS_REGISTRED', data: { result: false } });
  }
  // } else {
  //     yield put({ 'type': "IS_REGISTRED", data: { result: false } })
  //     yield put({ 'type': REG_FAIL, data: { result: 'Mobile Number Already Registered' } })
  //     yield put({ 'type': REG_SEND_OTP_LOADER, payload: false })

  // }
}
export function* VerifyOtpAsync({ payload }) {
  let otp = payload.otp;
  try {
    yield put({ type: 'TRADE_FAIL', data: { result: undefined } });
    const state = yield select();
    const payload = {
      otpValue: otp,
      isCaUser: localStorage.getItem('CA') == 'true' ? true : false,
    };
    const data = yield verifyYBLOTPAPI(payload)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    if (data.statusType === 'SUCCESS') {
      if (data.response?.verifyOTPResponse) {
        const isvarifed = `${data.response?.verifyOTPResponse?.isValid}`;
        if (isvarifed === 'true') {
          yield put({ type: VERIFY_TRADE_OTP_SUCCESS, data: 'Otp Verified' });
          yield put({ type: TRADE_VERIFY_OTP_LOADER, payload: false });
        }
        if ('false' === isvarifed) {
          yield put({ type: VERIFY_TRADE_OTP_FAIL, data: data?.response?.verifyOTPResponse?.verificationFaultReason });
          yield put({ type: TRADE_VERIFY_OTP_LOADER, payload: false });
        }
      }

      if (data.response.mobile && data.response.emailId) {
        yield put({ type: VERIFY_TRADE_OTP_SUCCESS, data: 'Otp Verified' });
        yield put({ type: TRADE_VERIFY_OTP_LOADER, payload: false });
        // if(data.response.mobile && data.response.emailId)
        const custId = state.registerReducer?.verified_user?.custId;
        const res = data.response;
        res.custId = custId;
        yield put({ type: VERIFY_TRADE_USER_SUCCESS, data: res });
        yield put({ type: REG_CUST_ID_LOADER, payload: false });
        localStorage.setItem('CaVerifed', 'YES');
      } else {
      }
      // const yblResponse = `${decryptedData(data.response.yblResponse)}`;
      // const validYBLResponse = yblResponse.split("-")[0] === state?.registerReducer?.otp_data?.mobileNo

      // if (isvarifed == "true") {
      //     yield put({ 'type': VERIFY_OTP_SUCCESS, data: "Otp Verified" });
      //     yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
      //     if (state.registerReducer?.verified_user?.custId) {
      //         const custId = state.registerReducer?.verified_user?.custId;
      //         // find the Registered MObil No
      //         // find the registred email Id
      //         // appennd it with scret key
      //         let { data } = yield validCAUserOnRegistration(custId, localStorage.getItem("encData"));
      //         if (data.statusType === 'SUCCESS') {
      //             const res = data.response;
      //             res.custId = custId;
      //             res.encrptPhone = res.mobile;
      //             res.encrptemailId = res.emailId;
      //             res.mobile = `${decryptedData(res.mobile)}`
      //             if (res.firstName) {
      //                 res.emailId = `${decryptedData(res.emailId)}`;
      //                 res.firstName = `${decryptedData(res.firstName)}`;
      //             }
      //             if (res.lastName) {
      //                 res.lastName = `${decryptedData(res.lastName)}`;
      //             }

      //             yield put({ 'type': VERIFY_USER_SUCCESS, data: res });
      //             yield put({ "type": REG_CUST_ID_LOADER, payload: false })
      //             localStorage.setItem("CaVerifed", "YES")

      //         }
      //         if (data.statusType !== 'SUCCESS' && typeof data.response === "string") {
      //             yield put({ 'type': VERIFY_USER_FAIL, data: 'Please Enter Valid Cust ID' });
      //             yield put({ type: REG_CUST_ID_LOADER, payload: false })
      //             localStorage.setItem("CaVerifed", "NO")
      //         }
      //     }
      // }
      // if ("false" === isvarifed) {
      //     yield put({ type: VERIFY_OTP_FAIL, data: data?.response?.verifyOTPResponse?.verificationFaultReason })
      //     yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
      // }
    }
    if (data.statusType === 'FAIL') {
      yield put({ type: 'REG_FAIL', data: { result: data.statusMessage } });
      yield put({ type: VERIFY_TRADE_OTP_FAIL, data: data.statusMessage });
      yield put({ type: TRADE_VERIFY_OTP_LOADER, payload: false });
    }
  } catch (e) {
    yield put({ type: 'NETWORK ERROR' });
    yield put({ type: VERIFY_TRADE_OTP_FAIL, data: 'Invalid Otp' });
    yield put({ type: TRADE_VERIFY_OTP_LOADER, payload: false });
  }
}


//otp end


export default function* watchAll() {
  yield all([takeEvery(SAVE_TRADE_DATA, makeTradeApi), 
   // takeEvery(GET_SOLUTIONS, GetSolutionAsync) ,
    takeEvery(GET_CITY_SOLUTION, GetCityAsync) , 
   // takeEvery(GET_ACCOUNT_DETAILS, GetAccountDataAsync),
    //takeEvery(VERIFY_USER, VerifyUserAsync), 
    takeEvery(VERIFY_TRADE_OTP, VerifyOtpAsync),
    takeEvery(SEND_TRADE_OTP, sendOtp)
  ]);
}

import axios from 'axios';
import { compose } from 'redux';
import { APIURL } from '../../../env';

const capitalize = (s) => {
  if (typeof s !== 'string') return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
};

const fetchSolutions = ({ payload }) => {
  var response = axios.get(
    `${window.yblDomain}/apihub` + '/explore/solutions?solutionName=' + capitalize(payload.solutionName) + '&solutionType=' + payload.solutionType
  );
  //  var response = axios.get('http://api.636018471a4e4806a6f8.southeastasia.aksapp.io/explore/solutions?solutionName=Payments&solutionType=ybl')
  return response;
};

const fetchTagsSolutions = (params) => {
  let fsearchKey = params.tags.toString();
  let searchKey = fsearchKey.toLowerCase();
  let value = '';
  if (params.boolean === true) {
    value = 'yblProduct';
  } else if (params.boolean === false) {
    value = 'partner';
  } else if (params.boolean === '') {
    value = '';
  }
  var config = {
    searchKey: searchKey,
    filter: value,
  };
  console.log('insidefetchsolutions', params.boolean);
  let tagsresponse = axios.post(`${window.yblDomain}/apihub` + '/search/searchDetails', config);
  return tagsresponse;
};

export { fetchSolutions, fetchTagsSolutions };

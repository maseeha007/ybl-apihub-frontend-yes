import React, { Component } from 'react';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';

import './style.scss';
import { withRouter } from 'react-router';
import { getAccountData } from '../account/actions';
import { connect } from 'react-redux';
import { onLoadTrack } from '../../../analytics';

class Index extends Component {
  componentDidMount() {
    this.props.getAccountData();
    const payload = {
      pageName: 'yes connect|policy',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };

    onLoadTrack(payload);
  }
  render() {
    return (
      <>
        <Header />
        <section id="policy">
          <div className="banner-container">
            <h2 className="banner-heading">
              {' '}
              <span>Privacy Policy for Developers</span>{' '}
            </h2>
          </div>
          <div className="body-container">
            <div className="sub-container">
              <p className="text-content">
                In this policy, “we”, “us”, “our” means YES BANK Limited and “you”, “your” or “yours” means the persons to whom this policy applies.
              </p>
              <p className="text-content">
                When you visit this web site YES BANK may collect personal information about you, either directly (where you are asked to provide the
                information) or indirectly. While information is the cornerstone of our ability to provide superior service, our most important asset is our
                customers' trust. Keeping customer information secure, and using it only as our customers would want us to, is a top priority for all of us at
                YBL. Hence, YES BANKwill only use these personal data in accordance with the purposes set forth in this Developer Privacy Policy and is
                committed to safeguarding the personal information collected.
              </p>
              <p className="text-content">
                This Developer Privacy Policy describes how we may collect, use and share information you provide when you visit or otherwise interact with the
                Developer Portal.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">How Do We Use the Information We Collect?</h2>
              <p className="text-content">
                By accessing the Developer Portal and/or participating in the programme involving the development and embedding of APIs of YES BANKyou agree to
                be bound by this policy which supplements the terms of YES BANKPrivacy Policy accessible at https://www.yesbank.in/pdf/footer_privacypolicy by
                setting out the additional purposes in relation to which we may collect, use and disclose your information.{' '}
              </p>
              <p className="text-content">
                The following sections of the YES BANKPrivacy Policy (including any amendments made thereto from time to time) are incorporated by reference in
                this policy, mutatis mutandis: (i) Internet Privacy Policy; (ii) Purposes of processing; (iii) Data Retention; (iv) Cookies; (v) Internet
                Communications; (vi) Sensitive Data; (vii) Third party sites; (viii) Customer Obligations; (ix) Your Rights How to Contact Us; (x) Contacting
                You; and (xi) Disclaimer for data on third party website.
              </p>
              <p className="text-content">
                You agree that we may use customer information for the purpose of statistical analysis and for creation of data ("Statistical Information"),
                which does not contain individual customer information. In addition to the information that we elicit from you, you are free to volunteer any
                other information that you feel that we need to know, but the security and confidentiality as per this Developer Privacy Policy is guaranteed
                only to the information that we directly ask from you.
              </p>
              <p className="text-content">
                You agree that we may use the customer information we collect from you for, among other things, to manage our offerings, offer an enhanced,
                personalized development experience on the Developer Portal, customer verification, for personalization of products or services, marketing or
                promotion of our financial services or related products or that of our associates and affiliates; for creation of Statistical Information,
                statistical analysis or credit scoring, enforcement of your obligations, any other purpose that will help us in providing you with optimal and
                high quality services.
              </p>
              <p className="text-content">
                This Developer Privacy Policy holds true for a non-customer who has provided information to us, by any means, with the intentions of
                establishing a relationship, of whatsoever nature, with us. By divulging any information to us you agree to the terms and conditions of this
                Developer Privacy Policy.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Security</h2>
              <p className="text-content">
                We will take reasonable measures to protect security and confidentiality of the customer information and its transmission through the World Wide
                Web. You are required to follow the Terms and Conditions while using this website including the instructions stated therein in respect of
                security and confidentiality of your Log-in and Password.
              </p>
              <p className="text-content">
                We will give access to customer information to only authorised employees, who are trained in the proper handling of customer information, to
                have access to that information. Employees who violate this Developer Privacy Policy shall be subject to our normal disciplinary process. Any
                employee who withdraws from the employment of YES BANKwill have to undertake to abide by this Developer Privacy Policy and keep all customer
                information secure and confidential.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Disclosure</h2>
              <p className="text-content">
                We shall not be held liable for disclosure of the customer information or Statistical Information in accordance with this Disclosure Privacy
                Policy or in terms of any other agreements with you.
              </p>
              <p className="text-content">
                We may disclose the Statistical Information to any person, without any limitation and you hereby give your irrevocable consent for the same.
              </p>
              <p className="text-content">
                We may disclose customer information to any of our associates and affiliates, without any limitation and you hereby give your consent for the
                same.
              </p>
              <p className="text-content">
                We may disclose the customer information, to third parties, without limitation, for the following reasons and you hereby give your irrevocable
                consent for the same:
              </p>
              <ol type="a">
                <li>
                  <p className="text-content-list">To comply with legal requirements, legal process, legal or regulatory directive/ instruction. or </p>
                </li>
                <li>
                  <p className="text-content-list">To enforce the Terms and Conditions of the products or services. or </p>
                </li>
                <li>
                  <p className="text-content-list">
                    To protect or defend our rights, interests and property or that of our associates and affiliates, or that of our or our affiliate's
                    employees, consultants etc. or{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">For fraud prevention purposes. or</p>
                </li>
                <li>
                  <p className="text-content-list">As permitted or required by law.</p>
                </li>
              </ol>
              <p className="text-content">
                {' '}
                We may disclose the customer information to third parties for following, among other purposes, and will make reasonable efforts to bind them to
                obligation to keep the same secure and confidential and an obligation to use the information for the purpose for which the same is disclosed,
                and you hereby give your irrevocable consent for the same:
              </p>
              <ol type="a" className="last-section">
                <li>
                  <p className="text-content-list">For participation in any telecommunication or electronic clearing network; or </p>
                </li>
                <li>
                  <p className="text-content-list">For credit rating by a credit rating agency; or </p>
                </li>
                <li>
                  <p className="text-content-list">For advertising; or </p>
                </li>
                <li>
                  <p className="text-content-list">For facilitating joint product promotion campaigns; or </p>
                </li>
                <li>
                  <p className="text-content-list">
                    For the purposes of credit reporting, verification and risk management to/ with clearing house centers or credit information bureau and the
                    like; or{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    For availing of the support services from third parties e.g. collecting subscription fees, and notifying or contacting you regarding any
                    problem with, or the expiration of, any services availed by you.{' '}
                  </p>
                </li>
              </ol>
            </div>
          </div>
        </section>
        <Footer />
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    ...state,
  };
};

const mapDispatchToProps = (dispatch) => ({
  getAccountData: () => dispatch(getAccountData()),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));

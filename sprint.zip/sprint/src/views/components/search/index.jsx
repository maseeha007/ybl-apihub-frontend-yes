import React, { PureComponent } from "react";
import { withRouter } from "react-router-dom";
import { Container, Row, Col, Badge } from "react-bootstrap";
import createHistory from "history/createBrowserHistory";
import { getSearchData } from "./action";
import { getTagsData } from '../explore/actions';
import { connect } from "react-redux";
import { globalClickEvent, trackSearchEvent } from '../../../analytics'

import "./style.scss";
const tags = [
  "Electronic Collection",
  "Dealer Payment Recovery",
  "Remittance", "Fund Transfer",
  "Bulk Transfers",
  "Benificiary Management",
  // "Bill Management",
  "Wallet Management",
  "ERP",
  "Accounting",
  "Invoice Management",
  "Payroll",
  "API Aggregator"
]

class Search extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      searchField: "",
      tagField: "",
      tags: tags.sort(),
    };
  }

  searchParamOnEnter = (e) => {
    if (e.charCode === 13) {
      this.props.close();
      trackSearchEvent(this.state.searchField)
      this.props.history.push(`/explore?searchKey=${this.state.searchField}`);
    }

  };

  handleSearchField = (e) => {
    this.setState({
      searchField: e.target.value,
    });
  };
  handleBadge = (e, tag) => {
    let boolean = "";
    this.setState(
      {
        tagField: tag,
      },
      () => {
        this.props.close()
        if (this.state.tagField == undefined) {
          trackSearchEvent(this.state.searchField)
          this.props.history.push(`/explore?searchKey=${this.state.searchField}`);
        } else {
          trackSearchEvent(this.state.tagField)
          this.props.history.push(`/explore?searchKey=${this.state.tagField}`);
        }

      }
    );
  };

  render() {
    return (
      <section id="search">
        <Container fluid className="no-pad">
          <Row className="search-container flex">
            <Col className="search-column flex">
              <input
                type="text"
                className="search-input"
                onChange={(e) => this.handleSearchField(e)}
                onKeyPress={(e) => this.searchParamOnEnter(e)}
                placeholder="Type to Search..."
                value={this.state.searchField}
                autoFocus={true}
              />
            </Col>
            <Col className={"button-container flex"}>
              <img
                alt="icon"
                className="search-icon"
                src="/assets/icons/search-big.svg"
                onClick={this.handleBadge}
              />
              <img
                alt="icon"
                className="close-icon"
                src="/assets/icons/close-black.svg"
                onClick={this.props.close}
              />
            </Col>
          </Row>
        </Container>
        <Container className="tags-container" fluid>
          <Row>
            <Col md={12} className="heading-row">
              <div className="tags-heading">Popular keywords</div>
            </Col>
          </Row>
          <Row className="tag-row">
            <Col className="tag-col">
              {this.state.tags.map((tag) => {
                return (
                  <Badge
                    className="badge"
                    onClick={(e) => this.handleBadge(e, tag)}
                  >
                    {tag}
                  </Badge>
                );
              })}
            </Col>
          </Row>
        </Container>
      </section>
    );
  }
}

const mapStateToProps = (state) => ({});
const mapDispatchToProps = (dispatch) => {
  return {
    getSearchData: (data, boolean) => dispatch(getSearchData(data, boolean)),
    getTagsData: (data, boolean) => dispatch(getTagsData(data, boolean))
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Search));

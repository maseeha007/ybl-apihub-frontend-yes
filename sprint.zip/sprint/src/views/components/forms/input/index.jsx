import React, { useState, useRef, useEffect } from "react";
import { Form, FormControl, InputGroup } from 'react-bootstrap';
import classnames from 'classnames';
import './style.scss';

const Input = (props, ref) => {
    const inputEl = useRef();

    const [state, setState] = useState({ edited: false })

    const innerFocus = () => {
        setState({ ...state, 'edited': true, 'hasText': props.defaultValue })
    }

    const innerBlur = () => {
        const value = inputEl.current.value
        if (value) {
            setState({ ...state, 'hasText': true, 'edited': false })
        } else {
            setState({ ...state, 'hasText': false, 'edited': false })
        }
    }


    const innerClick = () => {
        if (!props.disabled) {
            inputEl.current.focus();
            setState({ ...state, 'edited': true })
        }
    }

    useEffect(() => {
        console.log("under focus=======>")
        const value = inputEl.current.value
        if (value) {
            setState({ ...state, 'hasText': true, 'edited': false })
        } else {
            setState({ ...state, 'hasText': false, 'edited': false })
        }
    }, [props])
    console.log('edited============>', this?.state?.edited);
    console.log('defaultValue============>', props.defaultValue)
    console.log('hasText============>', this?.state?.hasText)



    return (
        <div className={classnames({ "ybl-input": true, 'active': state.edited, 'disabled': props.disabled })}  >
            <InputGroup>
                {props.icon ?
                    <InputGroup.Prepend>
                    </InputGroup.Prepend> : null}
                <div className="relative-div">
                    <FormControl value={props.disabled ? (props.defaultValue ? props.defaultValue : '') : (props.defaultValue ? props.defaultValue : undefined)} ref={ref} disabled={props.disabled} ref={inputEl} onKeyDown={(event) => { props.maskKey && props.maskKey(event) }} onChange={props.onChange} onFocus={() => { innerFocus(); }}  {...props} />
                    <Form.Label ref={el => {
                        el &&
                            el.addEventListener("selectstart", (e) => {
                                e.preventDefault()
                            });
                    }} onClick={() => { innerClick() }} className={classnames({ 'has-text': props.defaultValue || state['hasText'] })}>{props.label ? props.label : ''}{props.required ? <span className="required">*</span> : null} </Form.Label>
                </div>
            </InputGroup>
            { props.error && <div className="error">{props.error}</div>}
            { props.success && <div className="success">{props.success}</div>}
        </div>
    );
}

export default Input;

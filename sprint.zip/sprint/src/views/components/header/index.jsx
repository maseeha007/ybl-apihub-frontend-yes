import React from 'react';

function Header() {
  return (
    <nav className="navbar navbar-light bg-light">
      <a className="navbar-brand" href="/">
        <img src="/assets/logo" height="60" className="d-inline-block align-top" alt="" />
      </a>
    </nav>
  );
}

export default Header;

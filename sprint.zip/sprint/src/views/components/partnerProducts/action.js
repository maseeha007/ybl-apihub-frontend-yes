import { GET_PARTNER_PRODUCTS,UPDATE_PARTNER} from './constant';

export const getpartnerProducts = () => ({
  type:GET_PARTNER_PRODUCTS,
});

export const updatePartner = (obj) =>({
  type:UPDATE_PARTNER,
  payload:{obj}
})
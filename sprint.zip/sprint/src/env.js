// import fs from 'fs-extra';
// import YAML from 'yaml';
import * as yaml from 'yamljs';

// DEV ENV

// export const APIMiddLEWAREURL = () => {
//   //   let domainName = 'Navin';

//   //   if (!localStorage.domainName1) {
//   fetch('/domain.txt', {
//     headers: {
//       'Content-Type': 'application/json',
//       Accept: 'application/json',
//     },
//   })
//     .then(function (response) {
//       console.log(response);
//       return response.json();
//     })
//     .then(function (myJson) {
//       debugger;
//       // console.log(myJson);
//       if (myJson.domain === 'QA') {
//         // domainName = 'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io';
//         return 'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io';
//       }
//       if (myJson.domain === 'UAT') {
//         // domainName = 'https://uatyesconnectadmin.yesbank.in';
//         return 'https://uatyesconnectadmin.yesbank.in';
//       }
//       if (myJson.domain === 'PROD') {
//         // domainName = 'https://yesconnect.yesbank.in';
//         return 'https://yesconnect.yesbank.in';
//       }
//       // return domainName
//     });
//   //   localStorage.setItem('domainName', domainName);
//   //   return domainName;
//   //   } else {
//   //     return localStorage.getItem('domainName');
//   //   }
// };
export let APIMiddLEWAREURL = '';
export let APIURL = '';
// export let APIMiddLEWAREURL = 'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io';
// // debugger;
// export let APIURL = `http://api.636018471a4e4806a6f8.southeastasia.aksapp.io/apihub`; // 'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io/apihub'
// //'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io'
export let APISecretKey = 'ARNUISSYH&1234&$'; //process.env.APISecretKey
export let AESKEY = 'YjkxNDc0MWRjYTMxYmZhZTRjMmQ0ZDAwMzc4MGIwMGU=';
// };
// fetch('/public/domain.txt')
//   .then((response) => response.text())
//   .then((text) => {
//     debugger;
//     console.log(text);
//   });
// ENV DEV, UAT ,PROD
// try {
//   debugger;
//   yaml.load('/helm/ybl-apihub-frontend-chart/templates/ybl-apihub-frontend-deployment.yaml', (result) => {
//     console.log('result', result);
//     debugger;
//     APIURL = `${result.spec.template.spec.containers[0].env[0].value}/apihub`;
//     APIMiddLEWAREURL = `${result.spec.template.spec.containers[0].env[0].value}`;
//     // this.setState({ fileData: result, loading: false, activeTab: Object.keys(result['paths'])[0] })
//   });
// } catch (e) {
//   console.log(e);
// }
// import * as config from '../helm/ybl-apihub-frontend-chart/templates/ybl-apihub-frontend-deployment.yaml';
// ENV for PROD

// export const APIURL = 'https://yesconnect.yesbank.in/apihub';
// export const APIMiddLEWAREURL = 'https://yesconnect.yesbank.in';
// export const APISecretKey = 'ARNUISSYH&1234&$';
// export const AESKEY = 'YjkxNDc0MWRjYTMxYmZhZTRjMmQ0ZDAwMzc4MGIwMGU=';
// UAT ENV

// export const APIURL = 'https://uatyesconnectadmin.yesbank.in/apihub';
// export const APIMiddLEWAREURL = 'https://uatyesconnectadmin.yesbank.in';
// export const APISecretKey = 'ARNUISSYH&1234&$'; //process.env.APISecretKey
// export const AESKEY = 'YjkxNDc0MWRjYTMxYmZhZTRjMmQ0ZDAwMzc4MGIwMGU=';

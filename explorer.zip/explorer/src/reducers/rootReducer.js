import { combineReducers } from 'redux';
import homeReducer from '../views/pages/home/store';
import headerReducer from '../views/layout/header/store';
import solutionsReducer from '../views/components/explore/store';
import solutionsexReducer from '../views/components/explore-path/store';
import searchReducer from '../views/components/search/store';
import loginReducer from '../views/components/login/reducers';
import registerReducer from '../views/pages/register/store';
import subscribeReducer from '../views/pages/subscribe/store';
import accountReducer from '../views/components/account/store';
import subscriptionListReducer from '../views/components/subscriptionDetails/store';
import partnerReducer from '../views/components/partnerProducts/store';
import adminSubReducer from '../views/pages/admin-subscriptions/store';
import adminLoginReducer from '../views/pages/admin-login/store';
import adminCaSubReducer from '../views/pages/admin-subscriptions-cancel/store';
import adminLeadReducer from '../views/pages/admin-leads/store';
import adminTradeReducer from '../views/pages/admin-trade/store';
import partnerProductReducer from '../views/components/partnerDetails/store';
import pdpReducer from '../views/pages/pdp/store';
import partnerLeadReducer from '../views/pages/admin-partner-leads/store';
import partnersReducer from '../views/components/partners/store';
import traderegisterReducer from '../views/components/blog/store';
export default combineReducers({
  homeReducer,
  headerReducer,
  registerReducer,
  searchReducer,
  loginReducer,
  solutionsReducer,
  subscribeReducer,
  accountReducer,
  subscriptionListReducer,
  partnerReducer,
  adminSubReducer,
  adminCaSubReducer,
  adminLeadReducer,
  adminTradeReducer,
  partnerProductReducer,
  pdpReducer,
  solutionsexReducer,
  adminLoginReducer,
  partnerLeadReducer,
  partnersReducer,
  traderegisterReducer
});

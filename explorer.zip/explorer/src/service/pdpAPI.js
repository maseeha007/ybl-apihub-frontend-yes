import axios from 'axios';
import { APIURL } from '../env';

export const getOverViewAPI = (id) => {
  const url = `${window.yblDomain}/apihub/explore/products/${id}/overviews`;
  return axios.get(url);
};

export const getFeaturesAPI = (id) => {
  const url = `${window.yblDomain}/apihub/explore/products/${id}/features`;
  return axios.get(url);
};

export const getVersions = (id) => {
  const url = `${window.yblDomain}/apihub/explore/products/${id}/versions`;
  return axios.get(url);
};

export const getAPIDefination = (id, token) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  const url = `${window.yblDomain}/apihub/explore/products/${id}/apiDefinition`;
  return axios.get(url, config);
};

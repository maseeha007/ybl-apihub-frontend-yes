import axios from 'axios';
import { APIURL } from '../../../env';

const fetchOverview = (id) => {
  var response = axios.get(`${window.yblDomain}/apihub` + '/explore/products/' + id + '/overviews');
  return response;
};

const fetchFeatures = (id) => {
  // debugger;
  var response = axios.get(`${window.yblDomain}/apihub` + '/explore/products/' + id + '/features');
  return response;
};
const fetchSubscribe = (payload) => {
  var name = payload.name;
  var productId = payload.productId;
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  debugger;
  var response = axios.post(
    `${window.yblDomain}/apihub` + '/subscription?productName=' + name + '&isPartnerProduct=true',
    { productId: productId, environment: '', plan: 'Gold', custId: payload.custId },
    config
  );
  return response;
};

export { fetchOverview, fetchFeatures, fetchSubscribe };

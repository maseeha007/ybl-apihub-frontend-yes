import { GET_SEARCH } from './constant';


export const getSearchData = (tags, boolean) => (
  console.log("tagsinaction", tags, boolean),
  {
    type: GET_SEARCH,
    payload: { tags, boolean }
  });

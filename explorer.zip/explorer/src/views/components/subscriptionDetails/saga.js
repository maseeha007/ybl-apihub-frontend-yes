import { all, call, put, takeEvery, takeLatest } from "redux-saga/effects";
import {fetchsubscriptionlist,cancelSubscription} from "./api";
import {  GET_SUBSCRIPTION_LIST, GET_SUBSCRIPTION_LIST_SUCCESS,GET_SUBSCRIPTION_LIST_FAILURE,CANCEL_SUBSCRIPTION, CANCEL_SUBSCRIPTION_SUCCESS,CANCEL_SUBSCRIPTION_FAILURE } from './constant';

export function* GetSubscriptionListAsync() {
    console.log("insaga%%%%%%");
  try {
    const data = yield call(fetchsubscriptionlist);
    if (data.data.statusType == "SUCCESS") {
        console.log("insaga",data.data.response);
      yield put({ type: GET_SUBSCRIPTION_LIST_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_SUBSCRIPTION_LIST_FAILURE,
        error_message: data.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: GET_SUBSCRIPTION_LIST_FAILURE,
      error_message: "Some Network Problem Occured",
    });
    const token = localStorage.getItem("token")
    if ("Unauthorized" === error?.response?.data?.error && token) {
      window.location.href = "/";
      localStorage.setItem("userLogin","NO")
      localStorage.setItem("sessionExpired","true")
    }
    
  }
}
export function*CancelSubscriptionAsync({payload}) {
    console.log("icancelsaga");
  try {
    const data = yield call(cancelSubscription.bind(this,payload));
    if (data.data.statusCode == 200) {
        console.log("insaga",data.data.response);
      yield put({ type: CANCEL_SUBSCRIPTION_SUCCESS, data: data.data });
    } else {
      yield put({
        type: CANCEL_SUBSCRIPTION_FAILURE,
        error_message: data.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: GET_SUBSCRIPTION_LIST_FAILURE,
      error_message: "Some Network Problem Occured",
    });
    const token = localStorage.getItem("token")
    if ("Unauthorized" === error?.response?.data?.error && token) {
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      // localStorage.setItem("userLogin","NO")
      window.location.href = "/";
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem("userLogin","NO")
      localStorage.setItem("sessionExpired","true")
    }
  }
}




export default function* watchAll() {
  yield all([
    takeLatest( GET_SUBSCRIPTION_LIST, GetSubscriptionListAsync),
    takeLatest( CANCEL_SUBSCRIPTION, CancelSubscriptionAsync),
  ]);
}

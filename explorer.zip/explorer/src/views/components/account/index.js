import React, { Component } from 'react';
import { Container, Row, Col, Badge, Modal, Button, Alert, Form, Spinner } from 'react-bootstrap';
import Header from '../../layout/header/index';
import {
  getAccountData,
  updateCustId,
  clearData,
  custICheckAction,
  sendOtpLoaderAction,
  custIDLoaderAction,
  verifyOTPLoader,
  sendOtpCAUser,
  verifyOtpAction,
  refreshCaptcha,
  removeCustId,
  makeDefaultCustId,
} from './actions';
import { connect } from 'react-redux';
import { onLoadTrack } from '../../../analytics';
import Input from '../forms/input';
import PhoneNumber from '../../components/forms/phoneNumber';
import Otp from '../../components/forms/otp';
import './style.scss';
import Captcha from '../../components/captcha';

// import { verify_user, verifyOtpLoaderAction } from '../../pages/register/actions';
class Account extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalAccount: false,
      caNumber: '',
      disabledVerify: false,
      error: {},
      isCustIdVisible: true,
      otpVerified: false,
      otpDisabled: true,
      otpTime: 0,
    };
  }

  componentDidMount(prevProps) {
    this.props.getAccountData();
    const isLogin = localStorage.getItem('userLogin');
    if (isLogin) {
      window.location.href = '/';
    }
    const payload = {
      pageName: 'yes connect|account',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }
  handlePageChange() {
    this.props.history.push('/subscription-list');
  }
  handleModalClose() {
    // debugger;
    this.props.clearData();
    this.setState({ ...this.state, modalAccount: false, caNumber: '', rand: Math.random() });
  }
  handleOpenModal() {
    this.setState({ ...this.state, modalAccount: true });
  }
  saveCaAccount(e) {
    // this.setState({ ...this.state, caNumber: e.target.value });
    if (e.target.value.length > 0) {
      this.setState({ ...this.state, disabledVerify: false, caNumber: e.target.value });
    } else {
      this.setState({ ...this.state, disabledVerify: false, caNumber: e.target.value });
    }
  }
  verifyCustId = () => {
    const { caNumber } = this.state;
    // debugger;
    this.props.custIDLoaderAction(true);
    // this.setState({ ...this.state, disabledVerify: true });
    if (caNumber.length > 0) {
      this.props.verify_user(caNumber);
    }
  };
  subscribeCustId = () => {
    console.log('custt ID update is called');
    if (!this.state.user.captcha) {
      this.setState({ ...this.state, error: { captcha: true } });
    }
    if (this.props.otpStatus === 'success') {
      this.setState({ ...this.state, error: { captcha: false } });

      this.props.updateCustId(this.state.caNumber);
    }
  };
  saveValue(name, e) {
    let value = e.target.value;
    console.log('name=========>' + name);
    console.log('value=========>' + value);

    this.setState({ ...this.state, user: { ...this.state.user, [name]: value } });
    console.log('saveValue==================>' + this.state.custId);
  }

  validateMobileNumber() {
    debugger;
    this.props.sendOtpLoaderAction(true);
    if (this.props?.verified_user?.mobile?.length > 0) {
      this.props.sendOtpCAUser(this.props?.verified_user?.custId);
    }
  }

  verifyClickNow() {
    debugger;
    if (this.state?.user.otp?.length === 6) {
      this.props.verifyOTPLoader(true);
      this.props.verifyOtpAPI(this.state?.user.otp, this.state?.user?.captcha);
      this.setState({ ...this.state, otpSent: true });
    } else {
      this.setState({ ...this.state, error: { otp: true }, otp_status: 'fail', otp_messgae: 'Please enter valid OTP' });
    }
  }

  componentDidUpdate(prevProps) {
    // debugger;
    if (prevProps?.isOtpSent !== this.props?.isOtpSent && this.props?.isOtpSent) {
      this.setState({ ...this.state, otpSent: true, otpDisabled: true, startTimer: true });
      this.timer = setInterval(() => {
        this.setState({ ...this.state, otpTime: this.state.otpTime ? this.state.otpTime - 1 : 60 });
      }, 1000);
      setTimeout(() => {
        if (this.timer !== null) {
          this.setState({ ...this.state, otpDisabled: false, otpTime: 0, startTimer: false, OtpText: 'Resend OTP' });
        }
        clearInterval(this.timer);
      }, 60000);
    }

    if (prevProps.otpStatus !== this.props.otpStatus && this.props.otpStatus) {
      this.setState({ ...this.state, otpTime: 0, otpDisabled: true });
      clearInterval(this.timer);
    }
  }

  removeMyAccountCustIds(e) {
    const custId = e.target.id;
    this.props.removeCustId(custId);
  }
  render() {
    console.log('props===========>', this.props);
    console.log('status 1====>', this.props.custIdSuccessStatus);
    console.log('status 2====>', this.props.custIdErrorStatus);
    console.log('caNumber=======>', this.state.caNumber);

    return (
      <>
        <Header />
        <section id="account">
          <Container>
            <Row noGutters={true}>
              <Col className="no-pad" md={12} lg={12}>
                <div className="nav nav-tabs">
                  <div className="heading-container tab active">
                    <Badge className="account-heading">My Account</Badge>
                  </div>
                  <div className="heading-container1 tab" onClick={this.handlePageChange.bind(this)}>
                    <Badge className="subscription-heading">My Subscription</Badge>
                  </div>
                </div>
              </Col>
              <Col className="no-pad body-container row" md={12} lg={12}>
                <Col className="leftsection" md={8} lg={8}>
                  <div className="row body-row">
                    <div className="col col-xs-5 col-md-6 no-pad ">
                      <p className="body-label"> First Name </p>
                      <p className="body-data">
                        {this.props.accountValues.firstName && this.props.accountValues.firstName == 'XXXXXXXXXXXXX'
                          ? 'Unknown'
                          : this.props.accountValues.firstName}{' '}
                      </p>
                    </div>
                    <div className="col col-xs-6 col-md-6 no-pad ">
                      <p className="body-label">Last Name </p>
                      <p className="body-data">{this.props.accountValues.lastName}</p>
                    </div>
                  </div>
                  <div className="row body-row">
                    <div className="col col-xs-5 col-md-6 no-pad ">
                      <p className="body-label">Organisation </p>
                      <p className="body-data">{this.props.accountValues.organisation} </p>
                    </div>

                    <div className="col col-xs-12 col-md-6 no-pad custiddata ">
                      <p className="body-label">Mobile </p>

                      <p className="body-data">{this.props.accountValues.mobile}</p>
                    </div>
                  </div>
                  <div className="row body-row">
                    <div className=".col col-xs-6 col-md-6 no-pad ">
                      <p className="body-label">Email </p>
                      <p className="body-data">{this.props.accountValues.emailId}</p>
                    </div>
                    <div className="col col-xs-3 col-md-6 no-pad Currentaccount">
                      <p className="body-label">Current Account Status </p>
                      <p className="body-data">{this.props?.accountValues?.leadgenStatus ? this.props?.accountValues?.leadgenStatus : 'NA'}</p>
                    </div>
                  </div>
                  <div className="row body-row">
                    <div className="col col-xs-3 col-md-6 no-pad ">
                      <p className="body-label">Partner Intent Shown </p>
                      <p className="body-data">{this.props.accountValues.partnerOptIn ? 'Yes' : 'No'}</p>
                    </div>
                  </div>
                </Col>
                <Col className="rightsection" md={4} lg={4}>
                  <div className="box-custid">
                    <div className=" col-xs-12 col-md-12 no-pad custiddata ">
                      <p className="body-label">Customer Id(s) </p>
                      <div className="mobilelist">
                        <p className="body-data">
                          {this.props?.custIds?.map((item, i) => {
                            return (
                              <>
                                <span className="count">{i + 1}.</span>
                                {item}

                                {this.props.primarycustId != item && <i class="fa fa-check" aria-hidden="true"></i>}
                                {/* {this.props.accountValues.custId && this.props.accountValues?.custId?.length > 0 ? this.props.accountValues.custId : ''}{' '} */}
                                <i
                                  id={this.props.accountValues.custId}
                                  onClick={this.removeMyAccountCustIds.bind(this)}
                                  className="fa fa-times"
                                  aria-hidden="true"
                                ></i>
                              </>
                            );
                          })}
                        </p>
                      </div>
                    </div>
                    {/* <div className="col col-xs-12 col-md-12 no-pad ">
                    <p className="body-label">Mobile </p>
                    <p className="body-data">
                      {this.props.accountValues.custId && this.props.accountValues?.custId?.length > 0 ? this.props.accountValues.custId : ''}
                     
                    </p>
                   
                  </div> */}

                    <span className="btncusid" onClick={this.handleOpenModal.bind(this)}>
                      <i className="fa fa-plus" aria-hidden="true"></i> Add New Cust ID{' '}
                    </span>
                  </div>
                </Col>
              </Col>
            </Row>
          </Container>
        </section>
        <Modal className={'custIdModal'} show={this.state.modalAccount} onHide={this.handleModalClose.bind(this)}>
          <Modal.Header className="no-border" closeButton>
            <h3 className="heading3 no-margin">Update Cust Id</h3>
          </Modal.Header>
          <Modal.Body>
            {this.props.successMsg && <Alert variant="success">{this.props.successMsg}</Alert>}
            {this.props.errorMsg && <Alert variant="danger">{this.props.errorMsg}</Alert>}

            <div className="col-md-12 m-t-40 margin-btm-50">
              <Input
                label={'CustID'}
                onChange={this.saveCaAccount.bind(this)}
                required
                name="custID"
                value={this.state.caNumber}
                defaultValue={this.state.caNumber}
                success={this.props.custIdSuccessStatus ? 'Cust Id verified' : ''}
                error={this.props.custIdErrorStatus ? 'Please Enter valid Cust Id' : ''}
                disabled={this.props.custIdSuccessStatus ? true : false}
                maxLength="10"
              />
              <p
                onClick={this.verifyCustId.bind(this)}
                className={`verify-btn pull-right ${this.state.disabledVerify ? 'disabled' : ''}`}
                // variant="link"
                // {`{this.props.custIdSuccessStatus} ? 'disabled' : ''`}
              >
                Verify
                {/* ${this.state.disabledVerify ? 'disabled' : '' */}
                {this.props.custIdLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
              </p>
              {/* )} */}
            </div>

            <div className="col-md-12 m-t-40 margin-btm-50 display-flex">
              <Form.Control as="select" disabled={true} value={'91'} className="phone-code">
                <option value={'91'}>+{'91'}</option>;
              </Form.Control>
              <PhoneNumber
                id="phoneno"
                showLoader={this.props.sendOtpLoader}
                // otpDisabled={this.state.otpDisabled}
                otpDisabled={false}
                timeStr={this.state.otpTime}
                otpText={this.state.OtpText}
                label={'Mobile Number'}
                value={this.props?.verified_user?.mobile}
                required
                name="mobile"
                error={this.state.error.mobile}
                // disableSendOtpLink={this.props?.verified_user?.mobile?.length > 0}
                disableSendOtpLink={this.props.otpStatus == 'success' ? !this.props.otpStatus == 'success' : this.props?.verified_user?.mobile?.length > 0}
                onChange={this.saveValue.bind(this, 'mobile')}
                otpClick={this.validateMobileNumber.bind(this)}
                disabled={true}
              />
              {/* <Input label={'Phone No'} name="phoneno" value={this.props?.verified_user?.mobile} defaultValue={'dfldkfl'} disabled={true} /> */}
            </div>

            {this.props.captcha && (
              <div className="col-md-12 m-t-40 margin-btm-50 display-flex">
                {this.props.captcha && <Captcha base64Data={this.props.captcha} clickEvent={this.props.refreshCaptcha}></Captcha>}
              </div>
            )}
            {this.props.captcha && (
              <div className="col-md-12 m-t-40 margin-btm-50">
                {/* <span class="fa-stack fa-2x">
                  <img src="/assets/icons/otp.svg" />
                </span> */}
                <Input
                  id="captcha"
                  maxlength="6"
                  label={'Captcha'}
                  onChange={this.saveValue.bind(this, 'captcha')}
                  error={this.state.error?.captcha}
                  required
                  value={this.state?.captcha}
                  defaultValue={this.state?.captcha}
                  name="captcha"
                  type="text"
                />
              </div>
            )}

            <div className="col-md-12 m-t-40 margin-btm-50">
              <Otp
                id="otp"
                label={'Otp'}
                showLoader={this.props?.verifyOtpLoader}
                otpDisabled={this.props.otpStatus == 'success'}
                verifyState={this.props.otpStatus}
                verifyMsg={this.props.otp_success_msg}
                verifyClick={this.verifyClickNow.bind(this)}
                error={this.state.error.otp}
                onChange={this.saveValue.bind(this, 'otp')}
                disabled={!this.state.otpSent || this.props.otpStatus == 'success'}
                required
                name="otp"
                value={this.state.otp}
                btnDisabled={!this.state.otpSent || this.props.otpStatus == 'success'}
              />
              {/* otp_status: 'fail', otp_messgae: 'Please enter valid OTP' */}
              {this.state.otp_status == 'fail' && !this.props.otpStatus && <span className="error">{this.state.otp_messgae}</span>}
            </div>

            {/* <div className="col-md-12 m-t-40 m-bottom-20">{this.props.partnerError && <Alert variant="danger">{this.props.partnerError}</Alert>}</div> */}
            {this.props.otpStatus == 'success' && (
              <div className="col-md-12 m-t-40 m-bottom-20">
                <Button className="submit-btn pull-right" variant="default" onClick={this.subscribeCustId.bind(this)}>
                  Update
                  {/* {this.props.parterLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"></Spinner>} */}
                </Button>
              </div>
            )}
          </Modal.Body>
        </Modal>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  accountValues: state.accountReducer?.accountDetails,
  error: state.accountReducer?.accountDetails,
  custIdSuccessStatus: state.accountReducer?.verified_user?.responseCode && state.accountReducer?.verified_user?.responseCode == '0',
  custIdErrorStatus: state.accountReducer?.verified_user?.responseCode && state.accountReducer?.verified_user?.responseCode == '1',
  custIdLoader: state.accountReducer.custIdLoader,
  successMsg: state.accountReducer?.msg,
  errorMsg: state.accountReducer?.errormsg,
  sendOtpLoader: state.accountReducer.sendOtpLoader,
  verified_user: state.accountReducer.verified_user,
  isOtpSent: state.accountReducer.isOtpSent,
  verifyOtpLoader: state.accountReducer.verifyOtpLoader,
  otpStatus: state.accountReducer.otpStatus,
  otp_success_msg: state.accountReducer.otp_success_msg,
  captcha: state.accountReducer.captcha,
  custIds: state.accountReducer.custIds,
});
const mapDispatchToProps = (dispatch) => ({
  getAccountData: () => dispatch(getAccountData()),
  verify_user: (custId) => dispatch(custICheckAction(custId)),
  updateCustId: (custId) => dispatch(updateCustId(custId)),
  custIDLoaderAction: (value) => dispatch(custIDLoaderAction(value)),
  clearData: () => dispatch(clearData()),
  sendOtpLoaderAction: (flag) => dispatch(sendOtpLoaderAction(flag)),
  sendOtpCAUser: (mobile) => dispatch(sendOtpCAUser(mobile)),
  verifyOtpAPI: (otp, captcha) => dispatch(verifyOtpAction(otp, captcha)),
  setServerError: (msg) => dispatch(setServerError(msg)),
  verifyOTPLoader: (flag) => dispatch(verifyOTPLoader(flag)),
  refreshCaptcha: () => dispatch(refreshCaptcha()),
  removeCustId: (custId) => dispatch(removeCustId(custId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Account);

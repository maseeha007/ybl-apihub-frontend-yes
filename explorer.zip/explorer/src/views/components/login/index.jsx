import React from 'react';
import PhoneNumber from '../../components/forms/phoneNumber';
import InputWithAction from '../../components/forms/InputWithAction'
import Input from '../../components/forms/input';
import { Form, Button, Spinner } from 'react-bootstrap';
import Radio from '../../components/forms/radio';
import './style.scss';
import 'font-awesome/css/font-awesome.min.css';
import {
  sendOtpOnMobileNumber, psmBtnLoaderAction, verifyOtpMobile, disableOTP,
  saveMobile, saveOtp, setErrorAction, sendOtpLoader, loginBtnLoaderAction,
  savePhoneCode, pmsloginAction, psmAdIdAction, refreshTokenAction, emptyCustomerCaptcha, emptyPSMCaptcha
} from './action';
import { connect } from 'react-redux';
import { Alert } from 'react-bootstrap';
import Number from '../../components/forms/number';
import { setTab } from '../../pages/pdp/actions';
import Captcha from '../../components/captcha';
import { trackRegisterAttemptEvent, trackLoginSuccessEvent, trackLoginAttemptEvent, globalClickEvent } from '../../../analytics';

const PhoneNumbers = {
  "IN": "91", "BD": "880", "BE": "32", "BF": "226", "BG": "359", "BA": "387", "BB": "1-246", "WF": "681",
  "BL": "590", "BM": "1-441", "BN": "673", "BO": "591", "BH": "973", "BI": "257", "BJ": "229", "BT": "975", "JM": "1-876",
  "BW": "267", "WS": "685", "BQ": "599", "BR": "55", "BS": "1-242", "JE": "44-1534", "BY": "375", "BZ": "501", "RU": "7",
  "RW": "250", "RS": "381", "TL": "670", "RE": "262", "TM": "993", "TJ": "992", "RO": "40", "TK": "690", "GW": "245", "GU": "1-671",
  "GT": "502", "GR": "30", "GQ": "240", "GP": "590", "JP": "81", "GY": "592", "GG": "44-1481", "GF": "594", "GE": "995",
  "GD": "1-473", "GB": "44", "GA": "241", "SV": "503", "GN": "224", "GM": "220", "GL": "299", "GI": "350", "GH": "233",
  "OM": "968", "TN": "216", "JO": "962", "HR": "385", "HT": "509", "HU": "36", "HK": "852", "HN": "504", "HM": " ",
  "VE": "58", "PR": "1-787 and 1-939", "PS": "970", "PW": "680", "PT": "351", "SJ": "47", "PY": "595", "IQ": "964", "PA": "507",
  "PF": "689", "PG": "675", "PE": "51", "PK": "92", "PH": "63", "PN": "870", "PL": "48", "PM": "508", "ZM": "260", "EH": "212",
  "EE": "372", "EG": "20", "ZA": "27", "EC": "593", "IT": "39", "VN": "84", "SB": "677", "ET": "251", "SO": "252", "ZW": "263",
  "SA": "966", "ES": "34", "ER": "291", "ME": "382", "MD": "373", "MG": "261", "MF": "590", "MA": "212", "MC": "377", "UZ": "998",
  "MM": "95", "ML": "223", "MO": "853", "MN": "976", "MH": "692", "MK": "389", "MU": "230", "MT": "356", "MW": "265", "MV": "960",
  "MQ": "596", "MP": "1-670", "MS": "1-664", "MR": "222", "IM": "44-1624", "UG": "256", "TZ": "255", "MY": "60", "MX": "52",
  "IL": "972", "FR": "33", "IO": "246", "SH": "290", "FI": "358", "FJ": "679", "FK": "500", "FM": "691", "FO": "298", "NI": "505",
  "NL": "31", "NO": "47", "NA": "264", "VU": "678", "NC": "687", "NE": "227", "NF": "672", "NG": "234", "NZ": "64", "NP": "977",
  "NR": "674", "NU": "683", "CK": "682", "CI": "225", "CH": "41", "CO": "57", "CN": "86", "CM": "237", "CL": "56",
  "CC": "61", "CA": "1", "CG": "242", "CF": "236", "CD": "243", "CZ": "420", "CY": "357", "CX": "61", "CR": "506", "CW": "599",
  "CV": "238", "CU": "53", "SZ": "268", "SY": "963", "SX": "599", "KG": "996", "KE": "254", "SS": "211", "SR": "597", "KI": "686",
  "KH": "855", "KN": "1-869", "KM": "269", "ST": "239", "SK": "421", "KR": "82", "SI": "386", "KP": "850", "KW": "965", "SN": "221",
  "SM": "378", "SL": "232", "SC": "248", "KZ": "7", "KY": "1-345", "SG": "65", "SE": "46", "SD": "249", "DO": "1-809 and 1-829",
  "DM": "1-767", "DJ": "253", "DK": "45", "VG": "1-284", "DE": "49", "YE": "967", "DZ": "213", "US": "1", "UY": "598", "YT":
    "262", "UM": "1", "LB": "961", "LC": "1-758", "LA": "856", "TV": "688", "TW": "886", "TT": "1-868", "TR": "90", "LK": "94",
  "LI": "423", "LV": "371", "TO": "676", "LT": "370", "LU": "352", "LR": "231", "LS": "266", "TH": "66", "TG": "228",
  "TD": "235", "TC": "1-649", "LY": "218", "VA": "379", "VC": "1-784", "AE": "971", "AD": "376", "AG": "1-268", "AF": "93",
  "AI": "1-264", "VI": "1-340", "IS": "354", "IR": "98", "AM": "374", "AL": "355", "AO": "244", "AS": "1-684",
  "AR": "54", "AU": "61", "AT": "43", "AW": "297", "AX": "358-18", "AZ": "994", "IE": "353",
  "ID": "62", "UA": "380", "QA": "974", "MZ": "258"
}

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      disableOTP: true,
      error: {},
      ...props,
      loginAttempts: 0,
      otpAttempts: 0,
      otpLink: true,
      phonecode: '91',
      otpText: "Send OTP",
      roleType: 'customer'
    };
    this.timer = null
    localStorage.setItem("userType", "customer")
  }

  saveValue(name, e) {
    const value = e.target.value.replace(/\D/g, "");
    this.setState({ ...this.state, [name]: value })
    if (name == "mobile") {
      this.props.saveMobile(value);
      localStorage.setItem("loginmobileNumber", value)
    }
    if (name === "otp") {
      this.props.saveOtp(value);
    }
  }
  saveCaptchaValue(name, e) {
    const value = e.target.value;
    this.setState({ ...this.state, [name]: value })
  }
  saveValueLDAPLogin(name, e) {
    let value = e.target.value;
    this.setState({ ...this.state, [name]: value }, () => {
      if (name === 'adId' && this.state?.adId?.length >= 10) {
        this.props.psmAdId(this.state?.adId);
        localStorage.setItem("loginAdId", value)

      }
    });

  }
  saveCode(name, e) {
    let code = e.target.value
    this.setState({ ...this.state, phonecode: code }, () => {
      this.props.savePhoneCode(code)
    })
  }
  login() {
    let flag = false
    let errObj = {}
    let dataObj = {}
    this.props.emptyError("");

    if (!this.state.mobile) {
      errObj['mobile'] = 'Please enter registered mobile number';
      document.getElementById("phoneno").focus();

      flag = true
    }
    else if (this.state.mobile && this.state.mobile.length < 10) {
      errObj['mobile'] = 'Please enter 10 digit registered mobile number';

      flag = true
    }
    else {
      dataObj['mobile'] = this.state.mobile
    }

    if (!this.state.otp) {
      errObj['otp'] = 'Please Enter OTP';
      if (!flag) {
        document.getElementById("otp-section").focus();
      }
      flag = true
    } if (this.state.otp && this.state.otp.length < 6) {
      errObj['otp'] = 'Enter Valid OTP';
      if (!flag) {
        document.getElementById("otp-section").focus();
      }
      flag = true
    } else {
      if (this.state.otp && this.state.otp.length === 6) {
        dataObj['otp'] = this.state.otp
        errObj['otp'] = ''
      }
    }
    if (this.state.captcha) {
      dataObj['captcha'] = this.state.captcha;
      errObj['captcha'] = ''
    } else {
      errObj['captcha'] = 'Please Enter Captcha';
      flag = true
    }
    this.setState({ ...this.state, error: { ...this.state.error, ...errObj } });

    if (!flag) {
      trackLoginAttemptEvent()
      debugger;
      this.props.verifyOTP(this.state.captcha);
      this.props.loginBtnLoaderAction(true);

    }
  }

  validateMobileNumber() {
    globalClickEvent('button clicked verify otp')
    let flag = false;
    let errObj = {}
    let dataObj = {}

    if (!this.state.mobile) {
      errObj['mobile'] = 'Please enter registered mobile number';
      flag = true
      document.getElementById("phoneno").focus();
    } else if (this.state.mobile && this.state.mobile.length < 10) {
      errObj['mobile'] = 'Please enter 10 digit registered mobile number';
      if (!flag) {
        document.getElementById("otp").focus();
      }
      flag = true
    } else {
      dataObj['mobile'] = this.state.mobile;
      errObj['mobile'] = '';
    }
    this.setState({ ...this.state, error: { ...this.state.error, ...errObj } });

    let tryCount = (this.state.otpAttempts ? ++this.state.otpAttempts : 1)



    if (!flag && !this.state.otpDisabled) {
      this.props.sendOtp(this.state.otpAttempts, this.state.phonecode, this.state.mobile);
      this.props.disableOTP();
      this.props.sendOtpLoader(true);

    }
  }

  loginwithPSM() {
    let flag = false;
    let errObj = {}
    let dataObj = {}
    if (!this.state.adId) {
      errObj['adId'] = 'Please enter valid ADID';
      flag = true
      document.getElementById("adId").focus();
    } else {
      dataObj['adId'] = this.state.adId;
      errObj['adId'] = '';
    }

    if (!this.state.password) {
      errObj['password'] = 'Please enter password';
      if (!flag) {
        flag = true
      }
    } else {
      dataObj['password'] = this.state.password;
      errObj['password'] = '';
    }
    if (!this.state.captcha) {
      errObj['captcha'] = 'Please enter captcha';
      if (!flag) {
        flag = true
      }
    } else {
      dataObj['captcha'] = this.state.captcha;
      errObj['captcha'] = '';
    }
    this.setState({ ...this.state, error: { ...this.state.error, ...errObj } });

    if (!flag) {
      this.props.psmBtnLoaderAction(true);
      this.props.pmsloginAction(dataObj.adId, dataObj.password, dataObj.captcha);
      trackLoginSuccessEvent()
    }
    // }
  }
  componentDidMount() {
    document.getElementById('otp-section').setAttribute("disabled", "disabled");
    if (Date.now() - localStorage.getItem('LoginAtteptTimeStart') > 120000) {
      localStorage.removeItem('LoginAtteptTimeStart')
      localStorage.setItem('LoginAtteptCount', 0)
      this.setState({ ...this.state, loginAttempts: 0 })
    } else {
      this.setState({ ...this.state, loginAttempts: parseInt(localStorage.getItem('LoginAtteptCount')) })
    }

    if (Date.now() - localStorage.getItem('OTPAtteptTimeStart') > 120000) {
      localStorage.removeItem('OTPAtteptTimeStart')
      localStorage.setItem('OTPAtteptCount', 0)
      this.setState({ ...this.state, otpAttempts: 0 })
    } else {
      this.setState({ ...this.state, otpAttempDisabled: (parseInt(localStorage.getItem('OTPAtteptCount')) > 2 ? true : false), otpAttempts: parseInt(localStorage.getItem('OTPAtteptCount')) })
    }
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevProps.state?.loginReducer?.errorMsg !== this.props.state?.loginReducer?.errorMsg && this.props.state.loginReducer.errorMsg == 'Incorrect OTP') {
      let atteptCount = (this.state.loginAttempts ? ++this.state.loginAttempts : 1)
      if (atteptCount == 1) {
        localStorage.setItem('LoginAtteptTimeStart', String(Date.now()))
      }
      if (atteptCount > 2) {
        let countTime = localStorage.getItem('LoginAtteptTimeStart')
        if (Date.now() - countTime > 120000) {
          localStorage.setItem('LoginAtteptTimeStart', String(Date.now()))
          this.setState({ ...this.state, loginAttempts: 0 })
        } else {
          localStorage.setItem('LoginAtteptCount', atteptCount)
          this.setState({ ...this.state, loginAttempts: atteptCount })
        }
      } else {
        localStorage.setItem('LoginAtteptCount', atteptCount)
        this.setState({ ...this.state, loginAttempts: atteptCount })
      }
    }


    if (prevProps.state.loginReducer.errorType !== this.props.state.loginReducer.errorType && this.props.state.loginReducer.errorType === "INVALID_NUMBER") {
      document.getElementById('otp-section').setAttribute("disabled", "disabled");
    }
    if (this.props.showOtp !== prevProps.showOtp && this.props.showOtp) {
      this.setState({ ...this.state, otpSent: true, otpDisabled: true, startTimer: true })
      this.timer = setInterval(() => {
        this.setState({ ...this.state, otpTime: (this.state.otpTime ? this.state.otpTime - 1 : 60) })
      }, 1000)
      document.getElementById('otp-section').removeAttribute("disabled");
      setTimeout(() => {
        clearInterval(this.timer)
        this.setState({ ...this.state, otpDisabled: false, otpTime: 0, otpLink: true, startTimer: false, OtpText: 'Resend OTP' })
      }, 60000);
    }
    if (this.props.state?.loginReducer?.gotOTP) {
      if (this.props.login) {
        this.props.modalclose();
      }
      localStorage.setItem('userName', this.props.user_data.username)
      localStorage.setItem('token', this.props.user_data.token)
      localStorage.setItem('role', this.props.user_data.role)
      const pathName = window.location.pathname;
      const tab = localStorage.getItem("tab");
      if (tab) {
        this.props.setTab()
      }
      let url = window.location.href;
      localStorage.setItem('hitLoginSuccess', true)
      if (pathName === "/register") {
        url = "/";
        window.location.href = url;
        trackLoginSuccessEvent()

      } else {
        trackLoginSuccessEvent()
        debugger;
        window.location.reload();
        trackLoginSuccessEvent()

      }
    }
  }

  componentWillUnmount() {
    this.props.disableOTP();
    this.props.emptyError();
    clearInterval(this.timer);
    const pathName = window.location.pathname;
    let url = window.location.href;
    if (pathName === "/register") {
      url = "/";
      window.location.href = url;
    }
  }
  selectCustomer(type) {
    const state = this.state;
    state.adId = '';
    state.password = ''
    state.captcha = '';
    state.mobile = '';
    state.otp = ''
    this.setState({ ...state, otpDisabled: false, otpTime: 0, roleType: type, error: {} });
    this.props.emptyError("");
    this.props.emptyPSMCaptcha();
    clearInterval(this.timer);
    localStorage.setItem("userType", "Customer")
  }
  selectPSM(type) {
    const state = this.state;
    state.adId = '';
    state.password = ''
    state.captcha = '';
    state.mobile = '';
    state.otp = ''
    this.setState({ ...state, otpDisabled: false, otpTime: 0, roleType: type, error: {} });
    this.props.emptyError("");
    this.props.emptyCustomerCaptcha();
    clearInterval(this.timer);
    localStorage.setItem("userType", "PSM")

  }

  gotoRegisterPage() {
    trackRegisterAttemptEvent();
    window.location.href = '/register'
  }

  render() {
    const phonesCodes = Object.values(PhoneNumbers);
    console.log('under rander Navi  ', this.state)
    return (
      <React.Fragment>
        <section id="login">
          <div className="container form-wrapper">
            {this.props?.state?.loginReducer?.errorMsg && <Alert key="login-error" variant='danger'>
              {this.props?.state?.loginReducer?.errorMsg}
            </Alert>}
            {this.state?.multiAttepts && <Alert key="login-error" variant='danger'>
              Too Many Attempts! Please try after some time
            </Alert>}
            {(localStorage.getItem("userLogin") === "NO") && <Alert key="login-error" variant='danger'>
              Your session has expired. Please relogin
            </Alert>}

            <div className="usertype-section">
              <span class="fa-stack fa-2x">
                <img src="/assets/icons/role.svg" />
              </span>
              <div className="sub-section phone-section-block">
                <Radio label={'Customer'} value="customer" name="account-title" onClick={this.selectCustomer.bind(this, 'customer')} checked={this.state.roleType === "customer"} />
                <Radio label={'Bank'} value="psm" className="psm" onClick={this.selectPSM.bind(this, 'psm')} name="account-title" checked={this.state.roleType === "psm"} />
              </div>
            </div>
            {this.state.roleType === "customer" && <> <div className="moblie-section">
              <span class="fa-stack fa-2x">
                <img src="/assets/icons/phone.svg" />
              </span>
              <div className="sub-section phone-section-block">
                <Form.Control as="select" name="phonecode" className="phone-code" onChange={this.saveCode.bind(this, 'phonecode')}>
                  {phonesCodes.map(function (phone, index) {
                    return <option key={index} selected={phone == String("91").replace('+', '')} value={phone} >+{phone}</option>;
                  })}
                </Form.Control>

                <PhoneNumber id="phoneno" showLoader={this.props.sendOtpLoaderStatus} otpDisabled={this.state.otpDisabled || this.state.otpAttempDisabled} timeStr={this.state.otpTime} otpText={this.state.OtpText} label={'Mobile Number'} value={this.state.mobile} required name="mobile" error={this.state.error.mobile} disableSendOtpLink={this.state?.mobile?.length > 0} onChange={this.saveValue.bind(this, 'mobile')} otpClick={this.validateMobileNumber.bind(this)} />
              </div>
            </div>

              <div className="moblie-section">
                <span class="fa-stack fa-2x">
                  <img src="/assets/icons/otp.svg" />
                </span>
                <Number id="otp" otpdisable={this.state.otpSent} label={'Otp'} required name="otp" value={this.state.otp} error={this.state.error.otp} onChange={this.saveValue.bind(this, 'otp')} size="6" />
              </div>
              <div className="moblie-section">
                {this.props.customerCaptcha && <Captcha base64Data={this.props.customerCaptcha} clickEvent={this.props.customerNewToken}></Captcha>}
              </div>
              {this.props.customerCaptcha && <div className="moblie-section">
                <span class="fa-stack fa-2x">
                  <img src="/assets/icons/otp.svg" />
                </span>
                <Input id="captcha" maxlength="6" label={'Captcha'} onChange={this.saveCaptchaValue.bind(this, 'captcha')} error={this.state.error.captcha} required value={this.state.captcha} defaultValue={this.state.captcha} name="captcha" type="text" />
              </div>}
              <div className="action-section">
                <Button className="submit-btn" variant="primary" onClick={this.login.bind(this)}>Login
                  {this.props.loginBtnLoaderStatus && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                </Button>
              </div> </>}

            {/* PSM  */}
            {this.state.roleType === "psm" && <>
              <div className="moblie-section">
                <span class="fa-stack fa-2x">
                  <img src="/assets/icons/phone.svg" />
                </span>
                <div className="sub-section phone-section-block">
                  <Input id="adId" maxlength="10" label={'ADID'} onChange={this.saveValueLDAPLogin.bind(this, 'adId')} error={this.state.error.adId} required value={this.state.adId} defaultValue={this.state.adId} name="adId" />
                </div>
              </div>

              <div className="moblie-section">
                <span class="fa-stack fa-2x">
                  <img src="/assets/icons/otp.svg" />
                </span>
                <Input id="password" maxlength="35" label={'Password'} onChange={this.saveValueLDAPLogin.bind(this, 'password')} error={this.state.error.password} required value={this.state.password} defaultValue={this.state.password} name="password" type="password" />
              </div>
              <div className="moblie-section">
                {this.props.psmCaptcha && <Captcha base64Data={this.props.psmCaptcha} clickEvent={this.props.psmNewToken} ></Captcha>}
              </div>

              {this.props.psmCaptcha && <div className="moblie-section">
                <span class="fa-stack fa-2x">
                  <img src="/assets/icons/otp.svg" />
                </span>
                <Input id="captcha" maxlength="6" label={'Captcha'} onChange={this.saveValueLDAPLogin.bind(this, 'captcha')} error={this.state.error.captcha} required value={this.state.captcha} defaultValue={this.state.captcha} name="captcha" type="text" />
              </div>}
              <div className="action-section">
                <Button className="submit-btn" variant="primary" onClick={this.loginwithPSM.bind(this)}>Login{this.props.psmLoader}
                  {this.props.psmLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                </Button>
              </div> </>}
            {this.state.roleType === "customer" && <p className="reg"> Not a Registered user? <a className="link" onClick={this.gotoRegisterPage}>Register</a> </p>}
          </div>
        </section>
      </React.Fragment>
    )
  }
}


const mapStateToProps = state => {
  return {
    state,
    user_data: state.loginReducer.user_data,
    login: state.headerReducer.loginModal,
    showOtp: state.loginReducer.showOtp,
    sendOtpLoaderStatus: state.loginReducer.sendOtpLoader,
    loginBtnLoaderStatus: state.loginReducer.loginbtnLoader,
    psmLoader: state.loginReducer.psmLoader,
    customerCaptcha: state.loginReducer.customerCaptcha,
    psmCaptcha: state.loginReducer.psmCaptcha

  };
};

const mapDispatchToProps = (dispatch) => ({
  sendOtp: (attempts, code, mobile) => dispatch(sendOtpOnMobileNumber(attempts, code, mobile)),
  verifyOTP: (captcha) => dispatch(verifyOtpMobile(captcha)),
  disableOTP: () => dispatch(disableOTP()),
  saveMobile: (number) => dispatch(saveMobile(number)),
  saveOtp: (otp) => dispatch(saveOtp(otp)),
  emptyError: () => dispatch(setErrorAction("")),
  setTab: (name) => dispatch(setTab(name)),
  sendOtpLoader: (name) => dispatch(sendOtpLoader(name)),
  loginBtnLoaderAction: (name) => dispatch(loginBtnLoaderAction(name)),
  savePhoneCode: (code) => dispatch(savePhoneCode(code)),
  pmsloginAction: (adid, password, captcha) => dispatch(pmsloginAction(adid, password, captcha)),
  psmBtnLoaderAction: (flag) => dispatch(psmBtnLoaderAction(flag)),
  psmAdId: (id) => dispatch(psmAdIdAction(id)),
  psmNewToken: () => dispatch(refreshTokenAction("P")),
  customerNewToken: () => dispatch(refreshTokenAction("C")),
  emptyCustomerCaptcha: () => dispatch(emptyCustomerCaptcha()),
  emptyPSMCaptcha: () => dispatch(emptyPSMCaptcha())

});

export default connect(mapStateToProps, mapDispatchToProps)(Login);


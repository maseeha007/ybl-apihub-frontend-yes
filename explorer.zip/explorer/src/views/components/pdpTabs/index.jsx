import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Features from '../../components/features';
import Content from '../../components/content';
import PartnerBanner from '../../components/partnerbanner';
import Defination from '../../components/defination';

import { Tabs, Tab, Table, ListGroup, Spinner, Button, Modal } from 'react-bootstrap';
import './style.scss';
import { onSubscribeBtnClick, globalClickEvent } from '../../../analytics';
const PDPTabs = (props) => {

    const offers = {
        title: 'What does this offer',
        data: 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.'
    }

    const functions = {
        title: 'Functionalities',
        data: 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which do not look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.'
    }
    const parseQuery = (queryString) => {
        var query = {};
        var pairs = (queryString[0] === "?"
            ? queryString.substr(1)
            : queryString
        ).split("&");
        for (var i = 0; i < pairs.length; i++) {
            var pair = pairs[i].split("=");
            query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || "");
        }
        return query;
    }

    let qs = parseQuery(window.location.search);
    const token = localStorage.getItem('token');
    let tabKey = localStorage.getItem('tab') ? localStorage.getItem('tab') : props.currentTab;
    if (!token) {
        tabKey = props.currentTab;
    }
    const [key, setTabKey] = useState(tabKey);

    const changeTab = (key) => {
        const loginAcess = localStorage.getItem("userLogin")
        props.setTab(key)
        if (key === 'api-defination') {
            if (!token || loginAcess === "NO") {
                props.openModal();
                localStorage.setItem('tab', "api-defination");
            } else {
                localStorage.removeItem('tab')
                setTabKey(key);
            }
        } else {
            localStorage.removeItem('tab')
            setTabKey(key);
        }

    }
    const checkLogin = () => {
        const token = localStorage.getItem('token');
        if (!token) {
            props.openModal();
        } else {
            globalClickEvent('Subscribe Product btn clicked')
            window.location.href = `${window.location.origin}/subscribe?id=${qs.id}&name=${qs.name}&solutionName=${props?.solutionName}`;
            globalClickEvent('Subscribe Product btn clicked')
            // const payload = {
            //     productName: qs.name,
            //     productType: 'banking product',
            //     partnerName: null,
            //     solutionName: props?.solutionName,
            // };
            // onSubscribeBtnClick(payload);
        }
    }

    const openLoginModal = () => {
        const token = localStorage.getItem('token');
        if (!token) {
            localStorage.setItem('tab', "overview");
            props.openModal();
        }
    }
    const pdfDownload = [
        'Beneficiary Maintenance',
        'E-Collect',
        'Fund Transfer',
        'Bulk Payments',
        'Individual Inward Remittance',
        'Dealer Finance'

    ]
    const showpdf = pdfDownload.indexOf(qs.name) > -1
    const apiDef = ['E-Collect', 'Fund Transfer', 'Bulk Payments', 'Beneficiary Maintenance', 'Dealer Finance']
    const showApiDef = apiDef.indexOf(qs.name) > -1
    debugger
    return (

        <div className="tab-section">
            <div className={`tab-data ${showApiDef ? '' : 'tab-data1'}`}>
                <Tabs activeKey={key} id="uncontrolled-tab-example"
                    onSelect={(k) => changeTab(k)}
                >
                    <Tab eventKey="overview" title="Overview" >
                        {localStorage.getItem("role") !== "PSM" && <> {props.isSubscribed !== null ? <div className="sub-btn-mobile">
                            {/* <p className="submit-link" variant="default" onClick={checkLogin}>Subscribe</p> */}
                            {props.isSubscribed === false && <p className="submit-link" variant="default" onClick={checkLogin}>Subscribe</p>}
                            {props.isSubscribed === true && <p className="subscribed" variant="default" >Subscribed</p>}
                        </div> : <div className="sub-btn">
                            <p className="submit-link submit-link-1" variant="default">Loading.... <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /></p>
                        </div>} </>}

                        <div className="overview-detail" dangerouslySetInnerHTML={{ __html: props?.overviewdata?.introduction }} />
                        <Features data={props?.feature} />
                        {props?.overviewdata?.offer && <Content title={offers.title} data={props?.overviewdata?.offer} />}
                        {props?.overviewdata?.functionalities && <Content title={functions.title} data={props?.overviewdata?.functionalities} />}
                        <PartnerBanner checkLogin={openLoginModal} />

                    </Tab>
                    {/* <Tab eventKey="visions" title="Versions" >
                        {localStorage.getItem("role") !== "PSM" && <> {props.isSubscribed !== null ? <div className="sub-btn-mobile">
                            {props.isSubscribed === false && <p className="submit-link" variant="default" onClick={checkLogin}>Subscribe</p>}
                            {props.isSubscribed === true && <p className="subscribed" variant="default" >Subscribed</p>}
                        </div> : <div className="sub-btn">
                            <p className="submit-link submit-link-1" variant="default">Loading.... <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /></p>
                        </div>} </>}
                        <ListGroup horizontal id="version-section">
                            <ListGroup.Item className="version-col-1">
                                <div className="heading-1">
                                    <b>Versions</b>
                                </div>
                                <div className="heading-2">
                                    <b>Status</b>
                                </div>
                            </ListGroup.Item>
                        </ListGroup>
                        {props.version && props.version.map((data) => (
                            <ListGroup horizontal>
                                <ListGroup.Item className="version-col-1">
                                    <div className="heading-1">
                                        <p> version {data.versionNumber}</p>
                                        <span>{data.modifiedDate}</span>
                                    </div>
                                    <div className={`heading-2 ${data.status}`}>
                                        {data.status}
                                    </div>

                                </ListGroup.Item>
                            </ListGroup>
                        ))}

                    </Tab> */}
                    {showApiDef &&
                        <Tab eventKey="api-defination" title="API Definition" >
                            {localStorage.getItem("role") !== "PSM" && <>{props.isSubscribed !== null ? <div className="sub-btn-mobile">
                                {props.isSubscribed === false && <p className="submit-link" variant="default" onClick={checkLogin}>Subscribe</p>}
                                {props.isSubscribed === true && <p className="subscribed" variant="default" >Subscribed</p>}
                            </div> : <div className="sub-btn">
                                <p className="submit-link submit-link-1" variant="default">Loading.... <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /></p>
                            </div>} </>}
                            {showpdf && <a style={{ float: 'right' }} href={`${window.yblDomain}/ybl/download/${qs.id}`} className="subscribed" variant="default" target="_blank" download={qs.name}>Download Pdf</a>}

                            {/* <p className="subscribed" variant="default" >Download Pdf</p> */}
                            <Defination setTab={setTabKey} />
                        </Tab>}
                </Tabs>
            </div>
            {localStorage.getItem("role") !== "PSM" && <> {props.isSubscribed !== null ? <div className="sub-btn">
                {!props.isSubscribed && <p className="submit-link pointer" variant="default" onClick={checkLogin}>Subscribe</p>}
                {props.isSubscribed && <p className="subscribed" variant="default" >Subscribed</p>}
            </div> :
                <div className="sub-btn">
                    <p className="submit-link submit-link-1" variant="default">Loading.... <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /></p>
                </div>}</>}


        </div>
    )
}
export default PDPTabs;
import { FETCH_LEAD_FAIL, FETCH_LEAD_SUCCESS, ACCEPT_LEAD_FAIL, ACCEPT_LEAD_SUCCESS, DECLINE_LEAD_SUCCESS, DECLINE_LEAD_FAIL } from './constant';


export default function storeCases(state = {}, action) {
  console.log('pkpk', action)
  switch (action.type) {
    case FETCH_LEAD_FAIL:
      return { ...state, error_msg: action.data.response }
    case FETCH_LEAD_SUCCESS:
      return { ...state, leadList: action.data.response.userList, subdata: action.data.response.userCount, error_msg: null }
    case ACCEPT_LEAD_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case ACCEPT_LEAD_SUCCESS:
      return { ...state, success_msg: "Accepted Successfully with ID: "+action.data.response, error_msg: null }
      case DECLINE_LEAD_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case DECLINE_LEAD_SUCCESS:
      return { ...state, success_msg: "Declined Successfully with ID: "+action.data.response, error_msg: null }

    default:
      return state
  }
}


import React from 'react';
import Header from '../../layout/header';
import PdpBanner from '../../components/pdpbanner';
import PDPTabs from '../../components/pdpTabs';
import Footer from '../../layout/footer';
import './style.scss';
import { connect } from "react-redux";
import { getProductOverview, getProductFeatures, getAPIVersions, getAPIDefination, setTab } from './actions';
import { parseQuery } from './../../../service/utils'
import { loginModalStatus } from '../../layout/header/action';
import { getSubscribeProduct, setSubscribleStatus } from '../../pages/subscribe/actions';
import { getAccountData } from '../../components/account/actions';
import { onLoadOfProductORPartnerDetail, globalClickEvent, subscribleClickEvent } from '../../../analytics';
class ProductDetail extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      token: localStorage.getItem('token'),
      solutionName: '',
      ...props
    }
  }
  componentDidMount() {
    const params = parseQuery(this.props.location.search);
    if (params?.id) {
      this.props.getPDPOverview(params.id);
      this.props.getPDPFeatures(params.id);
      const token = localStorage.getItem('token');
      localStorage.setItem("solutionName", params.solutionName)
      if (token) {
        this.props.getAPIDef(params.id, token);
        this.props.getSubscribeProduct(params.id, token);
      } else {
        this.props.setSubscribleStatus(false);
      }
      this.props.getAccountData();
    }
    const data = this.props?.location?.search
    if (data) {
      const payload = {
        productName: params?.name,
        solutionName: params.solutionName,
        productType: 'bank product',
        partnerName: undefined
      }
      onLoadOfProductORPartnerDetail(payload);
    }

  }
  parseQuery = (queryString) => {
    var query = {};
    var pairs = (queryString[0] === "?"
      ? queryString.substr(1)
      : queryString
    ).split("&");
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split("=");
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || "");
    }
    return query;
  }


  checkLogin = () => {
    const token = localStorage.getItem('token');
    let qs = parseQuery(window.location.search);
    debugger;
    if (!token) {
      this.props.openModal();
    } else {
      const data = {
        eventName: 'Subscribe Product btn clicked',
        productName: qs.name,
        solutionName: qs.solutionName,
      }
      window.location.href = `${window.location.origin}/subscribe?id=${qs.id}&name=${qs.name}&solutionName=${qs?.solutionName}`;


    }
  }

  render() {
    return (
      <>
        <Header />
        <PdpBanner data={this.props.location.search} checkLogin={this.checkLogin} />
        <PDPTabs solutionName={localStorage.getItem("solutionName")} overviewdata={this.props.overviewdata} feature={this.props.feature} version={this.props.version} openModal={this.props.openModal} isSubscribed={this.props.isSubscribed} setTab={this.props.setTab} currentTab={"overview"} />
        <Footer />
      </>
    )
  }
}
const mapStateToProps = (state) => ({
  overviewdata: state.pdpReducer.overview_data,
  feature: state.pdpReducer.feature_data,
  version: state.pdpReducer.version_data,
  token: state.loginReducer.otp_data.token,
  isSubscribed: state.subscribeReducer.isSubscribed,
  tab: state?.pdpReducer?.tab

});
const mapDispatchToProps = (dispatch) => {
  return {
    getPDPOverview: (id) => dispatch(getProductOverview(id)),
    getPDPFeatures: (id) => dispatch(getProductFeatures(id)),
    getVersion: (id) => dispatch(getAPIVersions(id)),
    openModal: () => dispatch(loginModalStatus(true)),
    getAPIDef: (id, token) => dispatch(getAPIDefination(id, token)),
    getSubscribeProduct: (id, token) => dispatch(getSubscribeProduct(id, token)),
    setTab: (name) => dispatch(setTab(name)),
    setSubscribleStatus: (name) => dispatch(setSubscribleStatus(name)),
    getAccountData: () => dispatch(getAccountData())
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ProductDetail);

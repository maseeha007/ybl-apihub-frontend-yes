import { all, put, takeEvery, call } from 'redux-saga/effects';
import {
  FETCH_USER,
  FETCH_USER_SUCCESS,
  FETCH_USER_FAIL,
  VERIFY_CUST,
  VERIFY_CUST_SUCCESS,
  VERIFY_CUST_FAIL,
  MAKE_SUB,
  MAKE_SUB_FAIL,
  MAKE_SUB_SUCCESS,
  GET_SUBSCRIBE_PRODUCT,
  SUB_BTN_LOADER,
  SUB_VERIFY_CUSTID_LOADER,
  YBL_SEND_OTP_LOADER,
  YBL_OTP_SENT,
  CUST_VERIFED_DATA,
  CALL_SEND_OTP,
  YBL_CALL_VERIFY_OTP,
  YBL_VERIFY_OTP_SUCCESS,
  YBL_VERIFY_OTP_STATUS,
  YBL_VERIFY_OTP_LOADER,
} from './constant';
import { fetch_user, fetch_cust_status, do_subscribe } from './apis';
import { subscribeAPI, sendEmailToUser } from './../../../service/subscribeAPI';
import { validCAUser } from '../../../service/otpAPI';
import { verifyYBLOTPAPI, validCAUserOnRegistration, sendYBLOTP } from '../../../service/otpAPI';

export function* fetchUserAsync() {
  try {
    let { data } = yield call(fetch_user);
    if (data.statusType != 'SUCCESS') {
      yield put({ type: FETCH_USER_FAIL, data: data });
    } else {
      yield put({ type: FETCH_USER_SUCCESS, data: data });
    }
  } catch (error) {
    const token = localStorage.getItem('token');
    if ('Unauthorized' === error?.response?.data?.error && token) {
      //   yield put({
      //     type:"SET_MODAL_STATUS",
      //     payload:true
      //   })
      localStorage.setItem('userLogin', 'NO');
    }
    yield put({ type: FETCH_USER_FAIL, data: { result: 'Some Network Error Occurred' } });
  }
}

export function* fetchCustStatusAsync({ payload }) {
  debugger;
  try {
    const custId = payload.custId;
    const res = yield validCAUserOnRegistration(custId);
    debugger;
    localStorage.setItem('sessionId', res?.headers['sessionid']);
    yield put({ type: VERIFY_CUST_SUCCESS, data: { response: '' } });
    // for testing

    if (res?.data?.response?.responseCode == '0') {
      yield put({ type: SUB_VERIFY_CUSTID_LOADER, payload: false });
      yield put({ type: VERIFY_CUST_SUCCESS, data: { response: 'verfied' } });
      const response = res?.data?.response;
      response.custId = custId;
      yield put({ type: 'CUST_VERIFED_DATA', payload: res?.data?.response });
    } else {
      yield put({ type: SUB_VERIFY_CUSTID_LOADER, payload: false });
      yield put({ type: VERIFY_CUST_SUCCESS, data: { response: 'notverfied' } });
    }
  } catch (error) {
    yield put({ type: VERIFY_CUST_FAIL, data: { result: 'Some Network Error Occurred' } });
    yield put({ type: MAKE_SUB_FAIL, data: { result: 'Some Network Error Occurred' } });
    yield put({ type: SUB_VERIFY_CUSTID_LOADER, payload: false });
  }
}

export function* doSubscribeAsync(action) {
  try {
    let { data } = yield call(do_subscribe.bind({}, action.payload));
    if (data.statusType != 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: MAKE_SUB_FAIL, data: { response: data.response } });
    }
    if (data.statusType != 'SUCCESS' && typeof data.response !== 'string') {
      yield put({ type: MAKE_SUB_FAIL, data: { response: data.response } });
    }
    if (data.statusType === 'SUCCESS') {
      yield put({ type: MAKE_SUB_SUCCESS, data: data });
      const { payload } = action;
      const emailPayLoad = {
        firstName: payload.fname,
        email: payload.email,
        productName: payload.prodName,
        planType: payload.plan,
      };
      const emailResponse = yield sendEmailToUser('yblProductSubscribe', emailPayLoad);
      if (emailResponse.data.statusType === 'FAIL') {
        yield put({
          type: MAKE_SUB_FAIL,
          data: { response: 'Data Saved Email not Sent' },
        });
      }
    }

    yield put({ type: SUB_BTN_LOADER, payload: false });
  } catch (error) {
    yield put({ type: MAKE_SUB_FAIL, data: { response: 'Some Network Error Occurred' } });
    yield put({ type: SUB_BTN_LOADER, payload: false });
    const token = localStorage.getItem('token');
    if ('Unauthorized' === error?.response?.data?.error && token) {
      //    yield put({
      //     type:"SET_MODAL_STATUS",
      //     payload:true
      //   })
      localStorage.setItem('userLogin', 'NO');
    }
  }
}
export function* getSubscrible({ payload }) {
  try {
    const data = yield subscribeAPI(payload?.id, payload?.token)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data.httpCode : e.message;
        return errorObj;
      });
    if (data?.statusType === 'SUCCESS') {
      yield put({ type: 'GET_SUBSCRIBE_DATA', payload: data?.response?.isSubscribed });
      yield put({ type: 'GET_UAT_STATUS', payload: data.response.environment.includes('uat') });
      yield put({ type: 'GET_PROD_STATUS', payload: data.response.environment.includes('production') });
    }
    if (data?.statusType === 'FAIL') {
      yield put({ type: 'GET_SUBSCRIBE_DATA', payload: false });
    }
  } catch (e) {
    yield put({ type: 'GET_SUBSCRIBE_DATA', payload: false });
    const token = localStorage.getItem('token');
    if ('Unauthorized' === e?.response?.data?.error && token) {
      //   yield put({
      //     type:"SET_MODAL_STATUS",
      //     payload:true
      //   })
      localStorage.setItem('userLogin', 'NO');
    }
  }
}

export function* sendOtpForProduct({ payload }) {
  debugger;
  const sendotppayload = {
    isCaUser: true,
    custId: payload,
  };

  try {
    debugger;
    const data = yield sendYBLOTP(sendotppayload)
      .then((res) => {
        if (res.headers['sessionid']) {
          localStorage.setItem('sessionId', res.headers['sessionid']);
        }
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });

    if (data.statusType === 'FAIL') {
      // yield put({ type: 'MAKE_SUB_FAIL', payload: data.statusMessage });
      yield put({ type: MAKE_SUB_FAIL, data: { response: data.statusMessage } });
    }
    if (data.statusType === 'REQUEST IS NOT APPROPRIATE') {
      // yield put({ type: 'MAKE_SUB_FAIL', payload: data.statusType });
      yield put({ type: MAKE_SUB_FAIL, data: { response: data.statusType } });
    }

    if (data.statusType === 'SUCCESS') {
      const res = { ...data };
      yield put({ type: YBL_OTP_SENT, payload: true });
      // yield put({ type: YBL_SEND_OTP_SUCCESS, payload: res });
      // yield put({ type: YBL_VERIFY_CA_SUCCESS, payload: { result: data.statusMessage } });
    }
  } catch (err) {
    console.log(err);
    // yield put({ type: 'MAKE_SUB_FAIL', payload: 'Unable to connect to YES BANK API' });
    yield put({ type: MAKE_SUB_FAIL, data: { response: 'Unable to connect to YES BANK API' } });
  }
  yield put({ type: YBL_SEND_OTP_LOADER, payload: false });
}

export function* verifyOtpForProduct({ payload }) {
  debugger;
  console.log('verifyOtpForProduct  =====> verifyOtpForProduct');
  try {
    debugger;
    // const state = yield select();
    const reqPayload = {
      otpValue: payload,
      isCaUser: true,
    };

    const data = yield verifyYBLOTPAPI(reqPayload)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    if (data.statusType === 'SUCCESS') {
      if (data.response.mobile && data.response.emailId) {
        yield put({ type: YBL_VERIFY_OTP_SUCCESS, payload: 'Otp Verified' });
        yield put({ type: YBL_VERIFY_OTP_LOADER, payload: false });
        yield put({ type: YBL_VERIFY_OTP_STATUS, payload: 'success' });
        debugger;
        yield put({ type: 'CUST_VERIFED_DATA', payload: data.response });
        localStorage.setItem('CaVerifed', 'YES');
      } else {
      }
    }
    if (data.statusType === 'FAIL') {
      yield put({ type: YBL_VERIFY_OTP_STATUS, data: 'fail' });
      // yield put({ type: 'MAKE_SUB_FAIL', data: data.statusMessage });
      yield put({ type: YBL_VERIFY_OTP_LOADER, payload: false });
      // yield put({ type: 'MAKE_SUB_FAIL', payload: data.statusMessage });
      yield put({ type: MAKE_SUB_FAIL, data: { response: data.statusMessage } });
    }
  } catch (e) {
    yield put({ type: YBL_VERIFY_OTP_STATUS, data: 'fail' });
    yield put({ type: MAKE_SUB_FAIL, data: { response: 'Invalid Otp' } });
    yield put({ type: YBL_VERIFY_OTP_LOADER, payload: false });
  }
}

export default function* watchAll() {
  yield all([
    takeEvery(YBL_CALL_VERIFY_OTP, verifyOtpForProduct),
    takeEvery(FETCH_USER, fetchUserAsync),
    takeEvery(VERIFY_CUST, fetchCustStatusAsync),
    takeEvery(MAKE_SUB, doSubscribeAsync),
    takeEvery(GET_SUBSCRIBE_PRODUCT, getSubscrible),
    takeEvery(CALL_SEND_OTP, sendOtpForProduct),
  ]);
}
